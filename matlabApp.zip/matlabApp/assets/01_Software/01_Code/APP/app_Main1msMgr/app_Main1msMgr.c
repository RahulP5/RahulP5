/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main1msMgr.c
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Fri Nov 26 13:13:41 2021
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main1msMgr.h"
#include "app_Main1msMgr_private.h"

/* user code (top of source file) */
#include "rte.h"

/* Real-time model */
RT_MODEL_app_Main1msMgr_T app_Main1msMgr_M_;
RT_MODEL_app_Main1msMgr_T *const app_Main1msMgr_M = &app_Main1msMgr_M_;

/* Model step function for TID1 */
void app_Main1msMgr_fcn(void)          /* Sample time: [0.001s, 0.0s] */
{
  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main1msMgr_fcn_at_outport_1' incorporates:
   *  SubSystem: '<Root>/app_Main1msMgr'
   */
  /* Inport: '<S1>/APP_1MS_IN1' incorporates:
   *  Inport: '<Root>/APP_1MS_IN1'
   */
  RTE_Write_APP_1MS_OUT1(RTE_Read_APP_1MS_IN1());

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main1msMgr_fcn_at_outport_1' */
}

/* Model initialize function */
void app_Main1msMgr_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(app_Main1msMgr_M, (NULL));

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main1msMgr_fcn_at_outport_1' incorporates:
   *  SystemInitialize for SubSystem: '<Root>/app_Main1msMgr'
   */
  /* SystemInitialize for Outport: '<S1>/APP_1MS_OUT1' */
  RTE_Write_APP_1MS_OUT1(app_Main1msMgr_P.APP_1MS_OUT1_Y0);

  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main1msMgr_fcn_at_outport_1' */
}

/* Model terminate function */
void app_Main1msMgr_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
