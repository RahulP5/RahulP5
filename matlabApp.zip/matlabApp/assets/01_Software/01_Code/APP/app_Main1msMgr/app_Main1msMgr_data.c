/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main1msMgr_data.c
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Fri Nov 26 13:13:41 2021
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main1msMgr.h"
#include "app_Main1msMgr_private.h"

/* Block parameters (auto storage) */
P_app_Main1msMgr_T app_Main1msMgr_P = {
  0.0                                  /* Computed Parameter: APP_1MS_OUT1_Y0
                                        * Referenced by: '<S1>/APP_1MS_OUT1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
