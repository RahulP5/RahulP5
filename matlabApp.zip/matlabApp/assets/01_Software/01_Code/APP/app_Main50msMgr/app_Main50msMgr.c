/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2016 SIGRA Technologies GmbH  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of SIGRA Technologies GmbH and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of SIGRA Technologies GmbH
 *
 * SIGRA Technologies GmbH
 * Agnes-Pockels-Bogen 1,
 * 80992, Munich,
 * Germany
 *
 * File Name: app_Main50msMgr.c
 * Author: TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Sat Sep 11 19:47:28 2021
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main50msMgr.h"
#include "app_Main50msMgr_private.h"

/* user code (top of source file) */
#include "rte.h"

/* Real-time model */
RT_MODEL_app_Main50msMgr_T app_Main50msMgr_M_;
RT_MODEL_app_Main50msMgr_T *const app_Main50msMgr_M = &app_Main50msMgr_M_;

/* Model step function for TID1 */
void app_Main50msMgr_fcn(void)         /* Sample time: [0.05s, 0.0s] */
{
  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main50msMgr_fcn_at_outport_1' incorporates:
   *  SubSystem: '<Root>/app_Main50msMgr'
   */
  /* Inport: '<S1>/APP_50MS_IN1' incorporates:
   *  Inport: '<Root>/APP_50MS_IN1'
   */
  RTE_Write_APP_50MS_OUT1(RTE_Read_APP_50MS_IN1());

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main50msMgr_fcn_at_outport_1' */
}

/* Model initialize function */
void app_Main50msMgr_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(app_Main50msMgr_M, (NULL));

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main50msMgr_fcn_at_outport_1' incorporates:
   *  SystemInitialize for SubSystem: '<Root>/app_Main50msMgr'
   */
  /* SystemInitialize for Outport: '<S1>/APP_50MS_OUT1' */
  RTE_Write_APP_50MS_OUT1(app_Main50msMgr_P.APP_50MS_OUT1_Y0);

  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main50msMgr_fcn_at_outport_1' */
}

/* Model terminate function */
void app_Main50msMgr_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
