/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main10msMgr.h
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Tue Mar 15 12:40:33 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#ifndef RTW_HEADER_app_Main10msMgr_h_
#define RTW_HEADER_app_Main10msMgr_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef app_Main10msMgr_COMMON_INCLUDES_
# define app_Main10msMgr_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* app_Main10msMgr_COMMON_INCLUDES_ */

#include "app_Main10msMgr_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Divide;                       /* '<S2>/Divide' */
  real_T TAPAS_ANLG_Read;              /* '<S3>/TAPAS_ANLG_Read' */
  real_T DataTypeConversion;           /* '<S3>/Data Type Conversion' */
} B_app_Main10msMgr_T;

/* Parameters (auto storage) */
struct P_app_Main10msMgr_T_ {
  real_T ANLG_ReadSignal_PARAM_ID;     /* Mask Parameter: ANLG_ReadSignal_PARAM_ID
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T IO_WriteDigitalOutput_PARAM_ID;/* Mask Parameter: IO_WriteDigitalOutput_PARAM_ID
                                         * Referenced by: '<S4>/Constant'
                                         */
  real_T MEM_SaveSignal_PARAM_ID;      /* Mask Parameter: MEM_SaveSignal_PARAM_ID
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T rpm_Value;                    /* Expression: 5000
                                        * Referenced by: '<S2>/rpm'
                                        */
  real_T Constant_Value;               /* Expression: 3000
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 2048
                                        * Referenced by: '<S2>/Constant1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_app_Main10msMgr_T {
  const char_T * volatile errorStatus;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;
};

/* Block parameters (auto storage) */
extern P_app_Main10msMgr_T app_Main10msMgr_P;

/* Block signals (auto storage) */
extern B_app_Main10msMgr_T app_Main10msMgr_B;

/* Model entry point functions */
extern void app_Main10msMgr_initialize(void);
extern void app_Main10msMgr_terminate(void);

/* Exported entry point functions */
extern void app_Main10msMgr_fcn(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  app_Main10msMgr_GetCAPIStaticMap(void);

/* Exported entry point functions */
extern void app_Main10msMgr_fcn(void);

/* Real-time Model object */
extern RT_MODEL_app_Main10msMgr_T *const app_Main10msMgr_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'app_Main10msMgr'
 * '<S1>'   : 'app_Main10msMgr/app_Main10msMgr'
 * '<S2>'   : 'app_Main10msMgr/app_Main10msMgr/Subsystem'
 * '<S3>'   : 'app_Main10msMgr/app_Main10msMgr/Subsystem/ANLG_ReadSignal'
 * '<S4>'   : 'app_Main10msMgr/app_Main10msMgr/Subsystem/IO_WriteDigitalOutput'
 * '<S5>'   : 'app_Main10msMgr/app_Main10msMgr/Subsystem/MEM_SaveSignal'
 */
#endif                                 /* RTW_HEADER_app_Main10msMgr_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
