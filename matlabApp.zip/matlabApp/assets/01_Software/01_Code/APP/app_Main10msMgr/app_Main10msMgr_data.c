/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main10msMgr_data.c
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Tue Mar 15 12:40:33 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main10msMgr.h"
#include "app_Main10msMgr_private.h"

/* Block parameters (auto storage) */
P_app_Main10msMgr_T app_Main10msMgr_P = {
  1.0,                                 /* Mask Parameter: ANLG_ReadSignal_PARAM_ID
                                        * Referenced by: '<S3>/Constant'
                                        */
  6.0,                                 /* Mask Parameter: IO_WriteDigitalOutput_PARAM_ID
                                        * Referenced by: '<S4>/Constant'
                                        */
  1.0,                                 /* Mask Parameter: MEM_SaveSignal_PARAM_ID
                                        * Referenced by: '<S5>/Constant'
                                        */
  5000.0,                              /* Expression: 5000
                                        * Referenced by: '<S2>/rpm'
                                        */
  3000.0,                              /* Expression: 3000
                                        * Referenced by: '<S2>/Constant'
                                        */
  2048.0                               /* Expression: 2048
                                        * Referenced by: '<S2>/Constant1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
