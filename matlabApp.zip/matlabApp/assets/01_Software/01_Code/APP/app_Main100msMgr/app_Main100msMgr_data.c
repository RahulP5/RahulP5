/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main100msMgr_data.c
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Sat Mar 12 15:03:39 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main100msMgr.h"
#include "app_Main100msMgr_private.h"

/* Block parameters (auto storage) */
P_app_Main100msMgr_T app_Main100msMgr_P = {
  43.0,                                /* Mask Parameter: COM_ReadSignal_PARAM_ID
                                        * Referenced by: '<S3>/Constant'
                                        */
  45.0,                                /* Mask Parameter: COM_ReadSignal1_PARAM_ID
                                        * Referenced by: '<S4>/Constant'
                                        */
  54.0,                                /* Mask Parameter: COM_ReadSignal10_PARAM_ID
                                        * Referenced by: '<S5>/Constant'
                                        */
  50.0,                                /* Mask Parameter: COM_ReadSignal11_PARAM_ID
                                        * Referenced by: '<S6>/Constant'
                                        */
  72.0,                                /* Mask Parameter: COM_ReadSignal12_PARAM_ID
                                        * Referenced by: '<S7>/Constant'
                                        */
  68.0,                                /* Mask Parameter: COM_ReadSignal13_PARAM_ID
                                        * Referenced by: '<S8>/Constant'
                                        */
  67.0,                                /* Mask Parameter: COM_ReadSignal14_PARAM_ID
                                        * Referenced by: '<S9>/Constant'
                                        */
  69.0,                                /* Mask Parameter: COM_ReadSignal15_PARAM_ID
                                        * Referenced by: '<S10>/Constant'
                                        */
  70.0,                                /* Mask Parameter: COM_ReadSignal16_PARAM_ID
                                        * Referenced by: '<S11>/Constant'
                                        */
  71.0,                                /* Mask Parameter: COM_ReadSignal17_PARAM_ID
                                        * Referenced by: '<S12>/Constant'
                                        */
  66.0,                                /* Mask Parameter: COM_ReadSignal18_PARAM_ID
                                        * Referenced by: '<S13>/Constant'
                                        */
  62.0,                                /* Mask Parameter: COM_ReadSignal19_PARAM_ID
                                        * Referenced by: '<S14>/Constant'
                                        */
  46.0,                                /* Mask Parameter: COM_ReadSignal2_PARAM_ID
                                        * Referenced by: '<S15>/Constant'
                                        */
  61.0,                                /* Mask Parameter: COM_ReadSignal20_PARAM_ID
                                        * Referenced by: '<S16>/Constant'
                                        */
  63.0,                                /* Mask Parameter: COM_ReadSignal21_PARAM_ID
                                        * Referenced by: '<S17>/Constant'
                                        */
  64.0,                                /* Mask Parameter: COM_ReadSignal22_PARAM_ID
                                        * Referenced by: '<S18>/Constant'
                                        */
  65.0,                                /* Mask Parameter: COM_ReadSignal23_PARAM_ID
                                        * Referenced by: '<S19>/Constant'
                                        */
  60.0,                                /* Mask Parameter: COM_ReadSignal24_PARAM_ID
                                        * Referenced by: '<S20>/Constant'
                                        */
  56.0,                                /* Mask Parameter: COM_ReadSignal25_PARAM_ID
                                        * Referenced by: '<S21>/Constant'
                                        */
  55.0,                                /* Mask Parameter: COM_ReadSignal26_PARAM_ID
                                        * Referenced by: '<S22>/Constant'
                                        */
  57.0,                                /* Mask Parameter: COM_ReadSignal27_PARAM_ID
                                        * Referenced by: '<S23>/Constant'
                                        */
  58.0,                                /* Mask Parameter: COM_ReadSignal28_PARAM_ID
                                        * Referenced by: '<S24>/Constant'
                                        */
  59.0,                                /* Mask Parameter: COM_ReadSignal29_PARAM_ID
                                        * Referenced by: '<S25>/Constant'
                                        */
  47.0,                                /* Mask Parameter: COM_ReadSignal3_PARAM_ID
                                        * Referenced by: '<S26>/Constant'
                                        */
  78.0,                                /* Mask Parameter: COM_ReadSignal30_PARAM_ID
                                        * Referenced by: '<S27>/Constant'
                                        */
  74.0,                                /* Mask Parameter: COM_ReadSignal31_PARAM_ID
                                        * Referenced by: '<S28>/Constant'
                                        */
  73.0,                                /* Mask Parameter: COM_ReadSignal32_PARAM_ID
                                        * Referenced by: '<S29>/Constant'
                                        */
  75.0,                                /* Mask Parameter: COM_ReadSignal33_PARAM_ID
                                        * Referenced by: '<S30>/Constant'
                                        */
  76.0,                                /* Mask Parameter: COM_ReadSignal34_PARAM_ID
                                        * Referenced by: '<S31>/Constant'
                                        */
  77.0,                                /* Mask Parameter: COM_ReadSignal35_PARAM_ID
                                        * Referenced by: '<S32>/Constant'
                                        */
  84.0,                                /* Mask Parameter: COM_ReadSignal36_PARAM_ID
                                        * Referenced by: '<S33>/Constant'
                                        */
  80.0,                                /* Mask Parameter: COM_ReadSignal37_PARAM_ID
                                        * Referenced by: '<S34>/Constant'
                                        */
  79.0,                                /* Mask Parameter: COM_ReadSignal38_PARAM_ID
                                        * Referenced by: '<S35>/Constant'
                                        */
  81.0,                                /* Mask Parameter: COM_ReadSignal39_PARAM_ID
                                        * Referenced by: '<S36>/Constant'
                                        */
  48.0,                                /* Mask Parameter: COM_ReadSignal4_PARAM_ID
                                        * Referenced by: '<S37>/Constant'
                                        */
  82.0,                                /* Mask Parameter: COM_ReadSignal40_PARAM_ID
                                        * Referenced by: '<S38>/Constant'
                                        */
  83.0,                                /* Mask Parameter: COM_ReadSignal41_PARAM_ID
                                        * Referenced by: '<S39>/Constant'
                                        */
  90.0,                                /* Mask Parameter: COM_ReadSignal42_PARAM_ID
                                        * Referenced by: '<S40>/Constant'
                                        */
  86.0,                                /* Mask Parameter: COM_ReadSignal43_PARAM_ID
                                        * Referenced by: '<S41>/Constant'
                                        */
  85.0,                                /* Mask Parameter: COM_ReadSignal44_PARAM_ID
                                        * Referenced by: '<S42>/Constant'
                                        */
  87.0,                                /* Mask Parameter: COM_ReadSignal45_PARAM_ID
                                        * Referenced by: '<S43>/Constant'
                                        */
  88.0,                                /* Mask Parameter: COM_ReadSignal46_PARAM_ID
                                        * Referenced by: '<S44>/Constant'
                                        */
  89.0,                                /* Mask Parameter: COM_ReadSignal47_PARAM_ID
                                        * Referenced by: '<S45>/Constant'
                                        */
  96.0,                                /* Mask Parameter: COM_ReadSignal48_PARAM_ID
                                        * Referenced by: '<S46>/Constant'
                                        */
  92.0,                                /* Mask Parameter: COM_ReadSignal49_PARAM_ID
                                        * Referenced by: '<S47>/Constant'
                                        */
  44.0,                                /* Mask Parameter: COM_ReadSignal5_PARAM_ID
                                        * Referenced by: '<S48>/Constant'
                                        */
  91.0,                                /* Mask Parameter: COM_ReadSignal50_PARAM_ID
                                        * Referenced by: '<S49>/Constant'
                                        */
  93.0,                                /* Mask Parameter: COM_ReadSignal51_PARAM_ID
                                        * Referenced by: '<S50>/Constant'
                                        */
  94.0,                                /* Mask Parameter: COM_ReadSignal52_PARAM_ID
                                        * Referenced by: '<S51>/Constant'
                                        */
  95.0,                                /* Mask Parameter: COM_ReadSignal53_PARAM_ID
                                        * Referenced by: '<S52>/Constant'
                                        */
  37.0,                                /* Mask Parameter: COM_ReadSignal54_PARAM_ID
                                        * Referenced by: '<S53>/Constant'
                                        */
  39.0,                                /* Mask Parameter: COM_ReadSignal55_PARAM_ID
                                        * Referenced by: '<S54>/Constant'
                                        */
  40.0,                                /* Mask Parameter: COM_ReadSignal56_PARAM_ID
                                        * Referenced by: '<S55>/Constant'
                                        */
  41.0,                                /* Mask Parameter: COM_ReadSignal57_PARAM_ID
                                        * Referenced by: '<S56>/Constant'
                                        */
  42.0,                                /* Mask Parameter: COM_ReadSignal58_PARAM_ID
                                        * Referenced by: '<S57>/Constant'
                                        */
  38.0,                                /* Mask Parameter: COM_ReadSignal59_PARAM_ID
                                        * Referenced by: '<S58>/Constant'
                                        */
  49.0,                                /* Mask Parameter: COM_ReadSignal6_PARAM_ID
                                        * Referenced by: '<S59>/Constant'
                                        */
  51.0,                                /* Mask Parameter: COM_ReadSignal7_PARAM_ID
                                        * Referenced by: '<S60>/Constant'
                                        */
  52.0,                                /* Mask Parameter: COM_ReadSignal8_PARAM_ID
                                        * Referenced by: '<S61>/Constant'
                                        */
  53.0,                                /* Mask Parameter: COM_ReadSignal9_PARAM_ID
                                        * Referenced by: '<S62>/Constant'
                                        */
  12.0,                                /* Mask Parameter: COM_WriteSignal_PARAM_ID
                                        * Referenced by: '<S63>/Constant'
                                        */
  14.0,                                /* Mask Parameter: COM_WriteSignal1_PARAM_ID
                                        * Referenced by: '<S64>/Constant'
                                        */
  23.0,                                /* Mask Parameter: COM_WriteSignal10_PARAM_ID
                                        * Referenced by: '<S65>/Constant'
                                        */
  19.0,                                /* Mask Parameter: COM_WriteSignal11_PARAM_ID
                                        * Referenced by: '<S66>/Constant'
                                        */
  41.0,                                /* Mask Parameter: COM_WriteSignal12_PARAM_ID
                                        * Referenced by: '<S67>/Constant'
                                        */
  37.0,                                /* Mask Parameter: COM_WriteSignal13_PARAM_ID
                                        * Referenced by: '<S68>/Constant'
                                        */
  36.0,                                /* Mask Parameter: COM_WriteSignal14_PARAM_ID
                                        * Referenced by: '<S69>/Constant'
                                        */
  38.0,                                /* Mask Parameter: COM_WriteSignal15_PARAM_ID
                                        * Referenced by: '<S70>/Constant'
                                        */
  39.0,                                /* Mask Parameter: COM_WriteSignal16_PARAM_ID
                                        * Referenced by: '<S71>/Constant'
                                        */
  40.0,                                /* Mask Parameter: COM_WriteSignal17_PARAM_ID
                                        * Referenced by: '<S72>/Constant'
                                        */
  35.0,                                /* Mask Parameter: COM_WriteSignal18_PARAM_ID
                                        * Referenced by: '<S73>/Constant'
                                        */
  31.0,                                /* Mask Parameter: COM_WriteSignal19_PARAM_ID
                                        * Referenced by: '<S74>/Constant'
                                        */
  15.0,                                /* Mask Parameter: COM_WriteSignal2_PARAM_ID
                                        * Referenced by: '<S75>/Constant'
                                        */
  30.0,                                /* Mask Parameter: COM_WriteSignal20_PARAM_ID
                                        * Referenced by: '<S76>/Constant'
                                        */
  32.0,                                /* Mask Parameter: COM_WriteSignal21_PARAM_ID
                                        * Referenced by: '<S77>/Constant'
                                        */
  33.0,                                /* Mask Parameter: COM_WriteSignal22_PARAM_ID
                                        * Referenced by: '<S78>/Constant'
                                        */
  34.0,                                /* Mask Parameter: COM_WriteSignal23_PARAM_ID
                                        * Referenced by: '<S79>/Constant'
                                        */
  29.0,                                /* Mask Parameter: COM_WriteSignal24_PARAM_ID
                                        * Referenced by: '<S80>/Constant'
                                        */
  25.0,                                /* Mask Parameter: COM_WriteSignal25_PARAM_ID
                                        * Referenced by: '<S81>/Constant'
                                        */
  24.0,                                /* Mask Parameter: COM_WriteSignal26_PARAM_ID
                                        * Referenced by: '<S82>/Constant'
                                        */
  26.0,                                /* Mask Parameter: COM_WriteSignal27_PARAM_ID
                                        * Referenced by: '<S83>/Constant'
                                        */
  27.0,                                /* Mask Parameter: COM_WriteSignal28_PARAM_ID
                                        * Referenced by: '<S84>/Constant'
                                        */
  28.0,                                /* Mask Parameter: COM_WriteSignal29_PARAM_ID
                                        * Referenced by: '<S85>/Constant'
                                        */
  16.0,                                /* Mask Parameter: COM_WriteSignal3_PARAM_ID
                                        * Referenced by: '<S86>/Constant'
                                        */
  47.0,                                /* Mask Parameter: COM_WriteSignal30_PARAM_ID
                                        * Referenced by: '<S87>/Constant'
                                        */
  43.0,                                /* Mask Parameter: COM_WriteSignal31_PARAM_ID
                                        * Referenced by: '<S88>/Constant'
                                        */
  42.0,                                /* Mask Parameter: COM_WriteSignal32_PARAM_ID
                                        * Referenced by: '<S89>/Constant'
                                        */
  44.0,                                /* Mask Parameter: COM_WriteSignal33_PARAM_ID
                                        * Referenced by: '<S90>/Constant'
                                        */
  45.0,                                /* Mask Parameter: COM_WriteSignal34_PARAM_ID
                                        * Referenced by: '<S91>/Constant'
                                        */
  46.0,                                /* Mask Parameter: COM_WriteSignal35_PARAM_ID
                                        * Referenced by: '<S92>/Constant'
                                        */
  53.0,                                /* Mask Parameter: COM_WriteSignal36_PARAM_ID
                                        * Referenced by: '<S93>/Constant'
                                        */
  49.0,                                /* Mask Parameter: COM_WriteSignal37_PARAM_ID
                                        * Referenced by: '<S94>/Constant'
                                        */
  48.0,                                /* Mask Parameter: COM_WriteSignal38_PARAM_ID
                                        * Referenced by: '<S95>/Constant'
                                        */
  50.0,                                /* Mask Parameter: COM_WriteSignal39_PARAM_ID
                                        * Referenced by: '<S96>/Constant'
                                        */
  17.0,                                /* Mask Parameter: COM_WriteSignal4_PARAM_ID
                                        * Referenced by: '<S97>/Constant'
                                        */
  51.0,                                /* Mask Parameter: COM_WriteSignal40_PARAM_ID
                                        * Referenced by: '<S98>/Constant'
                                        */
  52.0,                                /* Mask Parameter: COM_WriteSignal41_PARAM_ID
                                        * Referenced by: '<S99>/Constant'
                                        */
  59.0,                                /* Mask Parameter: COM_WriteSignal42_PARAM_ID
                                        * Referenced by: '<S100>/Constant'
                                        */
  55.0,                                /* Mask Parameter: COM_WriteSignal43_PARAM_ID
                                        * Referenced by: '<S101>/Constant'
                                        */
  54.0,                                /* Mask Parameter: COM_WriteSignal44_PARAM_ID
                                        * Referenced by: '<S102>/Constant'
                                        */
  56.0,                                /* Mask Parameter: COM_WriteSignal45_PARAM_ID
                                        * Referenced by: '<S103>/Constant'
                                        */
  57.0,                                /* Mask Parameter: COM_WriteSignal46_PARAM_ID
                                        * Referenced by: '<S104>/Constant'
                                        */
  58.0,                                /* Mask Parameter: COM_WriteSignal47_PARAM_ID
                                        * Referenced by: '<S105>/Constant'
                                        */
  65.0,                                /* Mask Parameter: COM_WriteSignal48_PARAM_ID
                                        * Referenced by: '<S106>/Constant'
                                        */
  61.0,                                /* Mask Parameter: COM_WriteSignal49_PARAM_ID
                                        * Referenced by: '<S107>/Constant'
                                        */
  13.0,                                /* Mask Parameter: COM_WriteSignal5_PARAM_ID
                                        * Referenced by: '<S108>/Constant'
                                        */
  60.0,                                /* Mask Parameter: COM_WriteSignal50_PARAM_ID
                                        * Referenced by: '<S109>/Constant'
                                        */
  62.0,                                /* Mask Parameter: COM_WriteSignal51_PARAM_ID
                                        * Referenced by: '<S110>/Constant'
                                        */
  63.0,                                /* Mask Parameter: COM_WriteSignal52_PARAM_ID
                                        * Referenced by: '<S111>/Constant'
                                        */
  64.0,                                /* Mask Parameter: COM_WriteSignal53_PARAM_ID
                                        * Referenced by: '<S112>/Constant'
                                        */
  6.0,                                 /* Mask Parameter: COM_WriteSignal54_PARAM_ID
                                        * Referenced by: '<S113>/Constant'
                                        */
  8.0,                                 /* Mask Parameter: COM_WriteSignal55_PARAM_ID
                                        * Referenced by: '<S114>/Constant'
                                        */
  9.0,                                 /* Mask Parameter: COM_WriteSignal56_PARAM_ID
                                        * Referenced by: '<S115>/Constant'
                                        */
  10.0,                                /* Mask Parameter: COM_WriteSignal57_PARAM_ID
                                        * Referenced by: '<S116>/Constant'
                                        */
  11.0,                                /* Mask Parameter: COM_WriteSignal58_PARAM_ID
                                        * Referenced by: '<S117>/Constant'
                                        */
  7.0,                                 /* Mask Parameter: COM_WriteSignal59_PARAM_ID
                                        * Referenced by: '<S118>/Constant'
                                        */
  18.0,                                /* Mask Parameter: COM_WriteSignal6_PARAM_ID
                                        * Referenced by: '<S119>/Constant'
                                        */
  20.0,                                /* Mask Parameter: COM_WriteSignal7_PARAM_ID
                                        * Referenced by: '<S120>/Constant'
                                        */
  21.0,                                /* Mask Parameter: COM_WriteSignal8_PARAM_ID
                                        * Referenced by: '<S121>/Constant'
                                        */
  22.0,                                /* Mask Parameter: COM_WriteSignal9_PARAM_ID
                                        * Referenced by: '<S122>/Constant'
                                        */
  0.0                                  /* Computed Parameter: APP_100MS_OUT1_Y0
                                        * Referenced by: '<S1>/APP_100MS_OUT1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
