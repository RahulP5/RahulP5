/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main100msMgr.h
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Sat Mar 12 15:03:39 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#ifndef RTW_HEADER_app_Main100msMgr_h_
#define RTW_HEADER_app_Main100msMgr_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef app_Main100msMgr_COMMON_INCLUDES_
# define app_Main100msMgr_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* app_Main100msMgr_COMMON_INCLUDES_ */

#include "app_Main100msMgr_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T TAPAS_COM_ReadSignal_o1;      /* '<S62>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2;      /* '<S62>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion;           /* '<S62>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_c;    /* '<S61>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_d;    /* '<S61>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_d;         /* '<S61>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_a;    /* '<S60>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_g;    /* '<S60>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_e;         /* '<S60>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_k;    /* '<S59>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_m;    /* '<S59>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_p;         /* '<S59>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_cg;   /* '<S58>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_p;    /* '<S58>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_g;         /* '<S58>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_j;    /* '<S57>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_f;    /* '<S57>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_gg;        /* '<S57>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_l;    /* '<S56>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_gs;   /* '<S56>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_a;         /* '<S56>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_jd;   /* '<S55>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_l;    /* '<S55>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_i;         /* '<S55>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_h;    /* '<S54>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_j;    /* '<S54>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_o;         /* '<S54>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_jo;   /* '<S53>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_gd;   /* '<S53>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_iy;        /* '<S53>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_e;    /* '<S52>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_jp;   /* '<S52>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_n;         /* '<S52>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ef;   /* '<S51>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_n;    /* '<S51>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_c;         /* '<S51>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_i;    /* '<S50>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_c;    /* '<S50>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_h;         /* '<S50>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_kt;   /* '<S49>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_j2;   /* '<S49>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_l;         /* '<S49>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_j2;   /* '<S48>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_o;    /* '<S48>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_j;         /* '<S48>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_hm;   /* '<S47>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_k;    /* '<S47>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ep;        /* '<S47>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_eb;   /* '<S46>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_kw;   /* '<S46>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ns;        /* '<S46>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_d;    /* '<S45>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_b;    /* '<S45>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_jd;        /* '<S45>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_o;    /* '<S44>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_or;   /* '<S44>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_m;         /* '<S44>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_dy;   /* '<S43>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ne;   /* '<S43>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_f;         /* '<S43>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_hk;   /* '<S42>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ms;   /* '<S42>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_id;        /* '<S42>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_di;   /* '<S41>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_oy;   /* '<S41>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_k;         /* '<S41>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_b;    /* '<S40>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ds;   /* '<S40>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_dq;        /* '<S40>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_m;    /* '<S39>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_a;    /* '<S39>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_nh;        /* '<S39>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_f;    /* '<S38>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_mg;   /* '<S38>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_jo;        /* '<S38>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_p;    /* '<S37>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_h;    /* '<S37>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_kt;        /* '<S37>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_pp;   /* '<S36>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_e;    /* '<S36>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_lq;        /* '<S36>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_em;   /* '<S35>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_bf;   /* '<S35>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_mv;        /* '<S35>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_dg;   /* '<S34>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_oo;   /* '<S34>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ju;        /* '<S34>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_cj;   /* '<S33>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ea;   /* '<S33>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_gp;        /* '<S33>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_i5;   /* '<S32>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ev;   /* '<S32>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_h4;        /* '<S32>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_kl;   /* '<S31>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_pc;   /* '<S31>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_nv;        /* '<S31>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_je;   /* '<S30>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_oe;   /* '<S30>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_cz;        /* '<S30>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ai;   /* '<S29>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_kv;   /* '<S29>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ln;        /* '<S29>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_lh;   /* '<S28>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ce;   /* '<S28>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_pe;        /* '<S28>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_pn;   /* '<S27>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_fr;   /* '<S27>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_jq;        /* '<S27>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ag;   /* '<S26>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_l4;   /* '<S26>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_jl;        /* '<S26>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_pk;   /* '<S25>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_go;   /* '<S25>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_or;        /* '<S25>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_al;   /* '<S24>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ef;   /* '<S24>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_gm;        /* '<S24>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_g;    /* '<S23>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ew;   /* '<S23>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_cl;        /* '<S23>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_j4;   /* '<S22>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_f0;   /* '<S22>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_iz;        /* '<S22>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_gn;   /* '<S21>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_al;   /* '<S21>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_hr;        /* '<S21>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ca;   /* '<S20>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_gy;   /* '<S20>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_kd;        /* '<S20>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_m1;   /* '<S19>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ff;   /* '<S19>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_mo;        /* '<S19>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_cc;   /* '<S18>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_bl;   /* '<S18>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_dv;        /* '<S18>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_m3;   /* '<S17>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_eu;   /* '<S17>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_je;        /* '<S17>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_kf;   /* '<S16>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_p5;   /* '<S16>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ap;        /* '<S16>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_kj;   /* '<S15>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ceu;  /* '<S15>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_jk;        /* '<S15>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_o0;   /* '<S14>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_kc;   /* '<S14>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_me;        /* '<S14>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_lj;   /* '<S13>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_lu;   /* '<S13>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_cv;        /* '<S13>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_fc;   /* '<S12>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ewv;  /* '<S12>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_hl;        /* '<S12>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_pv;   /* '<S11>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_hg;   /* '<S11>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ory;       /* '<S11>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ka;   /* '<S10>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_oa;   /* '<S10>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_fw;        /* '<S10>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_jm;   /* '<S9>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_i;    /* '<S9>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_l2;        /* '<S9>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_ic;   /* '<S8>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_dl;   /* '<S8>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_ca;        /* '<S8>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_pd;   /* '<S7>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_bz;   /* '<S7>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_o1;        /* '<S7>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_dgj;  /* '<S6>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_gi;   /* '<S6>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_om;        /* '<S6>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_hg;   /* '<S5>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_ph;   /* '<S5>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_pt;        /* '<S5>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_h5;   /* '<S4>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_l5;   /* '<S4>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_di;        /* '<S4>/Data Type Conversion' */
  real_T TAPAS_COM_ReadSignal_o1_h3;   /* '<S3>/TAPAS_COM_ReadSignal' */
  real_T TAPAS_COM_ReadSignal_o2_bz1;  /* '<S3>/TAPAS_COM_ReadSignal' */
  real_T DataTypeConversion_hp;        /* '<S3>/Data Type Conversion' */
} B_app_Main100msMgr_T;

/* Parameters (auto storage) */
struct P_app_Main100msMgr_T_ {
  real_T COM_ReadSignal_PARAM_ID;      /* Mask Parameter: COM_ReadSignal_PARAM_ID
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T COM_ReadSignal1_PARAM_ID;     /* Mask Parameter: COM_ReadSignal1_PARAM_ID
                                        * Referenced by: '<S4>/Constant'
                                        */
  real_T COM_ReadSignal10_PARAM_ID;    /* Mask Parameter: COM_ReadSignal10_PARAM_ID
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T COM_ReadSignal11_PARAM_ID;    /* Mask Parameter: COM_ReadSignal11_PARAM_ID
                                        * Referenced by: '<S6>/Constant'
                                        */
  real_T COM_ReadSignal12_PARAM_ID;    /* Mask Parameter: COM_ReadSignal12_PARAM_ID
                                        * Referenced by: '<S7>/Constant'
                                        */
  real_T COM_ReadSignal13_PARAM_ID;    /* Mask Parameter: COM_ReadSignal13_PARAM_ID
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T COM_ReadSignal14_PARAM_ID;    /* Mask Parameter: COM_ReadSignal14_PARAM_ID
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T COM_ReadSignal15_PARAM_ID;    /* Mask Parameter: COM_ReadSignal15_PARAM_ID
                                        * Referenced by: '<S10>/Constant'
                                        */
  real_T COM_ReadSignal16_PARAM_ID;    /* Mask Parameter: COM_ReadSignal16_PARAM_ID
                                        * Referenced by: '<S11>/Constant'
                                        */
  real_T COM_ReadSignal17_PARAM_ID;    /* Mask Parameter: COM_ReadSignal17_PARAM_ID
                                        * Referenced by: '<S12>/Constant'
                                        */
  real_T COM_ReadSignal18_PARAM_ID;    /* Mask Parameter: COM_ReadSignal18_PARAM_ID
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T COM_ReadSignal19_PARAM_ID;    /* Mask Parameter: COM_ReadSignal19_PARAM_ID
                                        * Referenced by: '<S14>/Constant'
                                        */
  real_T COM_ReadSignal2_PARAM_ID;     /* Mask Parameter: COM_ReadSignal2_PARAM_ID
                                        * Referenced by: '<S15>/Constant'
                                        */
  real_T COM_ReadSignal20_PARAM_ID;    /* Mask Parameter: COM_ReadSignal20_PARAM_ID
                                        * Referenced by: '<S16>/Constant'
                                        */
  real_T COM_ReadSignal21_PARAM_ID;    /* Mask Parameter: COM_ReadSignal21_PARAM_ID
                                        * Referenced by: '<S17>/Constant'
                                        */
  real_T COM_ReadSignal22_PARAM_ID;    /* Mask Parameter: COM_ReadSignal22_PARAM_ID
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T COM_ReadSignal23_PARAM_ID;    /* Mask Parameter: COM_ReadSignal23_PARAM_ID
                                        * Referenced by: '<S19>/Constant'
                                        */
  real_T COM_ReadSignal24_PARAM_ID;    /* Mask Parameter: COM_ReadSignal24_PARAM_ID
                                        * Referenced by: '<S20>/Constant'
                                        */
  real_T COM_ReadSignal25_PARAM_ID;    /* Mask Parameter: COM_ReadSignal25_PARAM_ID
                                        * Referenced by: '<S21>/Constant'
                                        */
  real_T COM_ReadSignal26_PARAM_ID;    /* Mask Parameter: COM_ReadSignal26_PARAM_ID
                                        * Referenced by: '<S22>/Constant'
                                        */
  real_T COM_ReadSignal27_PARAM_ID;    /* Mask Parameter: COM_ReadSignal27_PARAM_ID
                                        * Referenced by: '<S23>/Constant'
                                        */
  real_T COM_ReadSignal28_PARAM_ID;    /* Mask Parameter: COM_ReadSignal28_PARAM_ID
                                        * Referenced by: '<S24>/Constant'
                                        */
  real_T COM_ReadSignal29_PARAM_ID;    /* Mask Parameter: COM_ReadSignal29_PARAM_ID
                                        * Referenced by: '<S25>/Constant'
                                        */
  real_T COM_ReadSignal3_PARAM_ID;     /* Mask Parameter: COM_ReadSignal3_PARAM_ID
                                        * Referenced by: '<S26>/Constant'
                                        */
  real_T COM_ReadSignal30_PARAM_ID;    /* Mask Parameter: COM_ReadSignal30_PARAM_ID
                                        * Referenced by: '<S27>/Constant'
                                        */
  real_T COM_ReadSignal31_PARAM_ID;    /* Mask Parameter: COM_ReadSignal31_PARAM_ID
                                        * Referenced by: '<S28>/Constant'
                                        */
  real_T COM_ReadSignal32_PARAM_ID;    /* Mask Parameter: COM_ReadSignal32_PARAM_ID
                                        * Referenced by: '<S29>/Constant'
                                        */
  real_T COM_ReadSignal33_PARAM_ID;    /* Mask Parameter: COM_ReadSignal33_PARAM_ID
                                        * Referenced by: '<S30>/Constant'
                                        */
  real_T COM_ReadSignal34_PARAM_ID;    /* Mask Parameter: COM_ReadSignal34_PARAM_ID
                                        * Referenced by: '<S31>/Constant'
                                        */
  real_T COM_ReadSignal35_PARAM_ID;    /* Mask Parameter: COM_ReadSignal35_PARAM_ID
                                        * Referenced by: '<S32>/Constant'
                                        */
  real_T COM_ReadSignal36_PARAM_ID;    /* Mask Parameter: COM_ReadSignal36_PARAM_ID
                                        * Referenced by: '<S33>/Constant'
                                        */
  real_T COM_ReadSignal37_PARAM_ID;    /* Mask Parameter: COM_ReadSignal37_PARAM_ID
                                        * Referenced by: '<S34>/Constant'
                                        */
  real_T COM_ReadSignal38_PARAM_ID;    /* Mask Parameter: COM_ReadSignal38_PARAM_ID
                                        * Referenced by: '<S35>/Constant'
                                        */
  real_T COM_ReadSignal39_PARAM_ID;    /* Mask Parameter: COM_ReadSignal39_PARAM_ID
                                        * Referenced by: '<S36>/Constant'
                                        */
  real_T COM_ReadSignal4_PARAM_ID;     /* Mask Parameter: COM_ReadSignal4_PARAM_ID
                                        * Referenced by: '<S37>/Constant'
                                        */
  real_T COM_ReadSignal40_PARAM_ID;    /* Mask Parameter: COM_ReadSignal40_PARAM_ID
                                        * Referenced by: '<S38>/Constant'
                                        */
  real_T COM_ReadSignal41_PARAM_ID;    /* Mask Parameter: COM_ReadSignal41_PARAM_ID
                                        * Referenced by: '<S39>/Constant'
                                        */
  real_T COM_ReadSignal42_PARAM_ID;    /* Mask Parameter: COM_ReadSignal42_PARAM_ID
                                        * Referenced by: '<S40>/Constant'
                                        */
  real_T COM_ReadSignal43_PARAM_ID;    /* Mask Parameter: COM_ReadSignal43_PARAM_ID
                                        * Referenced by: '<S41>/Constant'
                                        */
  real_T COM_ReadSignal44_PARAM_ID;    /* Mask Parameter: COM_ReadSignal44_PARAM_ID
                                        * Referenced by: '<S42>/Constant'
                                        */
  real_T COM_ReadSignal45_PARAM_ID;    /* Mask Parameter: COM_ReadSignal45_PARAM_ID
                                        * Referenced by: '<S43>/Constant'
                                        */
  real_T COM_ReadSignal46_PARAM_ID;    /* Mask Parameter: COM_ReadSignal46_PARAM_ID
                                        * Referenced by: '<S44>/Constant'
                                        */
  real_T COM_ReadSignal47_PARAM_ID;    /* Mask Parameter: COM_ReadSignal47_PARAM_ID
                                        * Referenced by: '<S45>/Constant'
                                        */
  real_T COM_ReadSignal48_PARAM_ID;    /* Mask Parameter: COM_ReadSignal48_PARAM_ID
                                        * Referenced by: '<S46>/Constant'
                                        */
  real_T COM_ReadSignal49_PARAM_ID;    /* Mask Parameter: COM_ReadSignal49_PARAM_ID
                                        * Referenced by: '<S47>/Constant'
                                        */
  real_T COM_ReadSignal5_PARAM_ID;     /* Mask Parameter: COM_ReadSignal5_PARAM_ID
                                        * Referenced by: '<S48>/Constant'
                                        */
  real_T COM_ReadSignal50_PARAM_ID;    /* Mask Parameter: COM_ReadSignal50_PARAM_ID
                                        * Referenced by: '<S49>/Constant'
                                        */
  real_T COM_ReadSignal51_PARAM_ID;    /* Mask Parameter: COM_ReadSignal51_PARAM_ID
                                        * Referenced by: '<S50>/Constant'
                                        */
  real_T COM_ReadSignal52_PARAM_ID;    /* Mask Parameter: COM_ReadSignal52_PARAM_ID
                                        * Referenced by: '<S51>/Constant'
                                        */
  real_T COM_ReadSignal53_PARAM_ID;    /* Mask Parameter: COM_ReadSignal53_PARAM_ID
                                        * Referenced by: '<S52>/Constant'
                                        */
  real_T COM_ReadSignal54_PARAM_ID;    /* Mask Parameter: COM_ReadSignal54_PARAM_ID
                                        * Referenced by: '<S53>/Constant'
                                        */
  real_T COM_ReadSignal55_PARAM_ID;    /* Mask Parameter: COM_ReadSignal55_PARAM_ID
                                        * Referenced by: '<S54>/Constant'
                                        */
  real_T COM_ReadSignal56_PARAM_ID;    /* Mask Parameter: COM_ReadSignal56_PARAM_ID
                                        * Referenced by: '<S55>/Constant'
                                        */
  real_T COM_ReadSignal57_PARAM_ID;    /* Mask Parameter: COM_ReadSignal57_PARAM_ID
                                        * Referenced by: '<S56>/Constant'
                                        */
  real_T COM_ReadSignal58_PARAM_ID;    /* Mask Parameter: COM_ReadSignal58_PARAM_ID
                                        * Referenced by: '<S57>/Constant'
                                        */
  real_T COM_ReadSignal59_PARAM_ID;    /* Mask Parameter: COM_ReadSignal59_PARAM_ID
                                        * Referenced by: '<S58>/Constant'
                                        */
  real_T COM_ReadSignal6_PARAM_ID;     /* Mask Parameter: COM_ReadSignal6_PARAM_ID
                                        * Referenced by: '<S59>/Constant'
                                        */
  real_T COM_ReadSignal7_PARAM_ID;     /* Mask Parameter: COM_ReadSignal7_PARAM_ID
                                        * Referenced by: '<S60>/Constant'
                                        */
  real_T COM_ReadSignal8_PARAM_ID;     /* Mask Parameter: COM_ReadSignal8_PARAM_ID
                                        * Referenced by: '<S61>/Constant'
                                        */
  real_T COM_ReadSignal9_PARAM_ID;     /* Mask Parameter: COM_ReadSignal9_PARAM_ID
                                        * Referenced by: '<S62>/Constant'
                                        */
  real_T COM_WriteSignal_PARAM_ID;     /* Mask Parameter: COM_WriteSignal_PARAM_ID
                                        * Referenced by: '<S63>/Constant'
                                        */
  real_T COM_WriteSignal1_PARAM_ID;    /* Mask Parameter: COM_WriteSignal1_PARAM_ID
                                        * Referenced by: '<S64>/Constant'
                                        */
  real_T COM_WriteSignal10_PARAM_ID;   /* Mask Parameter: COM_WriteSignal10_PARAM_ID
                                        * Referenced by: '<S65>/Constant'
                                        */
  real_T COM_WriteSignal11_PARAM_ID;   /* Mask Parameter: COM_WriteSignal11_PARAM_ID
                                        * Referenced by: '<S66>/Constant'
                                        */
  real_T COM_WriteSignal12_PARAM_ID;   /* Mask Parameter: COM_WriteSignal12_PARAM_ID
                                        * Referenced by: '<S67>/Constant'
                                        */
  real_T COM_WriteSignal13_PARAM_ID;   /* Mask Parameter: COM_WriteSignal13_PARAM_ID
                                        * Referenced by: '<S68>/Constant'
                                        */
  real_T COM_WriteSignal14_PARAM_ID;   /* Mask Parameter: COM_WriteSignal14_PARAM_ID
                                        * Referenced by: '<S69>/Constant'
                                        */
  real_T COM_WriteSignal15_PARAM_ID;   /* Mask Parameter: COM_WriteSignal15_PARAM_ID
                                        * Referenced by: '<S70>/Constant'
                                        */
  real_T COM_WriteSignal16_PARAM_ID;   /* Mask Parameter: COM_WriteSignal16_PARAM_ID
                                        * Referenced by: '<S71>/Constant'
                                        */
  real_T COM_WriteSignal17_PARAM_ID;   /* Mask Parameter: COM_WriteSignal17_PARAM_ID
                                        * Referenced by: '<S72>/Constant'
                                        */
  real_T COM_WriteSignal18_PARAM_ID;   /* Mask Parameter: COM_WriteSignal18_PARAM_ID
                                        * Referenced by: '<S73>/Constant'
                                        */
  real_T COM_WriteSignal19_PARAM_ID;   /* Mask Parameter: COM_WriteSignal19_PARAM_ID
                                        * Referenced by: '<S74>/Constant'
                                        */
  real_T COM_WriteSignal2_PARAM_ID;    /* Mask Parameter: COM_WriteSignal2_PARAM_ID
                                        * Referenced by: '<S75>/Constant'
                                        */
  real_T COM_WriteSignal20_PARAM_ID;   /* Mask Parameter: COM_WriteSignal20_PARAM_ID
                                        * Referenced by: '<S76>/Constant'
                                        */
  real_T COM_WriteSignal21_PARAM_ID;   /* Mask Parameter: COM_WriteSignal21_PARAM_ID
                                        * Referenced by: '<S77>/Constant'
                                        */
  real_T COM_WriteSignal22_PARAM_ID;   /* Mask Parameter: COM_WriteSignal22_PARAM_ID
                                        * Referenced by: '<S78>/Constant'
                                        */
  real_T COM_WriteSignal23_PARAM_ID;   /* Mask Parameter: COM_WriteSignal23_PARAM_ID
                                        * Referenced by: '<S79>/Constant'
                                        */
  real_T COM_WriteSignal24_PARAM_ID;   /* Mask Parameter: COM_WriteSignal24_PARAM_ID
                                        * Referenced by: '<S80>/Constant'
                                        */
  real_T COM_WriteSignal25_PARAM_ID;   /* Mask Parameter: COM_WriteSignal25_PARAM_ID
                                        * Referenced by: '<S81>/Constant'
                                        */
  real_T COM_WriteSignal26_PARAM_ID;   /* Mask Parameter: COM_WriteSignal26_PARAM_ID
                                        * Referenced by: '<S82>/Constant'
                                        */
  real_T COM_WriteSignal27_PARAM_ID;   /* Mask Parameter: COM_WriteSignal27_PARAM_ID
                                        * Referenced by: '<S83>/Constant'
                                        */
  real_T COM_WriteSignal28_PARAM_ID;   /* Mask Parameter: COM_WriteSignal28_PARAM_ID
                                        * Referenced by: '<S84>/Constant'
                                        */
  real_T COM_WriteSignal29_PARAM_ID;   /* Mask Parameter: COM_WriteSignal29_PARAM_ID
                                        * Referenced by: '<S85>/Constant'
                                        */
  real_T COM_WriteSignal3_PARAM_ID;    /* Mask Parameter: COM_WriteSignal3_PARAM_ID
                                        * Referenced by: '<S86>/Constant'
                                        */
  real_T COM_WriteSignal30_PARAM_ID;   /* Mask Parameter: COM_WriteSignal30_PARAM_ID
                                        * Referenced by: '<S87>/Constant'
                                        */
  real_T COM_WriteSignal31_PARAM_ID;   /* Mask Parameter: COM_WriteSignal31_PARAM_ID
                                        * Referenced by: '<S88>/Constant'
                                        */
  real_T COM_WriteSignal32_PARAM_ID;   /* Mask Parameter: COM_WriteSignal32_PARAM_ID
                                        * Referenced by: '<S89>/Constant'
                                        */
  real_T COM_WriteSignal33_PARAM_ID;   /* Mask Parameter: COM_WriteSignal33_PARAM_ID
                                        * Referenced by: '<S90>/Constant'
                                        */
  real_T COM_WriteSignal34_PARAM_ID;   /* Mask Parameter: COM_WriteSignal34_PARAM_ID
                                        * Referenced by: '<S91>/Constant'
                                        */
  real_T COM_WriteSignal35_PARAM_ID;   /* Mask Parameter: COM_WriteSignal35_PARAM_ID
                                        * Referenced by: '<S92>/Constant'
                                        */
  real_T COM_WriteSignal36_PARAM_ID;   /* Mask Parameter: COM_WriteSignal36_PARAM_ID
                                        * Referenced by: '<S93>/Constant'
                                        */
  real_T COM_WriteSignal37_PARAM_ID;   /* Mask Parameter: COM_WriteSignal37_PARAM_ID
                                        * Referenced by: '<S94>/Constant'
                                        */
  real_T COM_WriteSignal38_PARAM_ID;   /* Mask Parameter: COM_WriteSignal38_PARAM_ID
                                        * Referenced by: '<S95>/Constant'
                                        */
  real_T COM_WriteSignal39_PARAM_ID;   /* Mask Parameter: COM_WriteSignal39_PARAM_ID
                                        * Referenced by: '<S96>/Constant'
                                        */
  real_T COM_WriteSignal4_PARAM_ID;    /* Mask Parameter: COM_WriteSignal4_PARAM_ID
                                        * Referenced by: '<S97>/Constant'
                                        */
  real_T COM_WriteSignal40_PARAM_ID;   /* Mask Parameter: COM_WriteSignal40_PARAM_ID
                                        * Referenced by: '<S98>/Constant'
                                        */
  real_T COM_WriteSignal41_PARAM_ID;   /* Mask Parameter: COM_WriteSignal41_PARAM_ID
                                        * Referenced by: '<S99>/Constant'
                                        */
  real_T COM_WriteSignal42_PARAM_ID;   /* Mask Parameter: COM_WriteSignal42_PARAM_ID
                                        * Referenced by: '<S100>/Constant'
                                        */
  real_T COM_WriteSignal43_PARAM_ID;   /* Mask Parameter: COM_WriteSignal43_PARAM_ID
                                        * Referenced by: '<S101>/Constant'
                                        */
  real_T COM_WriteSignal44_PARAM_ID;   /* Mask Parameter: COM_WriteSignal44_PARAM_ID
                                        * Referenced by: '<S102>/Constant'
                                        */
  real_T COM_WriteSignal45_PARAM_ID;   /* Mask Parameter: COM_WriteSignal45_PARAM_ID
                                        * Referenced by: '<S103>/Constant'
                                        */
  real_T COM_WriteSignal46_PARAM_ID;   /* Mask Parameter: COM_WriteSignal46_PARAM_ID
                                        * Referenced by: '<S104>/Constant'
                                        */
  real_T COM_WriteSignal47_PARAM_ID;   /* Mask Parameter: COM_WriteSignal47_PARAM_ID
                                        * Referenced by: '<S105>/Constant'
                                        */
  real_T COM_WriteSignal48_PARAM_ID;   /* Mask Parameter: COM_WriteSignal48_PARAM_ID
                                        * Referenced by: '<S106>/Constant'
                                        */
  real_T COM_WriteSignal49_PARAM_ID;   /* Mask Parameter: COM_WriteSignal49_PARAM_ID
                                        * Referenced by: '<S107>/Constant'
                                        */
  real_T COM_WriteSignal5_PARAM_ID;    /* Mask Parameter: COM_WriteSignal5_PARAM_ID
                                        * Referenced by: '<S108>/Constant'
                                        */
  real_T COM_WriteSignal50_PARAM_ID;   /* Mask Parameter: COM_WriteSignal50_PARAM_ID
                                        * Referenced by: '<S109>/Constant'
                                        */
  real_T COM_WriteSignal51_PARAM_ID;   /* Mask Parameter: COM_WriteSignal51_PARAM_ID
                                        * Referenced by: '<S110>/Constant'
                                        */
  real_T COM_WriteSignal52_PARAM_ID;   /* Mask Parameter: COM_WriteSignal52_PARAM_ID
                                        * Referenced by: '<S111>/Constant'
                                        */
  real_T COM_WriteSignal53_PARAM_ID;   /* Mask Parameter: COM_WriteSignal53_PARAM_ID
                                        * Referenced by: '<S112>/Constant'
                                        */
  real_T COM_WriteSignal54_PARAM_ID;   /* Mask Parameter: COM_WriteSignal54_PARAM_ID
                                        * Referenced by: '<S113>/Constant'
                                        */
  real_T COM_WriteSignal55_PARAM_ID;   /* Mask Parameter: COM_WriteSignal55_PARAM_ID
                                        * Referenced by: '<S114>/Constant'
                                        */
  real_T COM_WriteSignal56_PARAM_ID;   /* Mask Parameter: COM_WriteSignal56_PARAM_ID
                                        * Referenced by: '<S115>/Constant'
                                        */
  real_T COM_WriteSignal57_PARAM_ID;   /* Mask Parameter: COM_WriteSignal57_PARAM_ID
                                        * Referenced by: '<S116>/Constant'
                                        */
  real_T COM_WriteSignal58_PARAM_ID;   /* Mask Parameter: COM_WriteSignal58_PARAM_ID
                                        * Referenced by: '<S117>/Constant'
                                        */
  real_T COM_WriteSignal59_PARAM_ID;   /* Mask Parameter: COM_WriteSignal59_PARAM_ID
                                        * Referenced by: '<S118>/Constant'
                                        */
  real_T COM_WriteSignal6_PARAM_ID;    /* Mask Parameter: COM_WriteSignal6_PARAM_ID
                                        * Referenced by: '<S119>/Constant'
                                        */
  real_T COM_WriteSignal7_PARAM_ID;    /* Mask Parameter: COM_WriteSignal7_PARAM_ID
                                        * Referenced by: '<S120>/Constant'
                                        */
  real_T COM_WriteSignal8_PARAM_ID;    /* Mask Parameter: COM_WriteSignal8_PARAM_ID
                                        * Referenced by: '<S121>/Constant'
                                        */
  real_T COM_WriteSignal9_PARAM_ID;    /* Mask Parameter: COM_WriteSignal9_PARAM_ID
                                        * Referenced by: '<S122>/Constant'
                                        */
  real_T APP_100MS_OUT1_Y0;            /* Computed Parameter: APP_100MS_OUT1_Y0
                                        * Referenced by: '<S1>/APP_100MS_OUT1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_app_Main100msMgr_T {
  const char_T * volatile errorStatus;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;
};

/* Block parameters (auto storage) */
extern P_app_Main100msMgr_T app_Main100msMgr_P;

/* Block signals (auto storage) */
extern B_app_Main100msMgr_T app_Main100msMgr_B;

/* Model entry point functions */
extern void app_Main100msMgr_initialize(void);
extern void app_Main100msMgr_terminate(void);

/* Exported entry point functions */
extern void app_Main100msMgr_fcn(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  app_Main100msMgr_GetCAPIStaticMap(void);

/* Exported entry point functions */
extern void app_Main100msMgr_fcn(void);

/* Real-time Model object */
extern RT_MODEL_app_Main100msMgr_T *const app_Main100msMgr_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'app_Main100msMgr'
 * '<S1>'   : 'app_Main100msMgr/app_Main100msMgr'
 * '<S2>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals'
 * '<S3>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal'
 * '<S4>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal1'
 * '<S5>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal10'
 * '<S6>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal11'
 * '<S7>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal12'
 * '<S8>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal13'
 * '<S9>'   : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal14'
 * '<S10>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal15'
 * '<S11>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal16'
 * '<S12>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal17'
 * '<S13>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal18'
 * '<S14>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal19'
 * '<S15>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal2'
 * '<S16>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal20'
 * '<S17>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal21'
 * '<S18>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal22'
 * '<S19>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal23'
 * '<S20>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal24'
 * '<S21>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal25'
 * '<S22>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal26'
 * '<S23>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal27'
 * '<S24>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal28'
 * '<S25>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal29'
 * '<S26>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal3'
 * '<S27>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal30'
 * '<S28>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal31'
 * '<S29>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal32'
 * '<S30>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal33'
 * '<S31>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal34'
 * '<S32>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal35'
 * '<S33>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal36'
 * '<S34>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal37'
 * '<S35>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal38'
 * '<S36>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal39'
 * '<S37>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal4'
 * '<S38>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal40'
 * '<S39>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal41'
 * '<S40>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal42'
 * '<S41>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal43'
 * '<S42>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal44'
 * '<S43>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal45'
 * '<S44>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal46'
 * '<S45>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal47'
 * '<S46>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal48'
 * '<S47>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal49'
 * '<S48>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal5'
 * '<S49>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal50'
 * '<S50>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal51'
 * '<S51>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal52'
 * '<S52>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal53'
 * '<S53>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal54'
 * '<S54>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal55'
 * '<S55>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal56'
 * '<S56>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal57'
 * '<S57>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal58'
 * '<S58>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal59'
 * '<S59>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal6'
 * '<S60>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal7'
 * '<S61>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal8'
 * '<S62>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_ReadSignal9'
 * '<S63>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal'
 * '<S64>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal1'
 * '<S65>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal10'
 * '<S66>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal11'
 * '<S67>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal12'
 * '<S68>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal13'
 * '<S69>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal14'
 * '<S70>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal15'
 * '<S71>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal16'
 * '<S72>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal17'
 * '<S73>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal18'
 * '<S74>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal19'
 * '<S75>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal2'
 * '<S76>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal20'
 * '<S77>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal21'
 * '<S78>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal22'
 * '<S79>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal23'
 * '<S80>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal24'
 * '<S81>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal25'
 * '<S82>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal26'
 * '<S83>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal27'
 * '<S84>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal28'
 * '<S85>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal29'
 * '<S86>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal3'
 * '<S87>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal30'
 * '<S88>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal31'
 * '<S89>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal32'
 * '<S90>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal33'
 * '<S91>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal34'
 * '<S92>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal35'
 * '<S93>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal36'
 * '<S94>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal37'
 * '<S95>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal38'
 * '<S96>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal39'
 * '<S97>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal4'
 * '<S98>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal40'
 * '<S99>'  : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal41'
 * '<S100>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal42'
 * '<S101>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal43'
 * '<S102>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal44'
 * '<S103>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal45'
 * '<S104>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal46'
 * '<S105>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal47'
 * '<S106>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal48'
 * '<S107>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal49'
 * '<S108>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal5'
 * '<S109>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal50'
 * '<S110>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal51'
 * '<S111>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal52'
 * '<S112>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal53'
 * '<S113>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal54'
 * '<S114>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal55'
 * '<S115>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal56'
 * '<S116>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal57'
 * '<S117>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal58'
 * '<S118>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal59'
 * '<S119>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal6'
 * '<S120>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal7'
 * '<S121>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal8'
 * '<S122>' : 'app_Main100msMgr/app_Main100msMgr/BMS_VCU_To_GatewaySignals/COM_WriteSignal9'
 */
#endif                                 /* RTW_HEADER_app_Main100msMgr_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
