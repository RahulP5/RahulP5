/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main100msMgr_private.h
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Sat Mar 12 15:03:39 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#ifndef RTW_HEADER_app_Main100msMgr_private_h_
#define RTW_HEADER_app_Main100msMgr_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "app_Main100msMgr.h"

/* Includes for objects with custom storage classes. */
#include "rte.h"

extern void app_Main100msMgr_COM_ReadSignal(void);
extern void app_Main100msMgr_COM_ReadSignal1(void);
extern void app_Main100msMgr_COM_ReadSignal10(void);
extern void app_Main100msMgr_COM_ReadSignal11(void);
extern void app_Main100msMgr_COM_ReadSignal12(void);
extern void app_Main100msMgr_COM_ReadSignal13(void);
extern void app_Main100msMgr_COM_ReadSignal14(void);
extern void app_Main100msMgr_COM_ReadSignal15(void);
extern void app_Main100msMgr_COM_ReadSignal16(void);
extern void app_Main100msMgr_COM_ReadSignal17(void);
extern void app_Main100msMgr_COM_ReadSignal18(void);
extern void app_Main100msMgr_COM_ReadSignal19(void);
extern void app_Main100msMgr_COM_ReadSignal2(void);
extern void app_Main100msMgr_COM_ReadSignal20(void);
extern void app_Main100msMgr_COM_ReadSignal21(void);
extern void app_Main100msMgr_COM_ReadSignal22(void);
extern void app_Main100msMgr_COM_ReadSignal23(void);
extern void app_Main100msMgr_COM_ReadSignal24(void);
extern void app_Main100msMgr_COM_ReadSignal25(void);
extern void app_Main100msMgr_COM_ReadSignal26(void);
extern void app_Main100msMgr_COM_ReadSignal27(void);
extern void app_Main100msMgr_COM_ReadSignal28(void);
extern void app_Main100msMgr_COM_ReadSignal29(void);
extern void app_Main100msMgr_COM_ReadSignal3(void);
extern void app_Main100msMgr_COM_ReadSignal30(void);
extern void app_Main100msMgr_COM_ReadSignal31(void);
extern void app_Main100msMgr_COM_ReadSignal32(void);
extern void app_Main100msMgr_COM_ReadSignal33(void);
extern void app_Main100msMgr_COM_ReadSignal34(void);
extern void app_Main100msMgr_COM_ReadSignal35(void);
extern void app_Main100msMgr_COM_ReadSignal36(void);
extern void app_Main100msMgr_COM_ReadSignal37(void);
extern void app_Main100msMgr_COM_ReadSignal38(void);
extern void app_Main100msMgr_COM_ReadSignal39(void);
extern void app_Main100msMgr_COM_ReadSignal4(void);
extern void app_Main100msMgr_COM_ReadSignal40(void);
extern void app_Main100msMgr_COM_ReadSignal41(void);
extern void app_Main100msMgr_COM_ReadSignal42(void);
extern void app_Main100msMgr_COM_ReadSignal43(void);
extern void app_Main100msMgr_COM_ReadSignal44(void);
extern void app_Main100msMgr_COM_ReadSignal45(void);
extern void app_Main100msMgr_COM_ReadSignal46(void);
extern void app_Main100msMgr_COM_ReadSignal47(void);
extern void app_Main100msMgr_COM_ReadSignal48(void);
extern void app_Main100msMgr_COM_ReadSignal49(void);
extern void app_Main100msMgr_COM_ReadSignal5(void);
extern void app_Main100msMgr_COM_ReadSignal50(void);
extern void app_Main100msMgr_COM_ReadSignal51(void);
extern void app_Main100msMgr_COM_ReadSignal52(void);
extern void app_Main100msMgr_COM_ReadSignal53(void);
extern void app_Main100msMgr_COM_ReadSignal54(void);
extern void app_Main100msMgr_COM_ReadSignal55(void);
extern void app_Main100msMgr_COM_ReadSignal56(void);
extern void app_Main100msMgr_COM_ReadSignal57(void);
extern void app_Main100msMgr_COM_ReadSignal58(void);
extern void app_Main100msMgr_COM_ReadSignal59(void);
extern void app_Main100msMgr_COM_ReadSignal6(void);
extern void app_Main100msMgr_COM_ReadSignal7(void);
extern void app_Main100msMgr_COM_ReadSignal8(void);
extern void app_Main100msMgr_COM_ReadSignal9(void);
extern void app_Main100msMgr_COM_WriteSignal(void);
extern void app_Main100msMgr_COM_WriteSignal1(void);
extern void app_Main100msMgr_COM_WriteSignal10(void);
extern void app_Main100msMgr_COM_WriteSignal11(void);
extern void app_Main100msMgr_COM_WriteSignal12(void);
extern void app_Main100msMgr_COM_WriteSignal13(void);
extern void app_Main100msMgr_COM_WriteSignal14(void);
extern void app_Main100msMgr_COM_WriteSignal15(void);
extern void app_Main100msMgr_COM_WriteSignal16(void);
extern void app_Main100msMgr_COM_WriteSignal17(void);
extern void app_Main100msMgr_COM_WriteSignal18(void);
extern void app_Main100msMgr_COM_WriteSignal19(void);
extern void app_Main100msMgr_COM_WriteSignal2(void);
extern void app_Main100msMgr_COM_WriteSignal20(void);
extern void app_Main100msMgr_COM_WriteSignal21(void);
extern void app_Main100msMgr_COM_WriteSignal22(void);
extern void app_Main100msMgr_COM_WriteSignal23(void);
extern void app_Main100msMgr_COM_WriteSignal24(void);
extern void app_Main100msMgr_COM_WriteSignal25(void);
extern void app_Main100msMgr_COM_WriteSignal26(void);
extern void app_Main100msMgr_COM_WriteSignal27(void);
extern void app_Main100msMgr_COM_WriteSignal28(void);
extern void app_Main100msMgr_COM_WriteSignal29(void);
extern void app_Main100msMgr_COM_WriteSignal3(void);
extern void app_Main100msMgr_COM_WriteSignal30(void);
extern void app_Main100msMgr_COM_WriteSignal31(void);
extern void app_Main100msMgr_COM_WriteSignal32(void);
extern void app_Main100msMgr_COM_WriteSignal33(void);
extern void app_Main100msMgr_COM_WriteSignal34(void);
extern void app_Main100msMgr_COM_WriteSignal35(void);
extern void app_Main100msMgr_COM_WriteSignal36(void);
extern void app_Main100msMgr_COM_WriteSignal37(void);
extern void app_Main100msMgr_COM_WriteSignal38(void);
extern void app_Main100msMgr_COM_WriteSignal39(void);
extern void app_Main100msMgr_COM_WriteSignal4(void);
extern void app_Main100msMgr_COM_WriteSignal40(void);
extern void app_Main100msMgr_COM_WriteSignal41(void);
extern void app_Main100msMgr_COM_WriteSignal42(void);
extern void app_Main100msMgr_COM_WriteSignal43(void);
extern void app_Main100msMgr_COM_WriteSignal44(void);
extern void app_Main100msMgr_COM_WriteSignal45(void);
extern void app_Main100msMgr_COM_WriteSignal46(void);
extern void app_Main100msMgr_COM_WriteSignal47(void);
extern void app_Main100msMgr_COM_WriteSignal48(void);
extern void app_Main100msMgr_COM_WriteSignal49(void);
extern void app_Main100msMgr_COM_WriteSignal5(void);
extern void app_Main100msMgr_COM_WriteSignal50(void);
extern void app_Main100msMgr_COM_WriteSignal51(void);
extern void app_Main100msMgr_COM_WriteSignal52(void);
extern void app_Main100msMgr_COM_WriteSignal53(void);
extern void app_Main100msMgr_COM_WriteSignal54(void);
extern void app_Main100msMgr_COM_WriteSignal55(void);
extern void app_Main100msMgr_COM_WriteSignal56(void);
extern void app_Main100msMgr_COM_WriteSignal57(void);
extern void app_Main100msMgr_COM_WriteSignal58(void);
extern void app_Main100msMgr_COM_WriteSignal59(void);
extern void app_Main100msMgr_COM_WriteSignal6(void);
extern void app_Main100msMgr_COM_WriteSignal7(void);
extern void app_Main100msMgr_COM_WriteSignal8(void);
extern void app_Main100msMgr_COM_WriteSignal9(void);

#endif                                 /* RTW_HEADER_app_Main100msMgr_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
