/*
 * ***************************************************************************
 * ***************************************************************************
 * (C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.
 *
 * All data and information contained in or disclosed by this document is
 * confidential and proprietary information of Devise Electronics Pvt Ltd and all
 * rights therein are expressly reserved.  By accepting this material the
 * recipient agrees that this material and the information contained therein
 * is held in confidence and in trust and will not be used, copied, reproduced
 * in whole or in part, nor its contents revealed in any manner to others
 * without the express written permission of Devise Electronics Pvt Ltd
 *
 * Devise Electronics Pvt Ltd
 * Erandwane,
 * 411038, Pune,
 * India
 * E-mail: devcu@deviseelectronics.com
 *
 * File Name: app_Main100msMgr.c
 * Author: deVCU-TAPAS/Matlab/Simulink/Embedded Coder Generated
 * TAPAS Generation Date: Sat Mar 12 15:03:39 2022
 * ***************************************************************************
 * ***************************************************************************
 */

#include "app_Main100msMgr_capi.h"
#include "app_Main100msMgr.h"
#include "app_Main100msMgr_private.h"

/* user code (top of source file) */
#include "rte.h"

/* Block signals (auto storage) */
B_app_Main100msMgr_T app_Main100msMgr_B;

/* Real-time model */
RT_MODEL_app_Main100msMgr_T app_Main100msMgr_M_;
RT_MODEL_app_Main100msMgr_T *const app_Main100msMgr_M = &app_Main100msMgr_M_;

/* Output and update for atomic system: '<S2>/COM_ReadSignal' */
void app_Main100msMgr_COM_ReadSignal(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal' */

  /* S-Function Block: <S3>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h3 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bz1 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bz1 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal' */

  /* DataTypeConversion: '<S3>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_hp =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h3;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal1' */
void app_Main100msMgr_COM_ReadSignal1(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal1' */

  /* S-Function Block: <S4>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal1_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h5 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l5 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l5 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal1' */

  /* DataTypeConversion: '<S4>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_di =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h5;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal10' */
void app_Main100msMgr_COM_ReadSignal10(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal10' */

  /* S-Function Block: <S5>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal10_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hg = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ph = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ph = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal10' */

  /* DataTypeConversion: '<S5>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_pt =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hg;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal11' */
void app_Main100msMgr_COM_ReadSignal11(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal11' */

  /* S-Function Block: <S6>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal11_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dgj = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gi = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gi = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal11' */

  /* DataTypeConversion: '<S6>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_om =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dgj;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal12' */
void app_Main100msMgr_COM_ReadSignal12(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal12' */

  /* S-Function Block: <S7>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal12_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pd = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bz = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bz = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal12' */

  /* DataTypeConversion: '<S7>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_o1 =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pd;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal13' */
void app_Main100msMgr_COM_ReadSignal13(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal13' */

  /* S-Function Block: <S8>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal13_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ic = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_dl = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_dl = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal13' */

  /* DataTypeConversion: '<S8>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ca =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ic;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal14' */
void app_Main100msMgr_COM_ReadSignal14(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal14' */

  /* S-Function Block: <S9>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal14_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jm = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_i = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_i = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal14' */

  /* DataTypeConversion: '<S9>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_l2 =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jm;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal15' */
void app_Main100msMgr_COM_ReadSignal15(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal15' */

  /* S-Function Block: <S10>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal15_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ka = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oa = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oa = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal15' */

  /* DataTypeConversion: '<S10>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_fw =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ka;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal16' */
void app_Main100msMgr_COM_ReadSignal16(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal16' */

  /* S-Function Block: <S11>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal16_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pv = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_hg = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_hg = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal16' */

  /* DataTypeConversion: '<S11>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ory =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pv;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal17' */
void app_Main100msMgr_COM_ReadSignal17(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal17' */

  /* S-Function Block: <S12>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal17_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_fc = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ewv = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ewv = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal17' */

  /* DataTypeConversion: '<S12>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_hl =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_fc;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal18' */
void app_Main100msMgr_COM_ReadSignal18(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal18' */

  /* S-Function Block: <S13>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal18_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_lj = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_lu = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_lu = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal18' */

  /* DataTypeConversion: '<S13>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_cv =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_lj;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal19' */
void app_Main100msMgr_COM_ReadSignal19(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal19' */

  /* S-Function Block: <S14>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal19_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_o0 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kc = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kc = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal19' */

  /* DataTypeConversion: '<S14>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_me =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_o0;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal2' */
void app_Main100msMgr_COM_ReadSignal2(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal2' */

  /* S-Function Block: <S15>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal2_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kj = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ceu = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ceu = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal2' */

  /* DataTypeConversion: '<S15>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_jk =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kj;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal20' */
void app_Main100msMgr_COM_ReadSignal20(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal20' */

  /* S-Function Block: <S16>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal20_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kf = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_p5 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_p5 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal20' */

  /* DataTypeConversion: '<S16>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ap =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kf;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal21' */
void app_Main100msMgr_COM_ReadSignal21(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal21' */

  /* S-Function Block: <S17>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal21_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m3 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_eu = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_eu = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal21' */

  /* DataTypeConversion: '<S17>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_je =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m3;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal22' */
void app_Main100msMgr_COM_ReadSignal22(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal22' */

  /* S-Function Block: <S18>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal22_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cc = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bl = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bl = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal22' */

  /* DataTypeConversion: '<S18>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_dv =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cc;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal23' */
void app_Main100msMgr_COM_ReadSignal23(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal23' */

  /* S-Function Block: <S19>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal23_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m1 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ff = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ff = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal23' */

  /* DataTypeConversion: '<S19>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_mo =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m1;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal24' */
void app_Main100msMgr_COM_ReadSignal24(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal24' */

  /* S-Function Block: <S20>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal24_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ca = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gy = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gy = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal24' */

  /* DataTypeConversion: '<S20>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_kd =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ca;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal25' */
void app_Main100msMgr_COM_ReadSignal25(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal25' */

  /* S-Function Block: <S21>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal25_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_gn = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_al = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_al = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal25' */

  /* DataTypeConversion: '<S21>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_hr =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_gn;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal26' */
void app_Main100msMgr_COM_ReadSignal26(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal26' */

  /* S-Function Block: <S22>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal26_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j4 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_f0 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_f0 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal26' */

  /* DataTypeConversion: '<S22>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_iz =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j4;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal27' */
void app_Main100msMgr_COM_ReadSignal27(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal27' */

  /* S-Function Block: <S23>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal27_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_g = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ew = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ew = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal27' */

  /* DataTypeConversion: '<S23>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_cl =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_g;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal28' */
void app_Main100msMgr_COM_ReadSignal28(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal28' */

  /* S-Function Block: <S24>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal28_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_al = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ef = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ef = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal28' */

  /* DataTypeConversion: '<S24>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_gm =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_al;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal29' */
void app_Main100msMgr_COM_ReadSignal29(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal29' */

  /* S-Function Block: <S25>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal29_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pk = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_go = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_go = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal29' */

  /* DataTypeConversion: '<S25>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_or =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pk;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal3' */
void app_Main100msMgr_COM_ReadSignal3(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal3' */

  /* S-Function Block: <S26>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal3_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ag = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l4 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l4 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal3' */

  /* DataTypeConversion: '<S26>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_jl =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ag;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal30' */
void app_Main100msMgr_COM_ReadSignal30(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal30' */

  /* S-Function Block: <S27>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal30_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pn = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_fr = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_fr = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal30' */

  /* DataTypeConversion: '<S27>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_jq =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pn;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal31' */
void app_Main100msMgr_COM_ReadSignal31(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal31' */

  /* S-Function Block: <S28>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal31_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_lh = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ce = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ce = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal31' */

  /* DataTypeConversion: '<S28>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_pe =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_lh;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal32' */
void app_Main100msMgr_COM_ReadSignal32(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal32' */

  /* S-Function Block: <S29>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal32_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ai = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kv = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kv = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal32' */

  /* DataTypeConversion: '<S29>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ln =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ai;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal33' */
void app_Main100msMgr_COM_ReadSignal33(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal33' */

  /* S-Function Block: <S30>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal33_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_je = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oe = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oe = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal33' */

  /* DataTypeConversion: '<S30>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_cz =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_je;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal34' */
void app_Main100msMgr_COM_ReadSignal34(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal34' */

  /* S-Function Block: <S31>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal34_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kl = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_pc = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_pc = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal34' */

  /* DataTypeConversion: '<S31>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_nv =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kl;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal35' */
void app_Main100msMgr_COM_ReadSignal35(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal35' */

  /* S-Function Block: <S32>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal35_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_i5 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ev = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ev = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal35' */

  /* DataTypeConversion: '<S32>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_h4 =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_i5;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal36' */
void app_Main100msMgr_COM_ReadSignal36(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal36' */

  /* S-Function Block: <S33>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal36_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cj = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ea = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ea = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal36' */

  /* DataTypeConversion: '<S33>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_gp =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cj;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal37' */
void app_Main100msMgr_COM_ReadSignal37(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal37' */

  /* S-Function Block: <S34>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal37_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dg = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oo = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oo = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal37' */

  /* DataTypeConversion: '<S34>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ju =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dg;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal38' */
void app_Main100msMgr_COM_ReadSignal38(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal38' */

  /* S-Function Block: <S35>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal38_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_em = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bf = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_bf = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal38' */

  /* DataTypeConversion: '<S35>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_mv =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_em;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal39' */
void app_Main100msMgr_COM_ReadSignal39(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal39' */

  /* S-Function Block: <S36>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal39_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pp = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_e = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_e = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal39' */

  /* DataTypeConversion: '<S36>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_lq =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_pp;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal4' */
void app_Main100msMgr_COM_ReadSignal4(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal4' */

  /* S-Function Block: <S37>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal4_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_p = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_h = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_h = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal4' */

  /* DataTypeConversion: '<S37>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_kt =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_p;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal40' */
void app_Main100msMgr_COM_ReadSignal40(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal40' */

  /* S-Function Block: <S38>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal40_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_f = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_mg = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_mg = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal40' */

  /* DataTypeConversion: '<S38>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_jo =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_f;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal41' */
void app_Main100msMgr_COM_ReadSignal41(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal41' */

  /* S-Function Block: <S39>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal41_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_a = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_a = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal41' */

  /* DataTypeConversion: '<S39>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_nh =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_m;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal42' */
void app_Main100msMgr_COM_ReadSignal42(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal42' */

  /* S-Function Block: <S40>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal42_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_b = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ds = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ds = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal42' */

  /* DataTypeConversion: '<S40>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_dq =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_b;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal43' */
void app_Main100msMgr_COM_ReadSignal43(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal43' */

  /* S-Function Block: <S41>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal43_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_di = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oy = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_oy = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal43' */

  /* DataTypeConversion: '<S41>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_k =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_di;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal44' */
void app_Main100msMgr_COM_ReadSignal44(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal44' */

  /* S-Function Block: <S42>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal44_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hk = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ms = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ms = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal44' */

  /* DataTypeConversion: '<S42>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_id =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hk;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal45' */
void app_Main100msMgr_COM_ReadSignal45(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal45' */

  /* S-Function Block: <S43>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal45_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dy = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ne = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_ne = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal45' */

  /* DataTypeConversion: '<S43>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_f =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_dy;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal46' */
void app_Main100msMgr_COM_ReadSignal46(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal46' */

  /* S-Function Block: <S44>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal46_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_o = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_or = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_or = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal46' */

  /* DataTypeConversion: '<S44>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_m =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_o;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal47' */
void app_Main100msMgr_COM_ReadSignal47(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal47' */

  /* S-Function Block: <S45>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal47_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_d = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_b = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_b = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal47' */

  /* DataTypeConversion: '<S45>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_jd =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_d;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal48' */
void app_Main100msMgr_COM_ReadSignal48(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal48' */

  /* S-Function Block: <S46>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal48_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_eb = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kw = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_kw = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal48' */

  /* DataTypeConversion: '<S46>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ns =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_eb;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal49' */
void app_Main100msMgr_COM_ReadSignal49(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal49' */

  /* S-Function Block: <S47>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal49_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hm = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_k = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_k = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal49' */

  /* DataTypeConversion: '<S47>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_ep =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_hm;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal5' */
void app_Main100msMgr_COM_ReadSignal5(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal5' */

  /* S-Function Block: <S48>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal5_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j2 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_o = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_o = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal5' */

  /* DataTypeConversion: '<S48>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_j =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j2;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal50' */
void app_Main100msMgr_COM_ReadSignal50(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal50' */

  /* S-Function Block: <S49>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal50_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kt = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_j2 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_j2 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal50' */

  /* DataTypeConversion: '<S49>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_l =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_kt;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal51' */
void app_Main100msMgr_COM_ReadSignal51(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal51' */

  /* S-Function Block: <S50>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal51_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_i = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_c = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_c = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal51' */

  /* DataTypeConversion: '<S50>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_h =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_i;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal52' */
void app_Main100msMgr_COM_ReadSignal52(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal52' */

  /* S-Function Block: <S51>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal52_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ef = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_n = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_n = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal52' */

  /* DataTypeConversion: '<S51>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_c =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_ef;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal53' */
void app_Main100msMgr_COM_ReadSignal53(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal53' */

  /* S-Function Block: <S52>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal53_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_e = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_jp = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_jp = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal53' */

  /* DataTypeConversion: '<S52>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_n =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_e;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal54' */
void app_Main100msMgr_COM_ReadSignal54(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal54' */

  /* S-Function Block: <S53>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal54_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jo = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gd = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gd = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal54' */

  /* DataTypeConversion: '<S53>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_iy =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jo;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal55' */
void app_Main100msMgr_COM_ReadSignal55(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal55' */

  /* S-Function Block: <S54>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal55_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_j = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_j = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal55' */

  /* DataTypeConversion: '<S54>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_o =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_h;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal56' */
void app_Main100msMgr_COM_ReadSignal56(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal56' */

  /* S-Function Block: <S55>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal56_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jd = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_l = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal56' */

  /* DataTypeConversion: '<S55>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_i =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_jd;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal57' */
void app_Main100msMgr_COM_ReadSignal57(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal57' */

  /* S-Function Block: <S56>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal57_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_l = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gs = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_gs = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal57' */

  /* DataTypeConversion: '<S56>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_a =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_l;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal58' */
void app_Main100msMgr_COM_ReadSignal58(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal58' */

  /* S-Function Block: <S57>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal58_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_f = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_f = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal58' */

  /* DataTypeConversion: '<S57>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_gg =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_j;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal59' */
void app_Main100msMgr_COM_ReadSignal59(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal59' */

  /* S-Function Block: <S58>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal59_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cg = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_p = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_p = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal59' */

  /* DataTypeConversion: '<S58>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_g =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_cg;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal6' */
void app_Main100msMgr_COM_ReadSignal6(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal6' */

  /* S-Function Block: <S59>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal6_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_k = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_m = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_m = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal6' */

  /* DataTypeConversion: '<S59>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_p =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_k;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal7' */
void app_Main100msMgr_COM_ReadSignal7(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal7' */

  /* S-Function Block: <S60>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal7_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_a = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_g = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_g = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal7' */

  /* DataTypeConversion: '<S60>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_e =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_a;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal8' */
void app_Main100msMgr_COM_ReadSignal8(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal8' */

  /* S-Function Block: <S61>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal8_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_c = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_d = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2_d = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal8' */

  /* DataTypeConversion: '<S61>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion_d =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1_c;
}

/* Output and update for atomic system: '<S2>/COM_ReadSignal9' */
void app_Main100msMgr_COM_ReadSignal9(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal9' */

  /* S-Function Block: <S62>/TAPAS_COM_ReadSignal */
  /* Insert Comment Here */
  STATUS_t eStatus;
  float fltValue;
  eStatus = RTE_Service_COM_vdReadSignal((uint8_t)
    (app_Main100msMgr_P.COM_ReadSignal9_PARAM_ID-1), &fltValue);
  app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1 = fltValue;
  if (eStatus == STATUS_OK) {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2 = 1;
  } else {
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o2 = 0;
  }

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal9' */

  /* DataTypeConversion: '<S62>/Data Type Conversion' */
  app_Main100msMgr_B.DataTypeConversion =
    app_Main100msMgr_B.TAPAS_COM_ReadSignal_o1;
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal' */
void app_Main100msMgr_COM_WriteSignal(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal' */

  /* S-Function Block: <S63>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_hp);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal1' */
void app_Main100msMgr_COM_WriteSignal1(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal1' */

  /* S-Function Block: <S64>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal1_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_di);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal1' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal10' */
void app_Main100msMgr_COM_WriteSignal10(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal10' */

  /* S-Function Block: <S65>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal10_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_pt);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal10' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal11' */
void app_Main100msMgr_COM_WriteSignal11(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal11' */

  /* S-Function Block: <S66>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal11_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_om);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal11' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal12' */
void app_Main100msMgr_COM_WriteSignal12(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal12' */

  /* S-Function Block: <S67>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal12_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_o1);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal12' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal13' */
void app_Main100msMgr_COM_WriteSignal13(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal13' */

  /* S-Function Block: <S68>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal13_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ca);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal13' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal14' */
void app_Main100msMgr_COM_WriteSignal14(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal14' */

  /* S-Function Block: <S69>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal14_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_l2);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal14' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal15' */
void app_Main100msMgr_COM_WriteSignal15(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal15' */

  /* S-Function Block: <S70>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal15_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_fw);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal15' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal16' */
void app_Main100msMgr_COM_WriteSignal16(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal16' */

  /* S-Function Block: <S71>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal16_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ory);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal16' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal17' */
void app_Main100msMgr_COM_WriteSignal17(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal17' */

  /* S-Function Block: <S72>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal17_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_hl);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal17' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal18' */
void app_Main100msMgr_COM_WriteSignal18(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal18' */

  /* S-Function Block: <S73>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal18_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_cv);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal18' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal19' */
void app_Main100msMgr_COM_WriteSignal19(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal19' */

  /* S-Function Block: <S74>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal19_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_me);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal19' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal2' */
void app_Main100msMgr_COM_WriteSignal2(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal2' */

  /* S-Function Block: <S75>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal2_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_jk);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal2' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal20' */
void app_Main100msMgr_COM_WriteSignal20(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal20' */

  /* S-Function Block: <S76>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal20_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ap);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal20' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal21' */
void app_Main100msMgr_COM_WriteSignal21(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal21' */

  /* S-Function Block: <S77>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal21_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_je);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal21' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal22' */
void app_Main100msMgr_COM_WriteSignal22(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal22' */

  /* S-Function Block: <S78>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal22_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_dv);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal22' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal23' */
void app_Main100msMgr_COM_WriteSignal23(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal23' */

  /* S-Function Block: <S79>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal23_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_mo);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal23' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal24' */
void app_Main100msMgr_COM_WriteSignal24(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal24' */

  /* S-Function Block: <S80>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal24_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_kd);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal24' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal25' */
void app_Main100msMgr_COM_WriteSignal25(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal25' */

  /* S-Function Block: <S81>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal25_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_hr);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal25' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal26' */
void app_Main100msMgr_COM_WriteSignal26(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal26' */

  /* S-Function Block: <S82>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal26_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_iz);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal26' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal27' */
void app_Main100msMgr_COM_WriteSignal27(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal27' */

  /* S-Function Block: <S83>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal27_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_cl);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal27' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal28' */
void app_Main100msMgr_COM_WriteSignal28(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal28' */

  /* S-Function Block: <S84>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal28_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_gm);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal28' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal29' */
void app_Main100msMgr_COM_WriteSignal29(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal29' */

  /* S-Function Block: <S85>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal29_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_or);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal29' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal3' */
void app_Main100msMgr_COM_WriteSignal3(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal3' */

  /* S-Function Block: <S86>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal3_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_jl);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal3' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal30' */
void app_Main100msMgr_COM_WriteSignal30(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal30' */

  /* S-Function Block: <S87>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal30_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_jq);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal30' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal31' */
void app_Main100msMgr_COM_WriteSignal31(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal31' */

  /* S-Function Block: <S88>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal31_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_pe);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal31' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal32' */
void app_Main100msMgr_COM_WriteSignal32(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal32' */

  /* S-Function Block: <S89>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal32_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ln);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal32' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal33' */
void app_Main100msMgr_COM_WriteSignal33(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal33' */

  /* S-Function Block: <S90>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal33_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_cz);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal33' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal34' */
void app_Main100msMgr_COM_WriteSignal34(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal34' */

  /* S-Function Block: <S91>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal34_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_nv);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal34' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal35' */
void app_Main100msMgr_COM_WriteSignal35(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal35' */

  /* S-Function Block: <S92>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal35_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_h4);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal35' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal36' */
void app_Main100msMgr_COM_WriteSignal36(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal36' */

  /* S-Function Block: <S93>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal36_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_gp);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal36' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal37' */
void app_Main100msMgr_COM_WriteSignal37(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal37' */

  /* S-Function Block: <S94>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal37_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ju);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal37' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal38' */
void app_Main100msMgr_COM_WriteSignal38(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal38' */

  /* S-Function Block: <S95>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal38_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_mv);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal38' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal39' */
void app_Main100msMgr_COM_WriteSignal39(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal39' */

  /* S-Function Block: <S96>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal39_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_lq);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal39' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal4' */
void app_Main100msMgr_COM_WriteSignal4(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal4' */

  /* S-Function Block: <S97>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal4_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_kt);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal4' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal40' */
void app_Main100msMgr_COM_WriteSignal40(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal40' */

  /* S-Function Block: <S98>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal40_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_jo);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal40' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal41' */
void app_Main100msMgr_COM_WriteSignal41(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal41' */

  /* S-Function Block: <S99>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal41_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_nh);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal41' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal42' */
void app_Main100msMgr_COM_WriteSignal42(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal42' */

  /* S-Function Block: <S100>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal42_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_dq);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal42' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal43' */
void app_Main100msMgr_COM_WriteSignal43(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal43' */

  /* S-Function Block: <S101>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal43_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_k);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal43' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal44' */
void app_Main100msMgr_COM_WriteSignal44(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal44' */

  /* S-Function Block: <S102>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal44_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_id);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal44' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal45' */
void app_Main100msMgr_COM_WriteSignal45(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal45' */

  /* S-Function Block: <S103>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal45_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_f);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal45' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal46' */
void app_Main100msMgr_COM_WriteSignal46(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal46' */

  /* S-Function Block: <S104>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal46_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_m);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal46' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal47' */
void app_Main100msMgr_COM_WriteSignal47(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal47' */

  /* S-Function Block: <S105>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal47_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_jd);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal47' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal48' */
void app_Main100msMgr_COM_WriteSignal48(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal48' */

  /* S-Function Block: <S106>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal48_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ns);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal48' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal49' */
void app_Main100msMgr_COM_WriteSignal49(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal49' */

  /* S-Function Block: <S107>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal49_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_ep);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal49' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal5' */
void app_Main100msMgr_COM_WriteSignal5(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal5' */

  /* S-Function Block: <S108>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal5_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_j);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal5' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal50' */
void app_Main100msMgr_COM_WriteSignal50(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal50' */

  /* S-Function Block: <S109>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal50_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_l);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal50' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal51' */
void app_Main100msMgr_COM_WriteSignal51(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal51' */

  /* S-Function Block: <S110>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal51_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_h);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal51' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal52' */
void app_Main100msMgr_COM_WriteSignal52(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal52' */

  /* S-Function Block: <S111>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal52_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_c);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal52' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal53' */
void app_Main100msMgr_COM_WriteSignal53(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal53' */

  /* S-Function Block: <S112>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal53_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_n);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal53' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal54' */
void app_Main100msMgr_COM_WriteSignal54(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal54' */

  /* S-Function Block: <S113>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal54_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_iy);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal54' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal55' */
void app_Main100msMgr_COM_WriteSignal55(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal55' */

  /* S-Function Block: <S114>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal55_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_o);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal55' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal56' */
void app_Main100msMgr_COM_WriteSignal56(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal56' */

  /* S-Function Block: <S115>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal56_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_i);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal56' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal57' */
void app_Main100msMgr_COM_WriteSignal57(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal57' */

  /* S-Function Block: <S116>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal57_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_a);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal57' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal58' */
void app_Main100msMgr_COM_WriteSignal58(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal58' */

  /* S-Function Block: <S117>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal58_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_gg);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal58' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal59' */
void app_Main100msMgr_COM_WriteSignal59(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal59' */

  /* S-Function Block: <S118>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal59_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_g);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal59' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal6' */
void app_Main100msMgr_COM_WriteSignal6(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal6' */

  /* S-Function Block: <S119>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal6_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_p);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal6' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal7' */
void app_Main100msMgr_COM_WriteSignal7(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal7' */

  /* S-Function Block: <S120>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal7_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_e);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal7' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal8' */
void app_Main100msMgr_COM_WriteSignal8(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal8' */

  /* S-Function Block: <S121>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal8_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion_d);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal8' */
}

/* Output and update for atomic system: '<S2>/COM_WriteSignal9' */
void app_Main100msMgr_COM_WriteSignal9(void)
{
  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal9' */

  /* S-Function Block: <S122>/TAPAS_COM_WriteSignal */
  /* Insert Comment Here */
  RTE_Service_COM_vdWriteSignal((uint8_t)
    (app_Main100msMgr_P.COM_WriteSignal9_PARAM_ID-1),
    app_Main100msMgr_B.DataTypeConversion);

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal9' */
}

/* Model step function for TID1 */
void app_Main100msMgr_fcn(void)        /* Sample time: [0.1s, 0.0s] */
{
  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main100msMgr_fcn_at_outport_1' incorporates:
   *  SubSystem: '<Root>/app_Main100msMgr'
   */
  /* Inport: '<S1>/APP_100MS_IN1' incorporates:
   *  Inport: '<Root>/APP_100MS_IN1'
   */
  RTE_Write_APP_100MS_OUT1(RTE_Read_APP_100MS_IN1());

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal' */
  app_Main100msMgr_COM_ReadSignal();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal' */
  app_Main100msMgr_COM_WriteSignal();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal1' */
  app_Main100msMgr_COM_ReadSignal1();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal1' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal1' */
  app_Main100msMgr_COM_WriteSignal1();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal1' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal10' */
  app_Main100msMgr_COM_ReadSignal10();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal10' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal10' */
  app_Main100msMgr_COM_WriteSignal10();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal10' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal11' */
  app_Main100msMgr_COM_ReadSignal11();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal11' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal11' */
  app_Main100msMgr_COM_WriteSignal11();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal11' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal12' */
  app_Main100msMgr_COM_ReadSignal12();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal12' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal12' */
  app_Main100msMgr_COM_WriteSignal12();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal12' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal13' */
  app_Main100msMgr_COM_ReadSignal13();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal13' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal13' */
  app_Main100msMgr_COM_WriteSignal13();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal13' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal14' */
  app_Main100msMgr_COM_ReadSignal14();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal14' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal14' */
  app_Main100msMgr_COM_WriteSignal14();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal14' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal15' */
  app_Main100msMgr_COM_ReadSignal15();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal15' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal15' */
  app_Main100msMgr_COM_WriteSignal15();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal15' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal16' */
  app_Main100msMgr_COM_ReadSignal16();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal16' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal16' */
  app_Main100msMgr_COM_WriteSignal16();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal16' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal17' */
  app_Main100msMgr_COM_ReadSignal17();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal17' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal17' */
  app_Main100msMgr_COM_WriteSignal17();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal17' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal18' */
  app_Main100msMgr_COM_ReadSignal18();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal18' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal18' */
  app_Main100msMgr_COM_WriteSignal18();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal18' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal19' */
  app_Main100msMgr_COM_ReadSignal19();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal19' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal19' */
  app_Main100msMgr_COM_WriteSignal19();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal19' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal2' */
  app_Main100msMgr_COM_ReadSignal2();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal2' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal2' */
  app_Main100msMgr_COM_WriteSignal2();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal2' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal20' */
  app_Main100msMgr_COM_ReadSignal20();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal20' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal20' */
  app_Main100msMgr_COM_WriteSignal20();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal20' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal21' */
  app_Main100msMgr_COM_ReadSignal21();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal21' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal21' */
  app_Main100msMgr_COM_WriteSignal21();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal21' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal22' */
  app_Main100msMgr_COM_ReadSignal22();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal22' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal22' */
  app_Main100msMgr_COM_WriteSignal22();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal22' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal23' */
  app_Main100msMgr_COM_ReadSignal23();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal23' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal23' */
  app_Main100msMgr_COM_WriteSignal23();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal23' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal24' */
  app_Main100msMgr_COM_ReadSignal24();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal24' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal24' */
  app_Main100msMgr_COM_WriteSignal24();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal24' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal25' */
  app_Main100msMgr_COM_ReadSignal25();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal25' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal25' */
  app_Main100msMgr_COM_WriteSignal25();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal25' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal26' */
  app_Main100msMgr_COM_ReadSignal26();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal26' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal26' */
  app_Main100msMgr_COM_WriteSignal26();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal26' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal27' */
  app_Main100msMgr_COM_ReadSignal27();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal27' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal27' */
  app_Main100msMgr_COM_WriteSignal27();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal27' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal28' */
  app_Main100msMgr_COM_ReadSignal28();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal28' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal28' */
  app_Main100msMgr_COM_WriteSignal28();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal28' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal29' */
  app_Main100msMgr_COM_ReadSignal29();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal29' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal29' */
  app_Main100msMgr_COM_WriteSignal29();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal29' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal3' */
  app_Main100msMgr_COM_ReadSignal3();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal3' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal3' */
  app_Main100msMgr_COM_WriteSignal3();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal3' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal30' */
  app_Main100msMgr_COM_ReadSignal30();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal30' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal30' */
  app_Main100msMgr_COM_WriteSignal30();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal30' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal31' */
  app_Main100msMgr_COM_ReadSignal31();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal31' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal31' */
  app_Main100msMgr_COM_WriteSignal31();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal31' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal32' */
  app_Main100msMgr_COM_ReadSignal32();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal32' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal32' */
  app_Main100msMgr_COM_WriteSignal32();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal32' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal33' */
  app_Main100msMgr_COM_ReadSignal33();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal33' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal33' */
  app_Main100msMgr_COM_WriteSignal33();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal33' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal34' */
  app_Main100msMgr_COM_ReadSignal34();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal34' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal34' */
  app_Main100msMgr_COM_WriteSignal34();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal34' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal35' */
  app_Main100msMgr_COM_ReadSignal35();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal35' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal35' */
  app_Main100msMgr_COM_WriteSignal35();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal35' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal36' */
  app_Main100msMgr_COM_ReadSignal36();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal36' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal36' */
  app_Main100msMgr_COM_WriteSignal36();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal36' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal37' */
  app_Main100msMgr_COM_ReadSignal37();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal37' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal37' */
  app_Main100msMgr_COM_WriteSignal37();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal37' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal38' */
  app_Main100msMgr_COM_ReadSignal38();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal38' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal38' */
  app_Main100msMgr_COM_WriteSignal38();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal38' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal39' */
  app_Main100msMgr_COM_ReadSignal39();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal39' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal39' */
  app_Main100msMgr_COM_WriteSignal39();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal39' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal4' */
  app_Main100msMgr_COM_ReadSignal4();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal4' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal4' */
  app_Main100msMgr_COM_WriteSignal4();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal4' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal40' */
  app_Main100msMgr_COM_ReadSignal40();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal40' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal40' */
  app_Main100msMgr_COM_WriteSignal40();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal40' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal41' */
  app_Main100msMgr_COM_ReadSignal41();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal41' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal41' */
  app_Main100msMgr_COM_WriteSignal41();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal41' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal42' */
  app_Main100msMgr_COM_ReadSignal42();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal42' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal42' */
  app_Main100msMgr_COM_WriteSignal42();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal42' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal43' */
  app_Main100msMgr_COM_ReadSignal43();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal43' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal43' */
  app_Main100msMgr_COM_WriteSignal43();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal43' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal44' */
  app_Main100msMgr_COM_ReadSignal44();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal44' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal44' */
  app_Main100msMgr_COM_WriteSignal44();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal44' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal45' */
  app_Main100msMgr_COM_ReadSignal45();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal45' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal45' */
  app_Main100msMgr_COM_WriteSignal45();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal45' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal46' */
  app_Main100msMgr_COM_ReadSignal46();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal46' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal46' */
  app_Main100msMgr_COM_WriteSignal46();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal46' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal47' */
  app_Main100msMgr_COM_ReadSignal47();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal47' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal47' */
  app_Main100msMgr_COM_WriteSignal47();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal47' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal48' */
  app_Main100msMgr_COM_ReadSignal48();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal48' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal48' */
  app_Main100msMgr_COM_WriteSignal48();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal48' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal49' */
  app_Main100msMgr_COM_ReadSignal49();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal49' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal49' */
  app_Main100msMgr_COM_WriteSignal49();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal49' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal5' */
  app_Main100msMgr_COM_ReadSignal5();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal5' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal5' */
  app_Main100msMgr_COM_WriteSignal5();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal5' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal50' */
  app_Main100msMgr_COM_ReadSignal50();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal50' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal50' */
  app_Main100msMgr_COM_WriteSignal50();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal50' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal51' */
  app_Main100msMgr_COM_ReadSignal51();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal51' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal51' */
  app_Main100msMgr_COM_WriteSignal51();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal51' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal52' */
  app_Main100msMgr_COM_ReadSignal52();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal52' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal52' */
  app_Main100msMgr_COM_WriteSignal52();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal52' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal53' */
  app_Main100msMgr_COM_ReadSignal53();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal53' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal53' */
  app_Main100msMgr_COM_WriteSignal53();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal53' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal54' */
  app_Main100msMgr_COM_ReadSignal54();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal54' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal54' */
  app_Main100msMgr_COM_WriteSignal54();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal54' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal55' */
  app_Main100msMgr_COM_ReadSignal55();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal55' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal55' */
  app_Main100msMgr_COM_WriteSignal55();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal55' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal56' */
  app_Main100msMgr_COM_ReadSignal56();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal56' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal56' */
  app_Main100msMgr_COM_WriteSignal56();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal56' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal57' */
  app_Main100msMgr_COM_ReadSignal57();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal57' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal57' */
  app_Main100msMgr_COM_WriteSignal57();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal57' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal58' */
  app_Main100msMgr_COM_ReadSignal58();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal58' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal58' */
  app_Main100msMgr_COM_WriteSignal58();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal58' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal59' */
  app_Main100msMgr_COM_ReadSignal59();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal59' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal59' */
  app_Main100msMgr_COM_WriteSignal59();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal59' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal6' */
  app_Main100msMgr_COM_ReadSignal6();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal6' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal6' */
  app_Main100msMgr_COM_WriteSignal6();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal6' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal7' */
  app_Main100msMgr_COM_ReadSignal7();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal7' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal7' */
  app_Main100msMgr_COM_WriteSignal7();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal7' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal8' */
  app_Main100msMgr_COM_ReadSignal8();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal8' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal8' */
  app_Main100msMgr_COM_WriteSignal8();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal8' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_ReadSignal9' */
  app_Main100msMgr_COM_ReadSignal9();

  /* End of Outputs for SubSystem: '<S2>/COM_ReadSignal9' */

  /* Outputs for Atomic SubSystem: '<S2>/COM_WriteSignal9' */
  app_Main100msMgr_COM_WriteSignal9();

  /* End of Outputs for SubSystem: '<S2>/COM_WriteSignal9' */

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main100msMgr_fcn_at_outport_1' */
}

/* Model initialize function */
void app_Main100msMgr_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)app_Main100msMgr_M, 0,
                sizeof(RT_MODEL_app_Main100msMgr_T));

  /* block I/O */
  (void) memset(((void *) &app_Main100msMgr_B), 0,
                sizeof(B_app_Main100msMgr_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  app_Main100msMgr_InitializeDataMapInfo(app_Main100msMgr_M);

  /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main100msMgr_fcn_at_outport_1' incorporates:
   *  SystemInitialize for SubSystem: '<Root>/app_Main100msMgr'
   */
  /* SystemInitialize for Outport: '<S1>/APP_100MS_OUT1' */
  RTE_Write_APP_100MS_OUT1(app_Main100msMgr_P.APP_100MS_OUT1_Y0);

  /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_app_Main100msMgr_fcn_at_outport_1' */
}

/* Model terminate function */
void app_Main100msMgr_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
