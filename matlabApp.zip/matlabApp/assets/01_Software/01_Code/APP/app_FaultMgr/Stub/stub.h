#ifndef STUB_H

#define STUB_H

#include "lib_types.h"

uint8_t ECU_MEM_INT_eWriteSignalValue(uint8_t u8SignalID, float fltValue, #ifndef STUB_H

#define STUB_H

#include "lib_types.h"

uint8_t ECU_MEM_INT_eWriteSignalValue(uint8_t u8SignalID, float fltValue, uint32_t u32Value);

#endif /*STUB_H*/

