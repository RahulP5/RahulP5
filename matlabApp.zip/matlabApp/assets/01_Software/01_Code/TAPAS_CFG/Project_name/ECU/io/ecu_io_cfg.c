/*
***************************************************************************
***************************************************************************
(C) 2020-2021 Devise Electronics Pvt Ltd All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_io_cfg.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/


#include "ecu_io_cfg.h"
#include "ecu_io.h"
#include "uc.h"

ECU_IO_strPwmObj_t ECU_IO_astrPwmObjInput[ECU_IO_PIN_NUM] =
{
  {
    /*PWM Object Id */
    Noname_Pin_P56,
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_PIN_ID_0,    
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,          
    /*Frequency Value*/
    TAPAS_DEFAULT,
    /*DutyCycle Value*/
    (float)TAPAS_DEFAULT,    
  },
  {
    /*PWM Object Id */
    Noname_Pin_P66,
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_PIN_ID_1,    
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,          
    /*Frequency Value*/
    TAPAS_DEFAULT,
    /*DutyCycle Value*/
    (float)TAPAS_DEFAULT,    
  },
};

ECU_IO_strPwmObj_t ECU_IO_astrPwmObjOutput[ECU_IO_POUT_NUM] = 
{
  {
    /*PWM Object Id*/
    MOTCOOLGPMP_P59,
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_POUT_ID_0 ,
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,    	
    /*Frequency Value*/
    ECU_IO_POUT_MOTCOOLGPMP_P59_DEFAULT_FREQ,
    /*DutyCycle Value*/
    ECU_IO_POUT_MOTCOOLGPMP_P59_DEFAULT_DUTY
  },
  {
    /*PWM Object Id*/
    Noname_Pin_P23,
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_POUT_ID_1,
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,    	
    /*Frequency Value*/
    ECU_IO_POUT_Noname_Pin_P23_DEFAULT_FREQ,
    /*DutyCycle Value*/
    ECU_IO_POUT_Noname_Pin_P23_DEFAULT_DUTY
  },
};

ECU_IO_strObj_t ECU_IO_astrObjInput[ECU_IO_DIN_NUM] = 
{
  {
    /*DIO Object Id*/
    Noname_Pin_P07,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID0        ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P08,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID1        ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P11,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID6          ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P12,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID10,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_KEY_START_DI_P13,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID15,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_PARK_BRAKESW_P25,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID3,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Neutral_IO_P27,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID4,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P28,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID5,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_DRIVE_IO_P29,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID7,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Reverse_IO_P30,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID2,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_KEY_ACC_DI_P32,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID16,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P35,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID11,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    McuDtcClr_P36,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID13,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Brake_Sw_IO_P38,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID12,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P52,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID8,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    ChargeActiveSignal_P53,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID14,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P54,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID9,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P55,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID17,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P61,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID18,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
};

ECU_IO_strObj_t ECU_IO_astrObjOutput[ECU_IO_DOUT_NUM] = 
{
  {
    /*DIO Object Id*/
    VHCL_AUX_MODE_RLY_P15,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO7  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P16,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO24 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Park_LED_P17,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO9  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Drive_LED_P20,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO6  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Reverse_LED_P21,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO20 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Neutral_LED_P22,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO8  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACChiller_P24,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO23 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACConden_P33,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO10 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACEvapValv_P34,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO11 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VhclRevLight_IO_P40,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO21 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Brake_LED_P16,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO22 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    KL15Signal_P42,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO12 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    KL30Signal_Switch_P43,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO13 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    RadrRly_P44,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO14 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P78,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO5  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
};

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        /*
***************************************************************************
***************************************************************************
(C) 2020-2021 Devise Electronics Pvt Ltd All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_io_cfg.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/


#include "ecu_io_cfg.h"
#include "ecu_io.h"
#include "uc.h"

ECU_IO_strPwmObj_t ECU_IO_astrPwmObjInput[ECU_IO_PIN_NUM] =
{
  {
    /*PWM Object Id */
    Noname_Pin_P56,
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_PIN_ID_0,    
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,          
    /*Frequency Value*/
    TAPAS_DEFAULT,
    /*DutyCycle Value*/
    (float)TAPAS_DEFAULT,    
  },
  {
    /*PWM Object Id */
    Noname_Pin_P66,
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_PIN_ID_1,    
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,          
    /*Frequency Value*/
    TAPAS_DEFAULT,
    /*DutyCycle Value*/
    (float)TAPAS_DEFAULT,    
  },
};

ECU_IO_strPwmObj_t ECU_IO_astrPwmObjOutput[ECU_IO_POUT_NUM] = 
{
  {
    /*PWM Object Id*/
    MOTCOOLGPMP_P59,
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_POUT_ID_0 ,
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,    	
    /*Frequency Value*/
    ECU_IO_POUT_MOTCOOLGPMP_P59_DEFAULT_FREQ,
    /*DutyCycle Value*/
    ECU_IO_POUT_MOTCOOLGPMP_P59_DEFAULT_DUTY
  },
  {
    /*PWM Object Id*/
    Noname_Pin_P23,
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*DIO Pin Id = Lower Layer Id */
    UC_PWM_POUT_ID_1,
    /*Under Tester Control*/
    TAPAS_FALSE,
    /*Tester Freeze Command*/
    TAPAS_FALSE,
    /*Tester Controlled Frequency*/
    TAPAS_DEFAULT,
    /*Tester Controlled Duty Cycle*/
    TAPAS_DEFAULT,    	
    /*Frequency Value*/
    ECU_IO_POUT_Noname_Pin_P23_DEFAULT_FREQ,
    /*DutyCycle Value*/
    ECU_IO_POUT_Noname_Pin_P23_DEFAULT_DUTY
  },
};

ECU_IO_strObj_t ECU_IO_astrObjInput[ECU_IO_DIN_NUM] = 
{
  {
    /*DIO Object Id*/
    Noname_Pin_P07,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID0        ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P08,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID1        ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P11,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID6          ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P12,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID10,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_KEY_START_DI_P13,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID15,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_PARK_BRAKESW_P25,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID3,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Neutral_IO_P27,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID4,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P28,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID5,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_DRIVE_IO_P29,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID7,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Reverse_IO_P30,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID2,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_KEY_ACC_DI_P32,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID16,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P35,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID11,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    McuDtcClr_P36,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID13,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VCU_Brake_Sw_IO_P38,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID12,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P52,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID8,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    ChargeActiveSignal_P53,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID14,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P54,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_VBAT,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID9,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P55,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID17,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P61,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,    
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,     
    /*Tester Controlled Value*/
    TAPAS_DEFAULT,  
    /*Direction*/
    ECU_IO_DIR_INPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_MAXIM_CHIP,
    /*States ID*/
    ECU_IO_SWITCH_OC_GND,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    ECU_IO_MAXIM_PIN_ID18,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_ENABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
};

ECU_IO_strObj_t ECU_IO_astrObjOutput[ECU_IO_DOUT_NUM] = 
{
  {
    /*DIO Object Id*/
    VHCL_AUX_MODE_RLY_P15,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO7  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P16,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO24 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Park_LED_P17,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO9  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Drive_LED_P20,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO6  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Reverse_LED_P21,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO20 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Neutral_LED_P22,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO8  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACChiller_P24,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO23 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACConden_P33,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO10 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    HVACEvapValv_P34,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO11 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    VhclRevLight_IO_P40,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO21 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Brake_LED_P16,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO22 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    KL15Signal_P42,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO12 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    KL30Signal_Switch_P43,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO13 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    RadrRly_P44,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO14 ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
  {
    /*DIO Object Id*/
    Noname_Pin_P78,
    /*Pin Current State*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,   
    /*Under Tester Control*/
    TAPAS_FALSE, 
    /*Tester Freeze Command*/
    TAPAS_DEFAULT,    
    /*Tester Controlled Command*/
    (UC_DIO_eOutputCommand_t)TAPAS_DEFAULT,       
    /*Tester Controlled Value*/
    TAPAS_DEFAULT, 
    /*Direction*/
    ECU_IO_DIR_OUTPUT,
    /*Active Type*/
    ECU_IO_ACTIVE_HIGH,
    /*Module Type*/
    ECU_IO_TYPE_CORE_DIO,
    /*States ID*/
    ECU_IO_SWITCH_0V_3V3,
    /*DIO Pin Id = Lower Layer Id or External Chip Pin Id*/
    UC_DIO_OUTPUT_GIO5  ,
    /*Value*/
    TAPAS_DEFAULT,
    /*Event Callback Enable*/
    ECU_IO_CLBK_DISABLE,
    /*Event Type*/
    ECU_IO_EVENT_NA,
    /*Event Callback*/
    TAPAS_NULL,
  },
};

