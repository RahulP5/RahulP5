/*
***************************************************************************
***************************************************************************
(C) 2016 SIGRA Technologies GmbH  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_com_cfg_gen.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/

#include "uc.h"
#include "ecu_com.h"
#include "ecu_com_cfg_gen.h"


/*********** NETWORK 1 ***********/
ECU_COM_strMsg_t ECU_COM_astrRx1Msg[ECU_COM_RX1_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX1_MSG_INDEX_1,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAUL/*
***************************************************************************
***************************************************************************
(C) 2016 SIGRA Technologies GmbH  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_com_cfg_gen.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/

#include "uc.h"
#include "ecu_com.h"
#include "ecu_com_cfg_gen.h"


/*********** NETWORK 1 ***********/
ECU_COM_strMsg_t ECU_COM_astrRx1Msg[ECU_COM_RX1_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX1_MSG_INDEX_1,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX1_MSG_INDEX_2,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX1_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		MCU_VCU_SIGNAL_1_RX,
        /*Can Msg Id*/
		0x11C,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX1_MSG_INDEX_4,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strMsg_t ECU_COM_astrTx1Msg[ECU_COM_TX1_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x7E3,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_1,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x5A5,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_2,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_4,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x5A8,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_5,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x5A4,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_6,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_MCU_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x212,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX1_MSG_INDEX_7,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strSignal_t ECU_COM_astrRx1Signal[ECU_COM_RX1_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		CR_MCU_MOTESTTQ_PC,
        /*Frame Id*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*Size*/
		12,
        /*Mask*/
		4095,
        /*MSB number*/
		11,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.048828,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MOTDEFACT_PC,
        /*Frame Id*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.3906,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MOTACTROTSPD_RPM,
        /*Frame Id*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MG1RADFANREQ_DUTY,
        /*Frame Id*/
		MCU_VCU_SIGNAL_4_RX,
        /*Can Msg Id*/
		0x2A1,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_VCRM_MOTACTROTSPD_RPM,
        /*Frame Id*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_VCRM_EWPSPDREQ_RPM,
        /*Frame Id*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_VCRM_MOTESTTQ_PC,
        /*Frame Id*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_VCRM_MOTDEFACT_PC,
        /*Frame Id*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_GEN_POWER_WH,
        /*Frame Id*/
		MCU_VCU_SIGNAL_3_RX,
        /*Can Msg Id*/
		0x5EC,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_MCU_MG1WRN,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		1,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_MCU_MG1FLT,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		0,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MOTROTORTEMP_C,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MG1IGBTTEMP_C,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MG1INVTEMP_C,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MCU_MOTTEMP_C,
        /*Frame Id*/
		MCU_VCU_SIGNAL_2_RX,
        /*Can Msg Id*/
		0x533,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_EPARK_FS_ACT,
        /*Frame Id*/
		MCU_VCU_SIGNAL_1_RX,
        /*Can Msg Id*/
		0x11C,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_EPARK_INHIBIT,
        /*Frame Id*/
		MCU_VCU_SIGNAL_1_RX,
        /*Can Msg Id*/
		0x11C,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		11,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_EPARK_PARKPOSSTS,
        /*Frame Id*/
		MCU_VCU_SIGNAL_1_RX,
        /*Can Msg Id*/
		0x11C,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		1,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


ECU_COM_strSignal_t ECU_COM_astrTx1Signal[ECU_COM_TX1_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		MCUDTCCLR,
        /*Frame Id*/
		VCU_MCU_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x7E3,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_PRECHGSTATUS,
        /*Frame Id*/
		VCU_MCU_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x5A5,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		8,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_CHARGECYCLE,
        /*Frame Id*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		25,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_EVRDY,
        /*Frame Id*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		45,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_VEH_DC,
        /*Frame Id*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		40,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_WARMUPCYC,
        /*Frame Id*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		41,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_VCU_TQSTD_NM,
        /*Frame Id*/
		VCU_MCU_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x210,
        /*Size*/
		6,
        /*Mask*/
		63,
        /*MSB number*/
		54,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		10,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VCU_EWPSPDMAXREQ_RPM,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		20,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_WAKEUPREQ,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		8,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_HVINTLOCK_REQ,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		9,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_3WAYVALINHIBIT,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		52,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_EWPFORCEDOPER,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		53,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_EWPCOOLANTDIAGENB,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		54,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_EWPCOOLANTDISP,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_CANCHECKSUM,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		4,
        /*Mask*/
		15,
        /*MSB number*/
		59,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_ALIVECOUNT,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		61,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_PARKCMD,
        /*Frame Id*/
		VCU_MCU_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x119,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MOTPWMONREQ,
        /*Frame Id*/
		VCU_MCU_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x5A8,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		17,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_BMS_MAINRLYONSTAT,
        /*Frame Id*/
		VCU_MCU_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x5A4,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		34,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_MOTPWRENA,
        /*Frame Id*/
		VCU_MCU_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x212,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		1,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_PGMRUN3_ALIVECOUNTER,
        /*Frame Id*/
		VCU_MCU_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x212,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		6,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_VCU_MOTTQCMD_PC,
        /*Frame Id*/
		VCU_MCU_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x212,
        /*Size*/
		12,
        /*Mask*/
		4095,
        /*MSB number*/
		19,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.048828,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CF_VCU_MSGCHKSUM3,
        /*Frame Id*/
		VCU_MCU_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x212,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


/*********** NETWORK 2 ***********/
ECU_COM_strMsg_t ECU_COM_astrRx2Msg[ECU_COM_RX2_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_1,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_2,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_02_RX,
        /*Can Msg Id*/
		0x457,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_4,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_01_RX,
        /*Can Msg Id*/
		0x456,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_5,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_00_RX,
        /*Can Msg Id*/
		0x455,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_6,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_00_RX,
        /*Can Msg Id*/
		0x100,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_7,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_8,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_9,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_10,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_11,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_12,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_13,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_14,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_15,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_16,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_17,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_18,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_12_RX,
        /*Can Msg Id*/
		0x112,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_19,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_20,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BMS_VCU_14_RX,
        /*Can Msg Id*/
		0x114,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX2_MSG_INDEX_21,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strMsg_t ECU_COM_astrTx2Msg[ECU_COM_TX2_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		BCM_VCU_06_TX,
        /*Can Msg Id*/
		0x453,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_1,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		BCM_VCU_04_TX,
        /*Can Msg Id*/
		0x451,
        /*DLC*/
		7,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_2,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_4,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_5,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_6,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_7,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_8,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_9,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_10,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_11,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x1F4,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_12,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_13,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	},
	{
  	    /*Msg ID*/
		VCU_BMS_REQ_TX,
        /*Can Msg Id*/
		0x200,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX2_MSG_INDEX_14,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strSignal_t ECU_COM_astrRx2Signal[ECU_COM_RX2_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		STATUS_CURRENT,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_REQUEST,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_UNUSED2,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_ANGLEBIT,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		37,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_BOOTSTRAP,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		36,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_REQSTATE,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		35,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_TARGET,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		10,
        /*Mask*/
		1023,
        /*MSB number*/
		33,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_ERROR,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		3,
        /*Mask*/
		7,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_RESERROR,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		20,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_CURSTATE,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		19,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_POSITION,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		10,
        /*Mask*/
		1023,
        /*MSB number*/
		17,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS_CODES,
        /*Frame Id*/
		BCM_VCU_07_RX,
        /*Can Msg Id*/
		0x454,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		ELECTRICALERRORPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		56,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		UNDERVOLTAGEPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		54,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		OVERVOLTAGEPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		52,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		UNDERTEMPERATUREPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		50,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		OVERTEMPERATUREPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		48,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		OVERCURRENTPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		46,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		DRYRUNERRORPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		44,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MOTORSTALLPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		42,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		TEMPERATUREPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		40,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VOLTAGEPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		32,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		RESPONSEERRORPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		24,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CURRENTPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		RPMPUMP1,
        /*Frame Id*/
		BCM_VCU_05_RX,
        /*Can Msg Id*/
		0x452,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_ON_OFF,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		60,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		USER_DRIVE_MODE_SELECTION,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		57,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_SET_TEMP,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_PACK_TEMP,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_PACK_PRESSURE,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_PACK_HUMIDITY,
        /*Frame Id*/
		BCM_VCU_03_RX,
        /*Can Msg Id*/
		0x458,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		POWERTRAIN_COOLANT_TEMP,
        /*Frame Id*/
		BCM_VCU_02_RX,
        /*Can Msg Id*/
		0x457,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		POWERTRAIN_COOLANT_PRESSURE,
        /*Frame Id*/
		BCM_VCU_02_RX,
        /*Can Msg Id*/
		0x457,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_COOLANT_OUTLET_TEMP,
        /*Frame Id*/
		BCM_VCU_02_RX,
        /*Can Msg Id*/
		0x457,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_COOLANT_INLET_TEMP,
        /*Frame Id*/
		BCM_VCU_02_RX,
        /*Can Msg Id*/
		0x457,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_COOLANT_INLET_PRESSURE,
        /*Frame Id*/
		BCM_VCU_01_RX,
        /*Can Msg Id*/
		0x456,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AMBIENT_PRESSURE,
        /*Frame Id*/
		BCM_VCU_01_RX,
        /*Can Msg Id*/
		0x456,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AMBIENT_TEMPRATURE,
        /*Frame Id*/
		BCM_VCU_01_RX,
        /*Can Msg Id*/
		0x456,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AMBIENT_HUMIDITY,
        /*Frame Id*/
		BCM_VCU_01_RX,
        /*Can Msg Id*/
		0x456,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_REFREGENT_LTEMPRATURE,
        /*Frame Id*/
		BCM_VCU_00_RX,
        /*Can Msg Id*/
		0x455,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_REFREGENT_LPRESSURE,
        /*Frame Id*/
		BCM_VCU_00_RX,
        /*Can Msg Id*/
		0x455,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_REFREGENT_HPRESSURE,
        /*Frame Id*/
		BCM_VCU_00_RX,
        /*Can Msg Id*/
		0x455,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		HVAC_INCABIN_TEMP,
        /*Frame Id*/
		BCM_VCU_00_RX,
        /*Can Msg Id*/
		0x455,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PACK_V_SUM_OF_CELLS,
        /*Frame Id*/
		BMS_VCU_00_RX,
        /*Can Msg Id*/
		0x100,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PACK_I_SHUNT,
        /*Frame Id*/
		BMS_VCU_00_RX,
        /*Can Msg Id*/
		0x100,
        /*Size*/
		32,
        /*Mask*/
		4294967295,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.01,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PACK_Q_SOC_INTERNAL,
        /*Frame Id*/
		BMS_VCU_00_RX,
        /*Can Msg Id*/
		0x100,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.01,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		STATUS,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CONTACTORS_ENABLED,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CONTACTORS_CHARGER_ACTIVATED,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CONTACTORS_LOAD_ACTIVATED,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		FLAGS_LOAD_ACTIVE,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		FLAGS_CHARGER_ACTIVE,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		FLAGS_PRECHARGE_ACTIVE,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		FLAGS_CHARGE_REG_ACTIVE,
        /*Frame Id*/
		BMS_VCU_01_RX,
        /*Can Msg Id*/
		0x101,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PCB_T1,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PCB_T2,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T1,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T2,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T3,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T4,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T5,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T6,
        /*Frame Id*/
		BMS_VCU_02_RX,
        /*Can Msg Id*/
		0x102,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T7,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T8,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T9,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T10,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		AUX_T11,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		ACTIVE_COUNT,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_ONLINE_COUNT,
        /*Frame Id*/
		BMS_VCU_03_RX,
        /*Can Msg Id*/
		0x103,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T1,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T3,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T5,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T7,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T9,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU1_CELL_T11,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T1,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T3,
        /*Frame Id*/
		BMS_VCU_04_RX,
        /*Can Msg Id*/
		0x104,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T5,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T7,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T9,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU2_CELL_T11,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T1,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T3,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T5,
        /*Frame Id*/
		BMS_VCU_05_RX,
        /*Can Msg Id*/
		0x105,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T7,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T9,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU3_CELL_T11,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T1,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T3,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T5,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T7,
        /*Frame Id*/
		BMS_VCU_06_RX,
        /*Can Msg Id*/
		0x106,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T9,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU4_CELL_T11,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T1,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T3,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T5,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T7,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T9,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU5_CELL_T11,
        /*Frame Id*/
		BMS_VCU_07_RX,
        /*Can Msg Id*/
		0x107,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T1,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T3,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T5,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T7,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T9,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU6_CELL_T11,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T1,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T3,
        /*Frame Id*/
		BMS_VCU_08_RX,
        /*Can Msg Id*/
		0x108,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T5,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T7,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T9,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU7_CELL_T11,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T1,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T3,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T5,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T7,
        /*Frame Id*/
		BMS_VCU_09_RX,
        /*Can Msg Id*/
		0x109,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T9,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU8_CELL_T11,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T1,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T3,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T5,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T7,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T9,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU9_CELL_T11,
        /*Frame Id*/
		BMS_VCU_10_RX,
        /*Can Msg Id*/
		0x110,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T1,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T3,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T5,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T7,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T9,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CMUS_CMU10_CELL_T11,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOH,
        /*Frame Id*/
		BMS_VCU_11_RX,
        /*Can Msg Id*/
		0x111,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.01,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_V_MIN_VAL,
        /*Frame Id*/
		BMS_VCU_12_RX,
        /*Can Msg Id*/
		0x112,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_V_MAX_VAL,
        /*Frame Id*/
		BMS_VCU_12_RX,
        /*Can Msg Id*/
		0x112,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		PACK_Q_REMAINING_HI_RES,
        /*Frame Id*/
		BMS_VCU_12_RX,
        /*Can Msg Id*/
		0x112,
        /*Size*/
		32,
        /*Mask*/
		4294967295,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_T_MIN_VAL,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_T_MIN_ID_CMU,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_T_MAX_VAL,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_T_MAX_ID_CMU,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_V_MIN_ID_CMU,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_V_MIN_ID_CELL,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CELL_V_MAX_ID_CMU,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CHARGER_CAN_ACTIVE,
        /*Frame Id*/
		BMS_VCU_13_RX,
        /*Can Msg Id*/
		0x113,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOP_INTERVAL_DATA1,
        /*Frame Id*/
		BMS_VCU_14_RX,
        /*Can Msg Id*/
		0x114,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOP_INTERVAL_DATA2,
        /*Frame Id*/
		BMS_VCU_14_RX,
        /*Can Msg Id*/
		0x114,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOP_INTERVAL_DATA3,
        /*Frame Id*/
		BMS_VCU_14_RX,
        /*Can Msg Id*/
		0x114,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOP_INTERVAL_DATA4,
        /*Frame Id*/
		BMS_VCU_14_RX,
        /*Can Msg Id*/
		0x114,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


ECU_COM_strSignal_t ECU_COM_astrTx2Signal[ECU_COM_TX2_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		SET_ANGLEBIT,
        /*Frame Id*/
		BCM_VCU_06_TX,
        /*Can Msg Id*/
		0x453,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SET_ANGLE,
        /*Frame Id*/
		BCM_VCU_06_TX,
        /*Can Msg Id*/
		0x453,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SET_POSITION,
        /*Frame Id*/
		BCM_VCU_06_TX,
        /*Can Msg Id*/
		0x453,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SET_NAD,
        /*Frame Id*/
		BCM_VCU_06_TX,
        /*Can Msg Id*/
		0x453,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		TARGETRPMPUMP1,
        /*Frame Id*/
		BCM_VCU_04_TX,
        /*Can Msg Id*/
		0x451,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		DISABLEEMMODEPUMP1,
        /*Frame Id*/
		BCM_VCU_04_TX,
        /*Can Msg Id*/
		0x451,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		0,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MOTOR_IGBTTEMP,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		REGEN_COMMAND_STATUS,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		29,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CURRENT_DRIVE_MODE,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		28,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BRAKE_SWITCH_DATA,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		26,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VCU_STATE,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		2,
        /*Mask*/
		3,
        /*MSB number*/
		25,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MOTOR_ROTORTEMP,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		ACCELERATION_PEDAL_PRESS,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_11_TX,
        /*Can Msg Id*/
		0x310,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU10_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		SOH_TOGW,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_10_TX,
        /*Can Msg Id*/
		0x1FC,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.01,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU9_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_9_TX,
        /*Can Msg Id*/
		0x1FB,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU8_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_8_TX,
        /*Can Msg Id*/
		0x1FA,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU6_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU7_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_7_TX,
        /*Can Msg Id*/
		0x1F9,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU5_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_6_TX,
        /*Can Msg Id*/
		0x1F8,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU4_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_5_TX,
        /*Can Msg Id*/
		0x1F7,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU3_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_4_TX,
        /*Can Msg Id*/
		0x1F6,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T5,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T7,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T9,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU1_CELL_T11,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		47,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T1,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CMU2_CELL_T3,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_3_TX,
        /*Can Msg Id*/
		0x1F5,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		63,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MCU_MG1IGBTTEMP_C,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x1F4,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		CR_MOTROTORTEMP_C,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x1F4,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		-40,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MCU_INVTEMP_C,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x1F4,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		MCU_MOTTEMP_C,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_2_TX,
        /*Can Msg Id*/
		0x1F4,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		ACPPEDALFAULT,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		1,
        /*Mask*/
		1,
        /*MSB number*/
		0,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATTERY_SOC,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		23,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		0.01,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VEHWHLCLCDSPD,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		31,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VHCLDRIVESTATUS,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		3,
        /*Mask*/
		7,
        /*MSB number*/
		3,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BATPACKVOLTAGE,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		39,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		VHCLESTIMATEDRANGE,
        /*Frame Id*/
		VCU_GATEWAY_SIGNAL_1_TX,
        /*Can Msg Id*/
		0x1FE,
        /*Size*/
		16,
        /*Mask*/
		65535,
        /*MSB number*/
		55,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_LOAD_ACTIVE,
        /*Frame Id*/
		VCU_BMS_REQ_TX,
        /*Can Msg Id*/
		0x200,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	},
	{
  	    /*Signal ID*/
		BMS_CHARGE_ACTIVE,
        /*Frame Id*/
		VCU_BMS_REQ_TX,
        /*Can Msg Id*/
		0x200,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		15,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


/*********** NETWORK 3 ***********/
ECU_COM_strMsg_t ECU_COM_astrRx3Msg[ECU_COM_RX3_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		TESTRXMSG,
        /*Can Msg Id*/
		0x150,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_RX3_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strMsg_t ECU_COM_astrTx3Msg[ECU_COM_TX3_MSGS_NUM] =
{
	{
  	    /*Msg ID*/
		TESTTXMSG,
        /*Can Msg Id*/
		0x160,
        /*DLC*/
		8,
        /*Lower Layer Frame Id */
		UC_CAN_TX3_MSG_INDEX_3,
        /*Data*/
		{TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT,TAPAS_DEFAULT},
        /*Status*/
		MESSAGE_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE
	}
};


ECU_COM_strSignal_t ECU_COM_astrRx3Signal[ECU_COM_RX3_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		TESTRXSIG,
        /*Frame Id*/
		TESTRXMSG,
        /*Can Msg Id*/
		0x150,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


ECU_COM_strSignal_t ECU_COM_astrTx3Signal[ECU_COM_TX3_SIGNALS_NUM] =
{
	{
  	    /*Signal ID*/
		TESTTXSIG,
        /*Frame Id*/
		TESTTXMSG,
        /*Can Msg Id*/
		0x160,
        /*Size*/
		8,
        /*Mask*/
		255,
        /*MSB number*/
		7,
        /*Big/Little Endian*/
		TAPAS_LITTLE_ENDIAN,
        /*Resolution*/
		1,
        /*Offset*/
		0,
        /*Raw Value*/
		TAPAS_DEFAULT,
        /*Physical Value*/
		TAPAS_DEFAULT,
        /*Status*/
		SIGNAL_NOT_AVAILABLE,
        /*New Data Flag*/
		TAPAS_TRUE,
	}
};


ECU_COM_strSigDecode_t ECU_COM_astrSigDecodeRx[ECU_COM_RX_SIGNALS_NUM] = 
{
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		ACTIVE_COUNT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AMBIENT_HUMIDITY,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AMBIENT_PRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AMBIENT_TEMPRATURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T10,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T2,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T4,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T6,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T8,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		AUX_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_COOLANT_INLET_PRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_COOLANT_INLET_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_COOLANT_OUTLET_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_PACK_HUMIDITY,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_PACK_PRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		BATTERY_PACK_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_T_MAX_ID_CMU,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_T_MAX_VAL,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_T_MIN_ID_CMU,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_T_MIN_VAL,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_V_MAX_ID_CMU,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_V_MAX_VAL,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_V_MIN_ID_CELL,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_V_MIN_ID_CMU,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CELL_V_MIN_VAL,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CF_EPARK_FS_ACT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CF_EPARK_INHIBIT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CF_EPARK_PARKPOSSTS,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CF_MCU_MG1FLT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CF_MCU_MG1WRN,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CHARGER_CAN_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU10_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU1_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU2_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU3_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU4_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU5_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU6_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU7_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU8_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_CMU9_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CMUS_ONLINE_COUNT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CONTACTORS_CHARGER_ACTIVATED,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CONTACTORS_ENABLED,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CONTACTORS_LOAD_ACTIVATED,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_GEN_POWER_WH,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MG1IGBTTEMP_C,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MG1INVTEMP_C,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MG1RADFANREQ_DUTY,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MOTACTROTSPD_RPM,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MOTDEFACT_PC,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MOTESTTQ_PC,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MOTROTORTEMP_C,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_MOTTEMP_C,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_VCRM_EWPSPDREQ_RPM,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_VCRM_MOTACTROTSPD_RPM,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_VCRM_MOTDEFACT_PC,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CR_MCU_VCRM_MOTESTTQ_PC,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		CURRENTPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		DRYRUNERRORPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		ELECTRICALERRORPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		FLAGS_CHARGER_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		FLAGS_CHARGE_REG_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		FLAGS_LOAD_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		FLAGS_PRECHARGE_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_INCABIN_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_ON_OFF,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_REFREGENT_HPRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_REFREGENT_LPRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_REFREGENT_LTEMPRATURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		HVAC_SET_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		MOTORSTALLPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		OVERCURRENTPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		OVERTEMPERATUREPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		OVERVOLTAGEPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PACK_I_SHUNT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PACK_Q_REMAINING_HI_RES,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PACK_Q_SOC_INTERNAL,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PACK_V_SUM_OF_CELLS,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PCB_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		PCB_T2,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		POWERTRAIN_COOLANT_PRESSURE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		POWERTRAIN_COOLANT_TEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		RESPONSEERRORPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		RPMPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		SOH,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		SOP_INTERVAL_DATA1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		SOP_INTERVAL_DATA2,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		SOP_INTERVAL_DATA3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		SOP_INTERVAL_DATA4,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_ANGLEBIT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_BOOTSTRAP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_CODES,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_CURRENT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_CURSTATE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_ERROR,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_POSITION,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_REQSTATE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_REQUEST,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_RESERROR,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_TARGET,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		STATUS_UNUSED2,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		TEMPERATUREPUMP1,
	},
	{
  	    /* Handler Id */
		2,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		TESTRXSIG,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		UNDERTEMPERATUREPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		UNDERVOLTAGEPUMP1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		USER_DRIVE_MODE_SELECTION,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_RX,
        /* Signal Id*/
		VOLTAGEPUMP1,
	}
};


ECU_COM_strSigDecode_t ECU_COM_astrSigDecodeTx[ECU_COM_TX_SIGNALS_NUM] = 
{
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		ACCELERATION_PEDAL_PRESS,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		ACPPEDALFAULT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BATPACKVOLTAGE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BATTERY_SOC,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CHARGE_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU10_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU1_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU2_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU3_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU4_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU5_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU6_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU7_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU8_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T1,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T11,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T3,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T5,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T7,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_CMU9_CELL_T9,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BMS_LOAD_ACTIVE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		BRAKE_SWITCH_DATA,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_BMS_MAINRLYONSTAT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_PRECHGSTATUS,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_3WAYVALINHIBIT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_ALIVECOUNT,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_CANCHECKSUM,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_CHARGECYCLE,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_EVRDY,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_EWPCOOLANTDIAGENB,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_EWPCOOLANTDISP,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_EWPFORCEDOPER,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_HVINTLOCK_REQ,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_MOTPWRENA,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_MSGCHKSUM3,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_PARKCMD,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_PGMRUN3_ALIVECOUNTER,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_VEH_DC,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_WAKEUPREQ,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CF_VCU_WARMUPCYC,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CR_MOTROTORTEMP_C,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CR_VCU_MOTTQCMD_PC,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CR_VCU_TQSTD_NM,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		CURRENT_DRIVE_MODE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		DISABLEEMMODEPUMP1,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MCUDTCCLR,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MCU_INVTEMP_C,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MCU_MG1IGBTTEMP_C,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MCU_MOTTEMP_C,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MOTOR_IGBTTEMP,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MOTOR_ROTORTEMP,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		MOTPWMONREQ,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		REGEN_COMMAND_STATUS,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		SET_ANGLE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		SET_ANGLEBIT,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		SET_NAD,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		SET_POSITION,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		SOH_TOGW,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		TARGETRPMPUMP1,
	},
	{
  	    /* Handler Id */
		2,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		TESTTXSIG,
	},
	{
  	    /* Handler Id */
		0,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		VCU_EWPSPDMAXREQ_RPM,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		VCU_STATE,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		VEHWHLCLCDSPD,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		VHCLDRIVESTATUS,
	},
	{
  	    /* Handler Id */
		1,
        /* Signal Type */
		ECU_COM_CH_TYPE_TX,
        /* Signal Id*/
		VHCLESTIMATEDRANGE,
	}
};


