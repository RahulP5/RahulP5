/*
***************************************************************************
***************************************************************************
(C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_mem_cfg.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/

#include "ecu_mem_cfg.h"
#include "ecu_mem.h"


#ifdef ECU_MEM_EXT_MODULE_ENABLE
ECU_MEM_EXT_strE2pSignalData_t ECU_MEM_EXT_astrE2pData[ECU_MEM_EXT_DATA_NUM] =
{
  {
    /*Data Id*/    
    ECU_MEM_EXT_DATA_ID0,
    /*Data Address Page Number*/
    ECU_MEM_EXT_PAGE_0,
    /*Data Address Offset*/
    ECU_MEM_EXT_OFFSET_0,
    /*Pysical Value*/
    TAPAS_DEFAULT,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    10,   
  },
};

ECU_MEM_EXT_E2pModuleHandler_t ECU_MEM_EXT_strE2pModuleHandler =
{
  /*Number of Objects*/
  ECU_MEM_EXT_DATA_NUM,
  /*Array of E2PROM Objects*/
  ECU_MEM_EXT_astrE2pData,
  /*Active Signal Write*/
  TAPAS_DEFAULT,
  /*Active Signal Read*/
  TAPAS_DEFAULT,
};
#endif /*ECU_MEM_EXT_MODULE_ENABLE*/

#ifdef ECU_MEM_INT_MODULE_ENABLE
ECU_MEM_INT_strE2pSignalData_t ECU_MEM_INT_astrE2pData[ECU_MEM_INT_DATA_NUM] =
{
  {
    /*Data Id*/ 
    ECU_MEM_INT_APP_VALID,
    /*Data Address Sector Number*/
    ECU_MEM_INT_BOOT_SECTOR,
    /*Data Address Offset*/
    (0*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_WDG_ENABLE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (0*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_XCP_ENABLE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (1*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_WHEEL_RADIUS,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (2*4),
    /*Pysical Value*/
    0.359,
    /*Resolution*/
    0.001,
    /*Offset*/
    0,
    /*Raw Value*/
    359,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_FINAL_DRIVE_RATIO,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (3*4),
    /*Pysical Value*/
    9.37,
    /*Resolution*/
    0.001,
    /*Offset*/
    0,
    /*Raw Value*/
    9370,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1SHORT2VCCVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (4*4),
    /*Pysical Value*/
    4.2,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    420,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1SHORT2GNDVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (5*4),
    /*Pysical Value*/
    0.5,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    50,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1PEDALMINVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (6*4),
    /*Pysical Value*/
    0.7,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    70,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1DELTAVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*
***************************************************************************
***************************************************************************
(C) 2020-2021 Devise Electronics Pvt Ltd  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of Devise Electronics Pvt Ltd and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of Devise Electronics Pvt Ltd

Devise Electronics Pvt Ltd
Erandwane,
411038, Pune,
India

File Name: ecu_mem_cfg.c
Author: deVCU-TAPAS Generated 
E-mail: devcu@deviseelectronics.com 
***************************************************************************
***************************************************************************
*/

#include "ecu_mem_cfg.h"
#include "ecu_mem.h"


#ifdef ECU_MEM_EXT_MODULE_ENABLE
ECU_MEM_EXT_strE2pSignalData_t ECU_MEM_EXT_astrE2pData[ECU_MEM_EXT_DATA_NUM] =
{
  {
    /*Data Id*/    
    ECU_MEM_EXT_DATA_ID0,
    /*Data Address Page Number*/
    ECU_MEM_EXT_PAGE_0,
    /*Data Address Offset*/
    ECU_MEM_EXT_OFFSET_0,
    /*Pysical Value*/
    TAPAS_DEFAULT,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    10,   
  },
};

ECU_MEM_EXT_E2pModuleHandler_t ECU_MEM_EXT_strE2pModuleHandler =
{
  /*Number of Objects*/
  ECU_MEM_EXT_DATA_NUM,
  /*Array of E2PROM Objects*/
  ECU_MEM_EXT_astrE2pData,
  /*Active Signal Write*/
  TAPAS_DEFAULT,
  /*Active Signal Read*/
  TAPAS_DEFAULT,
};
#endif /*ECU_MEM_EXT_MODULE_ENABLE*/

#ifdef ECU_MEM_INT_MODULE_ENABLE
ECU_MEM_INT_strE2pSignalData_t ECU_MEM_INT_astrE2pData[ECU_MEM_INT_DATA_NUM] =
{
  {
    /*Data Id*/ 
    ECU_MEM_INT_APP_VALID,
    /*Data Address Sector Number*/
    ECU_MEM_INT_BOOT_SECTOR,
    /*Data Address Offset*/
    (0*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_WDG_ENABLE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (0*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_XCP_ENABLE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (1*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_WHEEL_RADIUS,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (2*4),
    /*Pysical Value*/
    0.359,
    /*Resolution*/
    0.001,
    /*Offset*/
    0,
    /*Raw Value*/
    359,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_FINAL_DRIVE_RATIO,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (3*4),
    /*Pysical Value*/
    9.37,
    /*Resolution*/
    0.001,
    /*Offset*/
    0,
    /*Raw Value*/
    9370,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1SHORT2VCCVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (4*4),
    /*Pysical Value*/
    4.2,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    420,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1SHORT2GNDVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (5*4),
    /*Pysical Value*/
    0.5,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    50,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1PEDALMINVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (6*4),
    /*Pysical Value*/
    0.7,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    70,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P1DELTAVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (7*4),
    /*Pysical Value*/
    2.7,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    270,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P2SHORT2VCCVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (8*4),
    /*Pysical Value*/
    2.2,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    220,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P2SHORT2GNDVOLTAGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (9*4),
    /*Pysical Value*/
    0.3,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    30,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P2PEDALMINVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (10*4),
    /*Pysical Value*/
    0.5,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    50,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_P2DELTAVALUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (11*4),
    /*Pysical Value*/
    2.7,
    /*Resolution*/
    0.01,
    /*Offset*/
    0,
    /*Raw Value*/
    270,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXDELTA,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (12*4),
    /*Pysical Value*/
    30,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    30,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CLR_P1SHORT2VCC,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (13*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CLR_P1SHORT2GND,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (14*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CLR_P2SHORT2VCC,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (15*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CLR_P2SHORT2GND,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (16*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CLR_DELTA,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (17*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXTHEORATICALRANGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (18*4),
    /*Pysical Value*/
    500,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    500,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_RANGECALCULATIONINTERVA,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (19*4),
    /*Pysical Value*/
    2,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    2,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_ENERGYCALCULTIONFACTOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (20*4),
    /*Pysical Value*/
    1,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    1,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_DISTANCEINTERVAL,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (21*4),
    /*Pysical Value*/
    2,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    2,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_PREVIOUSENERGY,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (22*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_UBOOTNUMBER,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (23*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXDISCHARGECURRENT,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (24*4),
    /*Pysical Value*/
    160,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    160,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXCHARGECURRENT,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (25*4),
    /*Pysical Value*/
    26,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    26,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXCHARGECURRENTLIMIT,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (26*4),
    /*Pysical Value*/
    26,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    26,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXDISCHARGECURRENTLIMI,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (27*4),
    /*Pysical Value*/
    160,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    160,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_TDRV_PEDALMIDDLEPOSITIO,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (28*4),
    /*Pysical Value*/
    40,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    40,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_M_FACTOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (29*4),
    /*Pysical Value*/
    2,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    2,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_FVEHICLEMAXFORWARDSPEED,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (30*4),
    /*Pysical Value*/
    110,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    110,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CHFACTOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (31*4),
    /*Pysical Value*/
    2,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    2,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXREGENTORQUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (32*4),
    /*Pysical Value*/
    50,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    50,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_FMINCOMPRESSIONSPEEDFOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (33*4),
    /*Pysical Value*/
    10,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    10,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_TDRV_PEDALMASSFACTOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (34*4),
    /*Pysical Value*/
    10,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    10,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_MAXDRIVINGTORQUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (35*4),
    /*Pysical Value*/
    20,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    20,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_Y_FACTOR,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (36*4),
    /*Pysical Value*/
    0.8,
    /*Resolution*/
    0.1,
    /*Offset*/
    0,
    /*Raw Value*/
    8,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CREEP_TORQUERATECHANGE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (37*4),
    /*Pysical Value*/
    5,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    5,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CREEPMAXTORQUE,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (38*4),
    /*Pysical Value*/
    10,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    10,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_EEPROM_CREEP_SPEED,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (39*4),
    /*Pysical Value*/
    10,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    10,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_5,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (40*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_6,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (41*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_7,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (42*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_8,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (43*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_9,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (44*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
  {
    /*Data Id*/ 
    ECU_MEM_INT_DTC_NONAME_10,
    /*Data Address Sector Number*/
    ECU_MEM_INT_SECTOR,
    /*Data Address Offset*/
    (45*4),
    /*Pysical Value*/
    0,
    /*Resolution*/
    1,
    /*Offset*/
    0,
    /*Raw Value*/
    0,
  },
};

ECU_MEM_INT_E2pModuleHandler_t ECU_MEM_INT_strE2pModuleHandler =
{
  /*Number of Objects*/
  ECU_MEM_INT_DATA_NUM,
  /*Array of E2PROM Objects*/
  ECU_MEM_INT_astrE2pData,
};

#endif /*ECU_MEM_INT_MODULE_ENABLE*/


