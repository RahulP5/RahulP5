/*
***************************************************************************
***************************************************************************
(C) 2016 SIGRA Technologies GmbH  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of SIGRA Technologies GmbH and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of SIGRA Technologies GmbH

SIGRA Technologies GmbH
Agnes-Pockels-Bogen 1,
80992, Munich,
Germany

File Name: rte.h
Author: TAPAS Generated 
E-mail: info@sigratech.de  
***************************************************************************
***************************************************************************
*/
#ifndef RTE_H
#define RTE_H

#include "lib_types.h"
#include <stdlib.h>

/* TAPAS services includes */
#include "ecu.h"
#include "os.h"

#define RTE_MUTEX_FREE                                          (0)
#define RTE_MUTEX_BUSY                                          (1)

#define RTE_LOG_NO                                              (0)
#define RTE_LOG_YES                                             (1)


#define RTE_DATA_NUM                                                       (93)

#define RTE_DATA_ID_DTC_NONAME_5                                           (0)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_5                                   (1)
#define RTE_DATA_ID_DTC_NONAME_6                                           (2)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_6                                   (3)
#define RTE_DATA_ID_DTC_NONAME_7                                           (4)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_7                                   (5)
#define RTE_DATA_ID_DTC_NONAME_8                                           (6)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_8                                   (7)
#define RTE_DATA_ID_DTC_NONAME_9                                           (8)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_9                                   (9)
#define RTE_DATA_ID_DTC_NONAME_10                                          (10)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_10                                  (11)
#define RTE_DATA_ID_FLT_SYSTEMERRORSEVERITY                                (12)
#define RTE_DATA_ID_APP_100MS_OUT1                                         (13)
#define RTE_DATA_ID_APP_100MS_IN1                                          (14)
#define RTE_DATA_ID_DRYRUNERRORPUMP1_MONITOR                               (15)
#define RTE_DATA_ID_BATTERYPUMPRPM_MANUAL                                  (16)
#define RTE_DATA_ID_CAN_MOTROTSPD_MONITOR                                  (17)
#define RTE_DATA_ID_EEPROM_P1SHORT2VCCVOLTAGE_MONITOR                      (18)
#define RTE_DATA_ID_REVERSEPC_MANUAL                                       (19)
#define RTE_DATA_ID_REGENPC_MANUAL                                         (20)
#define RTE_DATA_ID_FORWORDPC_MANUAL                                       (21)
#define RTE_DATA_ID_SPORTMODE_MANUAL                                       (22)
#define RTE_DATA_ID_NORMALMODE_MANUAL                                      (23)
#define RTE_DATA_ID_ECOMODE_MANUAL                                         (24)
#define RTE_DATA_ID_I_BATT_CANBEFORECONVERSION_MONITOR                     (25)
#define RTE_DATA_ID_CURRENTLIM_MONITOR                                     (26)
#define RTE_DATA_ID_I_BATT_CANAFTERCONVERSION_MONITOR                      (27)
#define RTE_DATA_ID_I_BATT_TORQUELIMI_MONITOR                              (28)
#define RTE_DATA_ID_ACCELPEDALTORQUE_MONITOR                               (29)
#define RTE_DATA_ID_TORQUEABSREGEN_MONITOR                                 (30)
#define RTE_DATA_ID_TORQUEOVERSPEED_MONITOR                                (31)
#define RTE_DATA_ID_TORQUECHARGEPLUG_MONITOR                               (32)
#define RTE_DATA_ID_TORQUEOUTOFORDER_MONITOR                               (33)
#define RTE_DATA_ID_TORQUECURRENTLIMIT_MONITOR                             (34)
#define RTE_DATA_ID_TORQUEMCUDERATING_MONITOR                              (35)
#define RTE_DATA_ID_CREEPTORQU_MONITOR                                     (36)
#define RTE_DATA_ID_ACP_PEDALPOS_MONITOR                                   (37)
#define RTE_DATA_ID_EEPROM_PREVIOUSENERGY_MONITOR                          (38)
#define RTE_DATA_ID_KL30SIGNALSWITCH_MONITOR                               (39)
#define RTE_DATA_ID_KL15SIGNAL_MOONITOR                                    (40)
#define RTE_DATA_ID_KEY_AUX_MONITOR                                        (41)
#define RTE_DATA_ID_KEY_IGNITION_MONITOR                                   (42)
#define RTE_DATA_ID_SYS_ENABLE_DRV_MONITOR                                 (43)
#define RTE_DATA_ID_SYS_ENABLE_PRC_MONITOR                                 (44)
#define RTE_DATA_ID_SYS_ENABLE_DCDC_MONITOR                                (45)
#define RTE_DATA_ID_SYS_ENABLE_ACP_MONITOR                                 (46)
#define RTE_DATA_ID_SYS_ENABLE_PST_MONITOR                                 (47)
#define RTE_DATA_ID_SYS_ENABLE_DSH_MONITOR                                 (48)
#define RTE_DATA_ID_SYS_ENABLE_GEAR_MONITOR                                (49)
#define RTE_DATA_ID_SYS_ENABLE_KEY_MONITOR                                 (50)
#define RTE_DATA_ID_SYS_ENABLE_BAT_MONITOR                                 (51)
#define RTE_DATA_ID_SYS_ENABLE_THERM_MONITOR                               (52)
#define RTE_DATA_ID_SYS_ENABLE_CHR_MONITOR                                 (53)
#define RTE_DATA_ID_VEHICLESPEED_KMPH_MANUAL                               (54)
#define RTE_DATA_ID_MOTROTSPD_MANUAL                                       (55)
#define RTE_DATA_ID_MCU_MAXTRQ_MANUAL                                      (56)
#define RTE_DATA_ID_MCU_TRACTIONTRQAVAILABLE_MANUAL                        (57)
#define RTE_DATA_ID_LOAD_ACTIVE_MONITOR                                    (58)
#define RTE_DATA_ID_SYS_ENABLE_MCU_MONITOR                                 (59)
#define RTE_DATA_ID_SYS_ENABLE_BRK_MONITOR                                 (60)
#define RTE_DATA_ID_BRAKEPEDAL_MONITOR                                     (61)
#define RTE_DATA_ID_IMD_FAULTSIGNAL_MONITOR                                (62)
#define RTE_DATA_ID_SYS_SUBSTATE_MONITOR                                   (63)
#define RTE_DATA_ID_LOAD_ACTIVE_MANUAL                                     (64)
#define RTE_DATA_ID_MAINRELAYONSTATUS_MANUAL                               (65)
#define RTE_DATA_ID_MOTPWREN_MANUAL                                        (66)
#define RTE_DATA_ID_PARKCMD_MANUAL                                         (67)
#define RTE_DATA_ID_EPARK_INHIT_MANUAL                                     (68)
#define RTE_DATA_ID_VEHWHLCLCDSPD_MONITOR                                  (69)
#define RTE_DATA_ID_PARKCMD_MONITOR                                        (70)
#define RTE_DATA_ID_MOTPWENA_MONITOR                                       (71)
#define RTE_DATA_ID_TQRTOMCU_MONITOR                                       (72)
#define RTE_DATA_ID_MCUDTCCLR_MONITOR                                      (73)
#define RTE_DATA_ID_MOTTQCCMD_PC_MONITOR                                   (74)
#define RTE_DATA_ID_FLAGLOADACTIVE_MANUAL                                  (75)
#define RTE_DATA_ID_BRAKESWITCH_MANUAL                                     (76)
#define RTE_DATA_ID_CHARGESWITCH_MANUAL                                    (77)
#define RTE_DATA_ID_GEAR_P_MANUAL                                          (78)
#define RTE_DATA_ID_GEAR_D_MANUAL                                          (79)
#define RTE_DATA_ID_GEAR_N_MANUAL                                          (80)
#define RTE_DATA_ID_GEAR_R_MANUAL                                          (81)
#define RTE_DATA_ID_ESTOPSENS_MANUAL                                       (82)
#define RTE_DATA_ID_KEYSTART_MANUAL                                        (83)
#define RTE_DATA_ID_KEYACC_MANUAL                                          (84)
#define RTE_DATA_ID_PARKPOSSTS_MANUAL                                      (85)
#define RTE_DATA_ID_MCU_CANENABLE_MANUAL                                   (86)
#define RTE_DATA_ID_COOLNTPMPDC_MANUAL                                     (87)
#define RTE_DATA_ID_COOLNTPMPFRQCY_MANUAL                                  (88)
#define RTE_DATA_ID_APP_1MS_OUT1                                           (89)
#define RTE_DATA_ID_APP_1MS_IN1                                            (90)
#define RTE_DATA_ID_APP_50MS_OUT1                                          (91)
#define RTE_DATA_ID_APP_50MS_IN1                                           (92)


typedef struct RTE_strDataTemplate
{
	/* Data ID */
	uint16_t u8IdData;
	/* Data */
	float fltData;
	/* Access Mutex */
	uint32_t u32AccessMutex;
	/* Log Flag */
	uint8_t u8FlagLog;
} RTE_strData_t;


/* RTE Sender Receiver Bus Declaration */
extern RTE_strData_t RTE_astrData[RTE_DATA_NUM];


/* RTE Sender Receiver Interfaces Declarations */
float RTE_Read_DTC_NONAME_5(void);
void RTE_Write_DTC_NONAME_5(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_5(void);
void RTE_Write_FLT_CLR_DTC_NONAME_5(float fltValue);
float RTE_Read_DTC_NONAME_6(void);
void RTE_Write_DTC_NONAME_6(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_6(void);
void RTE_Write_FLT_CLR_DTC_NONAME_6(float fltValue);
float RTE_Read_DTC_NONAME_7(void);
void RTE_Write_DTC_NONAME_7(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_7(void);
void RTE_Write_FLT_CLR_DTC_NONAME_7(float fltValue);
float RTE_Read_DTC_NONAME_8(void);
void RTE_Write_DTC_NONAME_8(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_8(void);
void RTE_Write_FLT_CLR_DTC_NONAME_8(float fltValue);
float RTE_Read_DTC_NONAME_9(void);
void RTE_Write_DTC_NONAME_9(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_9(void);
void RTE_Write_FLT_CLR_DTC_NONAME_9(float fltValue);
float RTE_Read_DTC_NONAME_10(void);
void RTE_Write_DTC_NONAME_10(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_10(void);
void RTE_Write_FLT_CLR_DTC_NONAME_10(float fltValue);
float RTE_Read_FLT_SystemErrorSeverity(void);
void RTE_Write_FLT_SystemErrorSeverity(float fltValue);
float RTE_Read_APP_100MS_OUT1(void);
void RTE_Write_APP_100MS_OUT1(float fltValue);
float RTE_Read_APP_100MS_IN1(void);
void RTE_Write_APP_100MS_IN1(float fltValue);
float RTE_Read_DryRunErrorPump1_Monitor(void);
void RTE_Write_DryRunErrorPump1_Monitor(float fltValue);
float RTE_Read_BatteryPumpRPM_Manual(void);
void RTE_Write_BatteryPumpRPM_Manual(float fltValue);
float RTE_Read_CAN_MotRotSpd_Monitor(void);
void RTE_Write_CAN_MotRotSpd_Monitor(float fltValue);
float RTE_Read_EEPROM_P1SHORT2VCCVOLTAGE_Monitor(void);
void RTE_Write_EEPROM_P1SHORT2VCCVOLTAGE_Monitor(float fltValue);
float RTE_Read_ReversePC_Manual(void);
void RTE_Write_ReversePC_Manual(float fltValue);
float RTE_Read_RegenPC_Manual(void);
void RTE_Write_RegenPC_Manual(float fltValue);
float RTE_Read_ForwordPC_Manual(void);
void RTE_Write_ForwordPC_Manual(float fltValue);
float RTE_Read_SportMode_Manual(void);
void RTE_Write_SportMode_Manual(float fltValue);
float RTE_Read_NormalMode_Manual(void);
void RTE_Write_NormalMode_Manual(float fltValue);
float RTE_Read_EcoMode_Manual(void);
void RTE_Write_EcoMode_Manual(float fltValue);
float RTE_Read_I_Batt_CANBeforeconversion_Monitor(void);
void RTE_Write_I_Batt_CANBeforeconversion_Monitor(float fltValue);
float RTE_Read_CurrentLim_Monitor(void);
void RTE_Write_CurrentLim_Monitor(float fltValue);
float RTE_Read_I_Batt_CANAfterconversion_Monitor(void);
void RTE_Write_I_Batt_CANAfterconversion_Monitor(float fltValue);
float RTE_Read_I_Batt_TorqueLimi_Monitor(void);
void RTE_Write_I_Batt_TorqueLimi_Monitor(float fltValue);
float RTE_Read_Accelpedaltorque_Monitor(void);
void RTE_Write_Accelpedaltorque_Monitor(float fltValue);
float RTE_Read_TorqueABSRegen_Monitor(void);
void RTE_Write_TorqueABSRegen_Monitor(float fltValue);
float RTE_Read_TorqueOverspeed_Monitor(void);
void RTE_Write_TorqueOverspeed_Monitor(float fltValue);
float RTE_Read_TorqueChargePlug_Monitor(void);
void RTE_Write_TorqueChargePlug_Monitor(float fltValue);
float RTE_Read_TorqueOutOfOrder_Monitor(void);
void RTE_Write_TorqueOutOfOrder_Monitor(float fltValue);
float RTE_Read_TorqueCurrentLimit_Monitor(void);
void RTE_Write_TorqueCurrentLimit_Monitor(float fltValue);
float RTE_Read_TorqueMCUDerating_Monitor(void);
void RTE_Write_TorqueMCUDerating_Monitor(float fltValue);
float RTE_Read_CreepTorqu_Monitor(void);
void RTE_Write_CreepTorqu_Monitor(float fltValue);
float RTE_Read_ACP_PedalPos_Monitor(void);
void RTE_Write_ACP_PedalPos_Monitor(float fltValue);
float RTE_Read_EEPROM_PreviousEnergy_Monitor(void);
void RTE_Write_EEPROM_PreviousEnergy_Monitor(float fltValue);
float RTE_Read_KL30SignalSwitch_Monitor(void);
void RTE_Write_KL30SignalSwitch_Monitor(float fltValue);
float RTE_Read_KL15Signal_Moonitor(void);
void RTE_Write_KL15Signal_Moonitor(float fltValue);
float RTE_Read_Key_Aux_Monitor(void);
void RTE_Write_Key_Aux_Monitor(float fltValue);
float RTE_Read_Key_Ignition_Monitor(void);
void RTE_Write_Key_Ignition_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DRV_Monitor(void);
void RTE_Write_SYS_Enable_DRV_Monitor(float fltValue);
float RTE_Read_SYS_Enable_PRC_Monitor(void);
void RTE_Write_SYS_Enable_PRC_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DCDC_Monitor(void);
void RTE_Write_SYS_Enable_DCDC_Monitor(float fltValue);
float RTE_Read_SYS_Enable_ACP_Monitor(void);
void RTE_Write_SYS_Enable_ACP_Monitor(float fltValue);
float RTE_Read_SYS_Enable_PST_Monitor(void);
void RTE_Write_SYS_Enable_PST_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DSH_Monitor(void);
void RTE_Write_SYS_Enable_DSH_Monitor(float fltValue);
float RTE_Read_SYS_Enable_GEAR_Monitor(void);
void RTE_Write_SYS_Enable_GEAR_Monitor(float fltValue);
float RTE_Read_SYS_Enable_KEY_Monitor(void);
void RTE_Write_SYS_Enable_KEY_Monitor(float fltValue);
float RTE_Read_SYS_Enable_BAT_Monitor(void);
void RTE_Write_SYS_Enable_BAT_Monitor(float fltValue);
float RTE_Read_SYS_Enable_THERM_Monitor(void);
void RTE_Write_SYS_Enable_THERM_Monitor(float fltValue);
float RTE_Read_SYS_Enable_CHR_Monitor(void);
void RTE_Write_SYS_Enable_CHR_Monitor(float fltValue);
float RTE_Read_VehicleSpeed_kmph_Manual(void);
void RTE_Write_VehicleSpeed_kmph_Manual(float fltValue);
float RTE_Read_MotRotSpd_Manual(void);
void RTE_Write_MotRotSpd_Manual(float fltValue);
float RTE_Read_MCU_MaxTrq_Manual(void);
void RTE_Write_MCU_MaxTrq_Manual(float fltValue);
float RTE_Read_MCU_TractionTrqAvailable_Manual(void);
void RTE_Write_MCU_TractionTrqAvailable_Manual(float fltValue);
float RTE_Read_Load_Active_Monitor(void);
void RTE_Write_Load_Active_Monitor(float fltValue);
float RTE_Read_SYS_Enable_MCU_Monitor(void);
void RTE_Write_SYS_Enable_MCU_Monitor(float fltValue);
float RTE_Read_SYS_Enable_BRK_Monitor(void);
void RTE_Write_SYS_Enable_BRK_Monitor(float fltValue);
float RTE_Read_BrakePedal_Monitor(void);
void RTE_Write_BrakePedal_Monitor(float fltValue);
float RTE_Read_IMD_FaultSignal_Monitor(void);
void RTE_Write_IMD_FaultSignal_Monitor(float fltValue);
float RTE_Read_SYS_SubState_Monitor(void);
void RTE_Write_SYS_SubState_Monitor(float fltValue);
float RTE_Read_Load_Active_Manual(void);
void RTE_Write_Load_Active_Manual(float fltValue);
float RTE_Read_MainRelayOnStatus_Manual(void);
void RTE_Write_MainRelayOnStatus_Manual(float fltValue);
float RTE_Read_MotPwrEn_Manual(void);
void RTE_Write_MotPwrEn_Manual(float fltValue);
float RTE_Read_ParkCmd_Manual(void);
void RTE_Write_ParkCmd_Manual(float fltValue);
float RTE_Read_Epark_Inhit_Manual(void);
void RTE_Write_Epark_Inhit_Manual(float fltValue);
float RTE_Read_VehWhlClcdSpd_Monitor(void);
void RTE_Write_VehWhlClcdSpd_Monitor(float fltValue);
float RTE_Read_parkcmd_Monitor(void);
void RTE_Write_parkcmd_Monitor(float fltValue);
float RTE_Read_MotPwEna_Monitor(void);
void RTE_Write_MotPwEna_Monitor(float fltValue);
float RTE_Read_TqrTOMcu_Monitor(void);
void RTE_Write_TqrTOMcu_Monitor(float fltValue);
float RTE_Read_McuDtcClr_Monitor(void);
void RTE_Write_McuDtcClr_Monitor(float fltValue);
float RTE_Read_MotTqcCmd_PC_Monitor(void);
void RTE_Write_MotTqcCmd_PC_Monitor(float fltValue);
float RTE_Read_FlagLoadActive_Manual(void);
void RTE_Write_FlagLoadActive_Manual(float fltValue);
float RTE_Read_BrakeSwitch_Manual(void);
void RTE_Write_BrakeSwitch_Manual(float fltValue);
float RTE_Read_ChargeSwitch_Manual(void);
void RTE_Write_ChargeSwitch_Manual(float fltValue);
float RTE_Read_Gear_P_Manual(void);
void RTE_Write_Gear_P_Manual(float fltValue);
float RTE_Read_Gear_D_Manual(void);
void RTE_Write_Gear_D_Manual(float fltValue);
float RTE_Read_Gear_N_Manual(void);
void RTE_Write_Gear_N_Manual(float fltValue);
float RTE_Read_Gear_R_Manual(void);
void RTE_Write_Gear_R_Manual(float fltValue);
float RTE_Read_EStopSens_Manual(void);
void RTE_Write_EStopSens_Manual(float fltValue);
float RTE_Read_KeyStart_Manual(void);
void RTE_Write_KeyStart_Manual(float fltValue);
float RTE_Read_KeyAcc_Manual(void);
void RTE_Write_KeyAcc_Manual(float fltValue);
float RTE_Read_ParkPosSts_Manual(void);
void RTE_Write_ParkPosSts_Manual(float fltValue);
float RTE_Read_MCU_CANEnable_Manual(void);
void RTE_Write_MCU_CANEnable_Manual(float fltValue);
float RTE_Read_CoolntPmpDC_Manual(void);
void RTE_Write_CoolntPmpDC_Manual(float fltValue);
float RTE_Read_CoolntPmpFrqcy_Manual(void);
void RTE_Write_CoolntPmpFrqcy_Manual(float fltValue);
float RTE_Read_APP_1MS_OUT1(void);
void RTE_Write_APP_1MS_OUT1(float fltValue);
float RTE_Read_APP_1MS_IN1(void);
void RTE_Write_APP_1MS_IN1(float fltValue);
float RTE_Read_APP_50MS_OUT1(void);
void RTE_Write_APP_50MS_OUT1(float fltValue);
float RTE_Read_APP_50MS_IN1(void);
void RTE_Write_APP_50MS_IN1(float fltValue);

/* RTE SWC Init */
void RTE_vdInit(void);


/* RTE SWC Deinit */
void RTE_vdDeInit(void);


/* RTE SWC Access */
STATUS_t RTE_eReadData(uint16_t u16Id, float* pfltData);
STATUS_t RTE_eWriteData(uint16_t u16Id, float fltData);



/* Framework External Services Interfaces */
#define RTE_Service_COM_vdReadSignal ECU_COM_vdReadSignal
#define RTE_Service_COM_vdWriteSignal ECU_COM_vdWriteSignal
#define RTE_Service_COM_vdEnable ECU_COM_vdEnable
#define RTE_Service_ANLG_eReadSignal ECU_ANLG_eReadSignal
#define RTE_Service_IO_eOutputControl ECU_IO_eOutputControl
#define RTE_Service_IO_eInputRead ECU_IO_eInputRead
#define RTE_Service_MEM_eWriteSignalValue ECU_MEM_eWriteSignalValue
#define RTE_Service_MEM_eReadSignalValue ECU_MEM_eReadSignalValue
#define RTE_Service_SYS_vdShutdown ECU_SYS_vdShutdown
#define RTE_Service_IO_eReadPwm ECU_IO_eReadPwm
#define RTE_Service_IO_eSetPwm ECU_IO_eSetPwm
#define RTE_Service_SYS_vdGetResetStatus ECU_SYS_vdGetResetStatus
#define RTE_Service_SYS_vdClearResetStatus ECU_SYS_vdClearResetStatus
#define RTE_Service_IO_eInternalOutputControl ECU_IO_eInternalOutputControl

extern STATUS_t RTE_Service_COM_vdReadSignal(uint8_t u8IdSignal, float* pfltValue);
extern STATUS_t RTE_Service_COM_vdWriteSignal(uint8_t u8IdSignal, float fltValue);
extern STATUS_t RTE_Service_COM_vdEnable(uint8_t u8Enable);
extern STATUS_t RTE_Service_ANLG_eReadSignal(uint8_t u8IndexSignal, float* pfltValue);
extern STATUS_t RTE_Service_IO_eOutputControl(uint8_t u8IdOutput, ECU_IO_eOutputCommand_t eOutputCommand);
extern STATUS_t RTE_Service_IO_eInputRead(uint8_t u8IdInput, uint8_t* pu8Value);
extern STATUS_t RTE_Service_MEM_eWriteSignalValue(uint8_t u8SignalID, float fltValue, uint32_t u32Value);
extern STATUS_t RTE_Service_MEM_eReadSignalValue(uint8_t u8SignalID, float* pfltValue);
extern void RTE_Service_SYS_vdShutdown(void);
extern STATUS_t RTE_Service_IO_eReadPwm(uint8_t u8IdPin, uint32_t* pu32FreqHz, uint8_t* pu8DutyCycle);
extern STATUS_t RTE_Service_IO_eSetPwm(uint8_t u8IdPout, uint32_t u32FreqHz, uint8_t u8DutyCycle);
extern void RTE_Service_SYS_vdGetResetStatus(uint8_t* pu8IsExWdgReset);
extern void RTE_Service_SYS_vdClearResetStatus(uint8_t u8IsExWdgResetNeeded);
extern STATUS_t RTE_Service_IO_eInternalOutputControl(uint8_t u8IdOutput, ECU_IO_eOutputCommand_t eOutputCommand);

#endif /*RTE_H*/

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    /*
***************************************************************************
***************************************************************************
(C) 2016 SIGRA Technologies GmbH  All rights reserved.

All data and information contained in or disclosed by this document is
confidential and proprietary information of SIGRA Technologies GmbH and all
rights therein are expressly reserved.  By accepting this material the
recipient agrees that this material and the information contained therein
is held in confidence and in trust and will not be used, copied, reproduced
in whole or in part, nor its contents revealed in any manner to others
without the express written permission of SIGRA Technologies GmbH

SIGRA Technologies GmbH
Agnes-Pockels-Bogen 1,
80992, Munich,
Germany

File Name: rte.h
Author: TAPAS Generated 
E-mail: info@sigratech.de  
***************************************************************************
***************************************************************************
*/
#ifndef RTE_H
#define RTE_H

#include "lib_types.h"
#include <stdlib.h>

/* TAPAS services includes */
#include "ecu.h"
#include "os.h"

#define RTE_MUTEX_FREE                                          (0)
#define RTE_MUTEX_BUSY                                          (1)

#define RTE_LOG_NO                                              (0)
#define RTE_LOG_YES                                             (1)


#define RTE_DATA_NUM                                                       (93)

#define RTE_DATA_ID_DTC_NONAME_5                                           (0)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_5                                   (1)
#define RTE_DATA_ID_DTC_NONAME_6                                           (2)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_6                                   (3)
#define RTE_DATA_ID_DTC_NONAME_7                                           (4)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_7                                   (5)
#define RTE_DATA_ID_DTC_NONAME_8                                           (6)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_8                                   (7)
#define RTE_DATA_ID_DTC_NONAME_9                                           (8)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_9                                   (9)
#define RTE_DATA_ID_DTC_NONAME_10                                          (10)
#define RTE_DATA_ID_FLT_CLR_DTC_NONAME_10                                  (11)
#define RTE_DATA_ID_FLT_SYSTEMERRORSEVERITY                                (12)
#define RTE_DATA_ID_APP_100MS_OUT1                                         (13)
#define RTE_DATA_ID_APP_100MS_IN1                                          (14)
#define RTE_DATA_ID_DRYRUNERRORPUMP1_MONITOR                               (15)
#define RTE_DATA_ID_BATTERYPUMPRPM_MANUAL                                  (16)
#define RTE_DATA_ID_CAN_MOTROTSPD_MONITOR                                  (17)
#define RTE_DATA_ID_EEPROM_P1SHORT2VCCVOLTAGE_MONITOR                      (18)
#define RTE_DATA_ID_REVERSEPC_MANUAL                                       (19)
#define RTE_DATA_ID_REGENPC_MANUAL                                         (20)
#define RTE_DATA_ID_FORWORDPC_MANUAL                                       (21)
#define RTE_DATA_ID_SPORTMODE_MANUAL                                       (22)
#define RTE_DATA_ID_NORMALMODE_MANUAL                                      (23)
#define RTE_DATA_ID_ECOMODE_MANUAL                                         (24)
#define RTE_DATA_ID_I_BATT_CANBEFORECONVERSION_MONITOR                     (25)
#define RTE_DATA_ID_CURRENTLIM_MONITOR                                     (26)
#define RTE_DATA_ID_I_BATT_CANAFTERCONVERSION_MONITOR                      (27)
#define RTE_DATA_ID_I_BATT_TORQUELIMI_MONITOR                              (28)
#define RTE_DATA_ID_ACCELPEDALTORQUE_MONITOR                               (29)
#define RTE_DATA_ID_TORQUEABSREGEN_MONITOR                                 (30)
#define RTE_DATA_ID_TORQUEOVERSPEED_MONITOR                                (31)
#define RTE_DATA_ID_TORQUECHARGEPLUG_MONITOR                               (32)
#define RTE_DATA_ID_TORQUEOUTOFORDER_MONITOR                               (33)
#define RTE_DATA_ID_TORQUECURRENTLIMIT_MONITOR                             (34)
#define RTE_DATA_ID_TORQUEMCUDERATING_MONITOR                              (35)
#define RTE_DATA_ID_CREEPTORQU_MONITOR                                     (36)
#define RTE_DATA_ID_ACP_PEDALPOS_MONITOR                                   (37)
#define RTE_DATA_ID_EEPROM_PREVIOUSENERGY_MONITOR                          (38)
#define RTE_DATA_ID_KL30SIGNALSWITCH_MONITOR                               (39)
#define RTE_DATA_ID_KL15SIGNAL_MOONITOR                                    (40)
#define RTE_DATA_ID_KEY_AUX_MONITOR                                        (41)
#define RTE_DATA_ID_KEY_IGNITION_MONITOR                                   (42)
#define RTE_DATA_ID_SYS_ENABLE_DRV_MONITOR                                 (43)
#define RTE_DATA_ID_SYS_ENABLE_PRC_MONITOR                                 (44)
#define RTE_DATA_ID_SYS_ENABLE_DCDC_MONITOR                                (45)
#define RTE_DATA_ID_SYS_ENABLE_ACP_MONITOR                                 (46)
#define RTE_DATA_ID_SYS_ENABLE_PST_MONITOR                                 (47)
#define RTE_DATA_ID_SYS_ENABLE_DSH_MONITOR                                 (48)
#define RTE_DATA_ID_SYS_ENABLE_GEAR_MONITOR                                (49)
#define RTE_DATA_ID_SYS_ENABLE_KEY_MONITOR                                 (50)
#define RTE_DATA_ID_SYS_ENABLE_BAT_MONITOR                                 (51)
#define RTE_DATA_ID_SYS_ENABLE_THERM_MONITOR                               (52)
#define RTE_DATA_ID_SYS_ENABLE_CHR_MONITOR                                 (53)
#define RTE_DATA_ID_VEHICLESPEED_KMPH_MANUAL                               (54)
#define RTE_DATA_ID_MOTROTSPD_MANUAL                                       (55)
#define RTE_DATA_ID_MCU_MAXTRQ_MANUAL                                      (56)
#define RTE_DATA_ID_MCU_TRACTIONTRQAVAILABLE_MANUAL                        (57)
#define RTE_DATA_ID_LOAD_ACTIVE_MONITOR                                    (58)
#define RTE_DATA_ID_SYS_ENABLE_MCU_MONITOR                                 (59)
#define RTE_DATA_ID_SYS_ENABLE_BRK_MONITOR                                 (60)
#define RTE_DATA_ID_BRAKEPEDAL_MONITOR                                     (61)
#define RTE_DATA_ID_IMD_FAULTSIGNAL_MONITOR                                (62)
#define RTE_DATA_ID_SYS_SUBSTATE_MONITOR                                   (63)
#define RTE_DATA_ID_LOAD_ACTIVE_MANUAL                                     (64)
#define RTE_DATA_ID_MAINRELAYONSTATUS_MANUAL                               (65)
#define RTE_DATA_ID_MOTPWREN_MANUAL                                        (66)
#define RTE_DATA_ID_PARKCMD_MANUAL                                         (67)
#define RTE_DATA_ID_EPARK_INHIT_MANUAL                                     (68)
#define RTE_DATA_ID_VEHWHLCLCDSPD_MONITOR                                  (69)
#define RTE_DATA_ID_PARKCMD_MONITOR                                        (70)
#define RTE_DATA_ID_MOTPWENA_MONITOR                                       (71)
#define RTE_DATA_ID_TQRTOMCU_MONITOR                                       (72)
#define RTE_DATA_ID_MCUDTCCLR_MONITOR                                      (73)
#define RTE_DATA_ID_MOTTQCCMD_PC_MONITOR                                   (74)
#define RTE_DATA_ID_FLAGLOADACTIVE_MANUAL                                  (75)
#define RTE_DATA_ID_BRAKESWITCH_MANUAL                                     (76)
#define RTE_DATA_ID_CHARGESWITCH_MANUAL                                    (77)
#define RTE_DATA_ID_GEAR_P_MANUAL                                          (78)
#define RTE_DATA_ID_GEAR_D_MANUAL                                          (79)
#define RTE_DATA_ID_GEAR_N_MANUAL                                          (80)
#define RTE_DATA_ID_GEAR_R_MANUAL                                          (81)
#define RTE_DATA_ID_ESTOPSENS_MANUAL                                       (82)
#define RTE_DATA_ID_KEYSTART_MANUAL                                        (83)
#define RTE_DATA_ID_KEYACC_MANUAL                                          (84)
#define RTE_DATA_ID_PARKPOSSTS_MANUAL                                      (85)
#define RTE_DATA_ID_MCU_CANENABLE_MANUAL                                   (86)
#define RTE_DATA_ID_COOLNTPMPDC_MANUAL                                     (87)
#define RTE_DATA_ID_COOLNTPMPFRQCY_MANUAL                                  (88)
#define RTE_DATA_ID_APP_1MS_OUT1                                           (89)
#define RTE_DATA_ID_APP_1MS_IN1                                            (90)
#define RTE_DATA_ID_APP_50MS_OUT1                                          (91)
#define RTE_DATA_ID_APP_50MS_IN1                                           (92)


typedef struct RTE_strDataTemplate
{
	/* Data ID */
	uint16_t u8IdData;
	/* Data */
	float fltData;
	/* Access Mutex */
	uint32_t u32AccessMutex;
	/* Log Flag */
	uint8_t u8FlagLog;
} RTE_strData_t;


/* RTE Sender Receiver Bus Declaration */
extern RTE_strData_t RTE_astrData[RTE_DATA_NUM];


/* RTE Sender Receiver Interfaces Declarations */
float RTE_Read_DTC_NONAME_5(void);
void RTE_Write_DTC_NONAME_5(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_5(void);
void RTE_Write_FLT_CLR_DTC_NONAME_5(float fltValue);
float RTE_Read_DTC_NONAME_6(void);
void RTE_Write_DTC_NONAME_6(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_6(void);
void RTE_Write_FLT_CLR_DTC_NONAME_6(float fltValue);
float RTE_Read_DTC_NONAME_7(void);
void RTE_Write_DTC_NONAME_7(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_7(void);
void RTE_Write_FLT_CLR_DTC_NONAME_7(float fltValue);
float RTE_Read_DTC_NONAME_8(void);
void RTE_Write_DTC_NONAME_8(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_8(void);
void RTE_Write_FLT_CLR_DTC_NONAME_8(float fltValue);
float RTE_Read_DTC_NONAME_9(void);
void RTE_Write_DTC_NONAME_9(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_9(void);
void RTE_Write_FLT_CLR_DTC_NONAME_9(float fltValue);
float RTE_Read_DTC_NONAME_10(void);
void RTE_Write_DTC_NONAME_10(float fltValue);
float RTE_Read_FLT_CLR_DTC_NONAME_10(void);
void RTE_Write_FLT_CLR_DTC_NONAME_10(float fltValue);
float RTE_Read_FLT_SystemErrorSeverity(void);
void RTE_Write_FLT_SystemErrorSeverity(float fltValue);
float RTE_Read_APP_100MS_OUT1(void);
void RTE_Write_APP_100MS_OUT1(float fltValue);
float RTE_Read_APP_100MS_IN1(void);
void RTE_Write_APP_100MS_IN1(float fltValue);
float RTE_Read_DryRunErrorPump1_Monitor(void);
void RTE_Write_DryRunErrorPump1_Monitor(float fltValue);
float RTE_Read_BatteryPumpRPM_Manual(void);
void RTE_Write_BatteryPumpRPM_Manual(float fltValue);
float RTE_Read_CAN_MotRotSpd_Monitor(void);
void RTE_Write_CAN_MotRotSpd_Monitor(float fltValue);
float RTE_Read_EEPROM_P1SHORT2VCCVOLTAGE_Monitor(void);
void RTE_Write_EEPROM_P1SHORT2VCCVOLTAGE_Monitor(float fltValue);
float RTE_Read_ReversePC_Manual(void);
void RTE_Write_ReversePC_Manual(float fltValue);
float RTE_Read_RegenPC_Manual(void);
void RTE_Write_RegenPC_Manual(float fltValue);
float RTE_Read_ForwordPC_Manual(void);
void RTE_Write_ForwordPC_Manual(float fltValue);
float RTE_Read_SportMode_Manual(void);
void RTE_Write_SportMode_Manual(float fltValue);
float RTE_Read_NormalMode_Manual(void);
void RTE_Write_NormalMode_Manual(float fltValue);
float RTE_Read_EcoMode_Manual(void);
void RTE_Write_EcoMode_Manual(float fltValue);
float RTE_Read_I_Batt_CANBeforeconversion_Monitor(void);
void RTE_Write_I_Batt_CANBeforeconversion_Monitor(float fltValue);
float RTE_Read_CurrentLim_Monitor(void);
void RTE_Write_CurrentLim_Monitor(float fltValue);
float RTE_Read_I_Batt_CANAfterconversion_Monitor(void);
void RTE_Write_I_Batt_CANAfterconversion_Monitor(float fltValue);
float RTE_Read_I_Batt_TorqueLimi_Monitor(void);
void RTE_Write_I_Batt_TorqueLimi_Monitor(float fltValue);
float RTE_Read_Accelpedaltorque_Monitor(void);
void RTE_Write_Accelpedaltorque_Monitor(float fltValue);
float RTE_Read_TorqueABSRegen_Monitor(void);
void RTE_Write_TorqueABSRegen_Monitor(float fltValue);
float RTE_Read_TorqueOverspeed_Monitor(void);
void RTE_Write_TorqueOverspeed_Monitor(float fltValue);
float RTE_Read_TorqueChargePlug_Monitor(void);
void RTE_Write_TorqueChargePlug_Monitor(float fltValue);
float RTE_Read_TorqueOutOfOrder_Monitor(void);
void RTE_Write_TorqueOutOfOrder_Monitor(float fltValue);
float RTE_Read_TorqueCurrentLimit_Monitor(void);
void RTE_Write_TorqueCurrentLimit_Monitor(float fltValue);
float RTE_Read_TorqueMCUDerating_Monitor(void);
void RTE_Write_TorqueMCUDerating_Monitor(float fltValue);
float RTE_Read_CreepTorqu_Monitor(void);
void RTE_Write_CreepTorqu_Monitor(float fltValue);
float RTE_Read_ACP_PedalPos_Monitor(void);
void RTE_Write_ACP_PedalPos_Monitor(float fltValue);
float RTE_Read_EEPROM_PreviousEnergy_Monitor(void);
void RTE_Write_EEPROM_PreviousEnergy_Monitor(float fltValue);
float RTE_Read_KL30SignalSwitch_Monitor(void);
void RTE_Write_KL30SignalSwitch_Monitor(float fltValue);
float RTE_Read_KL15Signal_Moonitor(void);
void RTE_Write_KL15Signal_Moonitor(float fltValue);
float RTE_Read_Key_Aux_Monitor(void);
void RTE_Write_Key_Aux_Monitor(float fltValue);
float RTE_Read_Key_Ignition_Monitor(void);
void RTE_Write_Key_Ignition_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DRV_Monitor(void);
void RTE_Write_SYS_Enable_DRV_Monitor(float fltValue);
float RTE_Read_SYS_Enable_PRC_Monitor(void);
void RTE_Write_SYS_Enable_PRC_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DCDC_Monitor(void);
void RTE_Write_SYS_Enable_DCDC_Monitor(float fltValue);
float RTE_Read_SYS_Enable_ACP_Monitor(void);
void RTE_Write_SYS_Enable_ACP_Monitor(float fltValue);
float RTE_Read_SYS_Enable_PST_Monitor(void);
void RTE_Write_SYS_Enable_PST_Monitor(float fltValue);
float RTE_Read_SYS_Enable_DSH_Monitor(void);
void RTE_Write_SYS_Enable_DSH_Monitor(float fltValue);
float RTE_Read_SYS_Enable_GEAR_Monitor(void);
void RTE_Write_SYS_Enable_GEAR_Monitor(float fltValue);
float RTE_Read_SYS_Enable_KEY_Monitor(void);
void RTE_Write_SYS_Enable_KEY_Monitor(float fltValue);
float RTE_Read_SYS_Enable_BAT_Monitor(void);
void RTE_Write_SYS_Enable_BAT_Monitor(float fltValue);
float RTE_Read_SYS_Enable_THERM_Monitor(void);
void RTE_Write_SYS_Enable_THERM_Monitor(float fltValue);
float RTE_Read_SYS_Enable_CHR_Monitor(void);
void RTE_Write_SYS_Enable_CHR_Monitor(float fltValue);
float RTE_Read_VehicleSpeed_kmph_Manual(void);
void RTE_Write_VehicleSpeed_kmph_Manual(float fltValue);
float RTE_Read_MotRotSpd_Manual(void);
void RTE_Write_MotRotSpd_Manual(float fltValue);
float RTE_Read_MCU_MaxTrq_Manual(void);
void RTE_Write_MCU_MaxTrq_Manual(float fltValue);
float RTE_Read_MCU_TractionTrqAvailable_Manual(void);
void RTE_Write_MCU_TractionTrqAvailable_Manual(float fltValue);
float RTE_Read_Load_Active_Monitor(void);
void RTE_Write_Load_Active_Monitor(float fltValue);
float RTE_Read_SYS_Enable_MCU_Monitor(void);
void RTE_Write_SYS_Enable_MCU_Monitor(float fltValue);
float RTE_Read_SYS_Enable_BRK_Monitor(void);
void RTE_Write_SYS_Enable_BRK_Monitor(float fltValue);
float RTE_Read_BrakePedal_Monitor(void);
void RTE_Write_BrakePedal_Monitor(float fltValue);
float RTE_Read_IMD_FaultSignal_Monitor(void);
void RTE_Write_IMD_FaultSignal_Monitor(float fltValue);
float RTE_Read_SYS_SubState_Monitor(void);
void RTE_Write_SYS_SubState_Monitor(float fltValue);
float RTE_Read_Load_Active_Manual(void);
void RTE_Write_Load_Active_Manual(float fltValue);
float RTE_Read_MainRelayOnStatus_Manual(void);
void RTE_Write_MainRelayOnStatus_Manual(float fltValue);
float RTE_Read_MotPwrEn_Manual(void);
void RTE_Write_MotPwrEn_Manual(float fltValue);
float RTE_Read_ParkCmd_Manual(void);
void RTE_Write_ParkCmd_Manual(float fltValue);
float RTE_Read_Epark_Inhit_Manual(void);
void RTE_Write_Epark_Inhit_Manual(float fltValue);
float RTE_Read_VehWhlClcdSpd_Monitor(void);
void RTE_Write_VehWhlClcdSpd_Monitor(float fltValue);
float RTE_Read_parkcmd_Monitor(void);
void RTE_Write_parkcmd_Monitor(float fltValue);
float RTE_Read_MotPwEna_Monitor(void);
void RTE_Write_MotPwEna_Monitor(float fltValue);
float RTE_Read_TqrTOMcu_Monitor(void);
void RTE_Write_TqrTOMcu_Monitor(float fltValue);
float RTE_Read_McuDtcClr_Monitor(void);
void RTE_Write_McuDtcClr_Monitor(float fltValue);
float RTE_Read_MotTqcCmd_PC_Monitor(void);
void RTE_Write_MotTqcCmd_PC_Monitor(float fltValue);
float RTE_Read_FlagLoadActive_Manual(void);
void RTE_Write_FlagLoadActive_Manual(float fltValue);
float RTE_Read_BrakeSwitch_Manual(void);
void RTE_Write_BrakeSwitch_Manual(float fltValue);
float RTE_Read_ChargeSwitch_Manual(void);
void RTE_Write_ChargeSwitch_Manual(float fltValue);
float RTE_Read_Gear_P_Manual(void);
void RTE_Write_Gear_P_Manual(float fltValue);
float RTE_Read_Gear_D_Manual(void);
void RTE_Write_Gear_D_Manual(float fltValue);
float RTE_Read_Gear_N_Manual(void);
void RTE_Write_Gear_N_Manual(float fltValue);
float RTE_Read_Gear_R_Manual(void);
void RTE_Write_Gear_R_Manual(float fltValue);
float RTE_Read_EStopSens_Manual(void);
void RTE_Write_EStopSens_Manual(float fltValue);
float RTE_Read_KeyStart_Manual(void);
void RTE_Write_KeyStart_Manual(float fltValue);
float RTE_Read_KeyAcc_Manual(void);
void RTE_Write_KeyAcc_Manual(float fltValue);
float RTE_Read_ParkPosSts_Manual(void);
void RTE_Write_ParkPosSts_Manual(float fltValue);
float RTE_Read_MCU_CANEnable_Manual(void);
void RTE_Write_MCU_CANEnable_Manual(float fltValue);
float RTE_Read_CoolntPmpDC_Manual(void);
void RTE_Write_CoolntPmpDC_Manual(float fltValue);
float RTE_Read_CoolntPmpFrqcy_Manual(void);
void RTE_Write_CoolntPmpFrqcy_Manual(float fltValue);
float RTE_Read_APP_1MS_OUT1(void);
void RTE_Write_APP_1MS_OUT1(float fltValue);
float RTE_Read_APP_1MS_IN1(void);
void RTE_Write_APP_1MS_IN1(float fltValue);
float RTE_Read_APP_50MS_OUT1(void);
void RTE_Write_APP_50MS_OUT1(float fltValue);
float RTE_Read_APP_50MS_IN1(void);
void RTE_Write_APP_50MS_IN1(float fltValue);

/* RTE SWC Init */
void RTE_vdInit(void);


/* RTE SWC Deinit */
void RTE_vdDeInit(void);


/* RTE SWC Access */
STATUS_t RTE_eReadData(uint16_t u16Id, float* pfltData);
STATUS_t RTE_eWriteData(uint16_t u16Id, float fltData);



/* Framework External Services Interfaces */
#define RTE_Service_COM_vdReadSignal ECU_COM_vdReadSignal
#define RTE_Service_COM_vdWriteSignal ECU_COM_vdWriteSignal
#define RTE_Service_COM_vdEnable ECU_COM_vdEnable
#define RTE_Service_ANLG_eReadSignal ECU_ANLG_eReadSignal
#define RTE_Service_IO_eOutputControl ECU_IO_eOutputControl
#define RTE_Service_IO_eInputRead ECU_IO_eInputRead
#define RTE_Service_MEM_eWriteSignalValue ECU_MEM_eWriteSignalValue
#define RTE_Service_MEM_eReadSignalValue ECU_MEM_eReadSignalValue
#define RTE_Service_SYS_vdShutdown ECU_SYS_vdShutdown
#define RTE_Service_IO_eReadPwm ECU_IO_eReadPwm
#define RTE_Service_IO_eSetPwm ECU_IO_eSetPwm
#define RTE_Service_SYS_vdGetResetStatus ECU_SYS_vdGetResetStatus
#define RTE_Service_SYS_vdClearResetStatus ECU_SYS_vdClearResetStatus
#define RTE_Service_IO_eInternalOutputControl ECU_IO_eInternalOutputControl

extern STATUS_t RTE_Service_COM_vdReadSignal(uint8_t u8IdSignal, float* pfltValue);
extern STATUS_t RTE_Service_COM_vdWriteSignal(uint8_t u8IdSignal, float fltValue);
extern STATUS_t RTE_Service_COM_vdEnable(uint8_t u8Enable);
extern STATUS_t RTE_Service_ANLG_eReadSignal(uint8_t u8IndexSignal, float* pfltValue);
extern STATUS_t RTE_Service_IO_eOutputControl(uint8_t u8IdOutput, ECU_IO_eOutputCommand_t eOutputCommand);
extern STATUS_t RTE_Service_IO_eInputRead(uint8_t u8IdInput, uint8_t* pu8Value);
extern STATUS_t RTE_Service_MEM_eWriteSignalValue(uint8_t u8SignalID, float fltValue, uint32_t u32Value);
extern STATUS_t RTE_Service_MEM_eReadSignalValue(uint8_t u8SignalID, float* pfltValue);
extern void RTE_Service_SYS_vdShutdown(void);
extern STATUS_t RTE_Service_IO_eReadPwm(uint8_t u8IdPin, uint32_t* pu32FreqHz, uint8_t* pu8DutyCycle);
extern STATUS_t RTE_Service_IO_eSetPwm(uint8_t u8IdPout, uint32_t u32FreqHz, uint8_t u8DutyCycle);
extern void RTE_Service_SYS_vdGetResetStatus(uint8_t* pu8IsExWdgReset);
extern void RTE_Service_SYS_vdClearResetStatus(uint8_t u8IsExWdgResetNeeded);
extern STATUS_t RTE_Service_IO_eInternalOutputControl(uint8_t u8IdOutput, ECU_IO_eOutputCommand_t eOutputCommand);

#endif /*RTE_H*/

