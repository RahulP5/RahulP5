classdef App_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        FileMenu                     matlab.ui.container.Menu
        OpenProjectMenu              matlab.ui.container.Menu
        SaveMenu                     matlab.ui.container.Menu
        ECUInfoMenu                  matlab.ui.container.Menu
        AboutMenu                    matlab.ui.container.Menu
        TabGroup                     matlab.ui.container.TabGroup
        HomeTab                      matlab.ui.container.Tab
        TabGroup3                    matlab.ui.container.TabGroup
        NewProjectTab                matlab.ui.container.Tab
        Label_error                  matlab.ui.control.Label
        SAVEButton_2                 matlab.ui.control.Button
        ProjectPathButton            matlab.ui.control.Button
        PathLabel                    matlab.ui.control.Label
        Label                        matlab.ui.control.Label
        ProjectNameEditField         matlab.ui.control.EditField
        ProjectNameEditFieldLabel    matlab.ui.control.Label
        Tab2                         matlab.ui.container.Tab
        SAVEButton                   matlab.ui.control.Button
        LoadDefaultfileButton        matlab.ui.control.Button
        ECUConfigurationTab          matlab.ui.container.Tab
        TabGroup2                    matlab.ui.container.TabGroup
        DigitalOutputsTab            matlab.ui.container.Tab
        DOUTConfigurationLabel       matlab.ui.control.Label
        UITable_dout                 matlab.ui.control.Table
        DigitalInputsTab             matlab.ui.container.Tab
        DINConfigurationLabel        matlab.ui.control.Label
        UITable_din                  matlab.ui.control.Table
        PWMOutputsTab                matlab.ui.container.Tab
        UITable_pout                 matlab.ui.control.Table
        PWMInputsTab                 matlab.ui.container.Tab
        UITable_pin                  matlab.ui.control.Table
        AinConfigurationTab          matlab.ui.container.Tab
        UITable_ain                  matlab.ui.control.Table
        CANTab                       matlab.ui.container.Tab
        UITable_can                  matlab.ui.control.Table
        DBCfileNameLabel             matlab.ui.control.Label
        BrowseButton                 matlab.ui.control.Button
        XCPCANChannelDropDown        matlab.ui.control.DropDown
        XCPCANChannelDropDownLabel   matlab.ui.control.Label
        XCPHBTXIDHEXEditField        matlab.ui.control.EditField
        XCPHBTXIDHEXEditFieldLabel   matlab.ui.control.Label
        XCPHBRXIDHEXEditField        matlab.ui.control.EditField
        XCPHBRXIDHEXEditFieldLabel   matlab.ui.control.Label
        XCPTXIDHEXEditField          matlab.ui.control.EditField
        XCPTXIDHEXEditFieldLabel     matlab.ui.control.Label
        XCPRXIDHEXEditField          matlab.ui.control.EditField
        XCPRXIDHEXEditFieldLabel     matlab.ui.control.Label
        XCPProtocolCANIDsLabel       matlab.ui.control.Label
        SelectRXandTXIDforthisdiagnostictoolUDSProtocolLabel  matlab.ui.control.Label
        TXHexEditField               matlab.ui.control.EditField
        TXHexEditFieldLabel          matlab.ui.control.Label
        RXHexEditField               matlab.ui.control.EditField
        RXHexEditFieldLabel          matlab.ui.control.Label
        CANBusSettingsLabel          matlab.ui.control.Label
        MemoryTab                    matlab.ui.container.Tab
        UITable_memory               matlab.ui.control.Table
        ParameterConfigurationLabel  matlab.ui.control.Label
        DTCTab                       matlab.ui.container.Tab
        UITable_dtc                  matlab.ui.control.Table
        DTCConfigurationLabel        matlab.ui.control.Label
    end

    
    properties (Access = private)
        ProjectDir % save path of project dir
        ProjectName % Description
        ProjectPathFlag % Description
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: BrowseButton
        function BrowseButtonPushed(app, event)
            [file, path, ~] = uigetfile('*.dbc');

            if isequal(file,0)
                disp('User selected Cancel');
            else
                app.DBCfileNameLabel.Text = file;
                
                if app.ProjectPathFlag == 1
                    disp("Paste Can dbc manually")

                else
                    renamefolder = strcat(path,file);
                    newname = strcat(app.ProjectDir,"/02_CAN/",file);
                    % movefile(renamefolder, newname);
                    copyfile(renamefolder, newname);
                end
                
                
            end
        end

        % Button pushed function: LoadDefaultfileButton
        function LoadDefaultfileButtonPushed(app, event)

            % writing dout table
            doutdata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "DOUT");
            doutdata(:, 2) = [];
            doutdata(:, 4) = [];
            app.UITable_dout.Data = doutdata;
            
            % writing din table
            dindata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "DIN");
            dindata(:, 2) = [];
            dindata(:, 2) = [];
            dindata(:, 3) = [];
            tempswap = dindata(:, 2); 
            dindata(:,2) = dindata(:, 3);
            dindata(:, 3) = tempswap;
            app.UITable_din.Data = dindata;

            % witing PWM out table
            poutdata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "POUT");
            poutdata(:,2) = [];
            poutdata(:,6) = [];
            app.UITable_pout.Data = poutdata;
            
            % writing PWM in table
            pindata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "PIN");
            pindata(:,2) = [];
            pindata(:,4) = [];
            app.UITable_pin.Data = pindata;
            
            % Writing Analog table
            aindata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "AIN");
            aindata(:, 2) = [];
            aindata(:, 4) = [];
            app.UITable_ain.Data = aindata;
            
            % writing Can table
            candata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range", "B:C");
            app.UITable_can.Data = candata;
            dbcfile = readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","A2:A2");
           
            out = strjoin(dbcfile(1:1));
            app.DBCfileNameLabel.Text = out;
   
            rxdiag = readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","D2:D2");
            rxedit = strjoin(rxdiag(1:1));
            app.RXHexEditField.Value = rxedit;

            txdiag = readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","E2:E2");
            txedit = strjoin(txdiag(1:1));
            app.TXHexEditField.Value = txedit;

            xcprx= readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","G2:G2");
            xcprxedit = strjoin(xcprx(1:1));
            app.XCPRXIDHEXEditField.Value = xcprxedit;

            xcptx= readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","H2:H2");
            xcptxedit = strjoin(xcptx(1:1));
            app.XCPTXIDHEXEditField.Value = xcptxedit;

            xcphbtx= readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","J2:J2");
            xcphbtxedit = strjoin(xcphbtx(1:1));
            app.XCPHBTXIDHEXEditField.Value = xcphbtxedit;

            xcphbrx= readcell("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN", "Range","I2:I2");
            xcphbrxedit = strjoin(xcphbrx(1:1));
            app.XCPHBRXIDHEXEditField.Value = xcphbrxedit;

            % writing memory table
            pdata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "PARAMETERS", "Range","C:F");
            %pdata(:, 1) = [];
            %pdata(:, 1) = [];
            app.UITable_memory.Data = pdata;

            % writing dtc table
            dtcdata = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "DTCS");
            app.UITable_dtc.Data = dtcdata;
        end

        % Callback function: SAVEButton, SaveMenu
        function SAVEButtonPushed(app, event)
            filename = '/deVCU_Configurator.xlsx';
            path = app.ProjectDir;

            if app.ProjectPathFlag == 1
                filename = strcat(path);
            else
                filename = strcat(path,"/04_System",filename);
            end
            
            % Dout Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "DOUT");
            doutdata = app.UITable_dout.Data;
            writetable(sheet(:, 1), filename, "Sheet", "DOUT", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "DOUT", "Range", "B1");
            writetable(sheet(:, 3), filename, "Sheet", "DOUT", "Range", "C1");
            writetable(doutdata(:, 3), filename, 'Sheet', "DOUT", "Range", "D1");

            writematrix("Connector Pin Number",filename, "Sheet", "DOUT", "Range", "A1");
            writematrix("Pin ID",filename, "Sheet", "DOUT", "Range", "B1");
            writematrix("Level",filename, "Sheet", "DOUT", "Range", "C1");
            writematrix("Application Name",filename, "Sheet", "DOUT", "Range", "D1");

            % Din Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "DIN");
            dindata = app.UITable_din.Data;
            writetable(sheet(:, 1), filename, "Sheet", "DIN", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "DIN", "Range", "B1");
            writetable(sheet(:, 3), filename, "Sheet", "DIN", "Range", "C1");
            writetable(dindata(:, 3), filename, 'Sheet', "DIN", "Range", "D1");
            writetable(sheet(:, 5), filename, "Sheet", "DIN", "Range", "E1");
            writetable(sheet(:, 6), filename, "Sheet", "DIN", "Range", "F1");

            writematrix("Connector Pin Number",filename, "Sheet", "DIN", "Range", "A1");
            writematrix("Pin ID",filename, "Sheet", "DIN", "Range", "B1");
            writematrix("Level",filename, "Sheet", "DIN", "Range", "C1");
            writematrix("Application Name",filename, "Sheet", "DIN", "Range", "D1");
            writematrix("AppLevel1",filename, "Sheet", "DIN", "Range", "E1");
            writematrix("AppLevel2",filename, "Sheet", "DIN", "Range", "F1");

            % Pout Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "POUT");
            poutdata = app.UITable_pout.Data;
            writetable(sheet(:, 1), filename, "Sheet", "POUT", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "POUT", "Range", "B1");
            writetable(sheet(:, 3), filename, "Sheet", "POUT", "Range", "C1");
            writetable(poutdata(:, 3), filename, 'Sheet', "POUT", "Range", "D1");
            writetable(poutdata(:, 4), filename, 'Sheet', "POUT", "Range", "E1");
            writetable(poutdata(:, 5), filename, 'Sheet', "POUT", "Range", "F1");

            writematrix("Connector Pin Number",filename, "Sheet", "POUT", "Range", "A1");
            writematrix("Pin ID",filename, "Sheet", "POUT", "Range", "B1");
            writematrix("Level",filename, "Sheet", "POUT", "Range", "C1");
            writematrix("Application Name",filename, "Sheet", "POUT", "Range", "D1");
            writematrix("PWM Frequency (Hz)",filename, "Sheet", "POUT", "Range", "E1");
            writematrix("PWM Initial Deuty Cycle (%)",filename, "Sheet", "POUT", "Range", "F1");

            % Pin Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "PIN");
            pindata = app.UITable_pin.Data;
            writetable(sheet(:, 1), filename, "Sheet", "PIN", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "PIN", "Range", "B1");
            writetable(sheet(:, 3), filename, "Sheet", "PIN", "Range", "C1");
            writetable(pindata(:, 3), filename, 'Sheet', "PIN", "Range", "D1");

            writematrix("Connector Pin Number",filename, "Sheet", "PIN", "Range", "A1");
            writematrix("Pin ID",filename, "Sheet", "PIN", "Range", "B1");
            writematrix("Level",filename, "Sheet", "PIN", "Range", "C1");
            writematrix("Application Name",filename, "Sheet", "PIN", "Range", "D1");

            % Ain Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "AIN");
            aindata = app.UITable_ain.Data;
            writetable(sheet(:, 1), filename, "Sheet", "AIN", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "AIN", "Range", "B1");
            writetable(sheet(:, 3), filename, "Sheet", "AIN", "Range", "C1");
            writetable(aindata(:, 3), filename, 'Sheet', "AIN", "Range", "D1");

            writematrix("Connector Pin Number",filename, "Sheet", "AIN", "Range", "A1");
            writematrix("Pin ID",filename, "Sheet", "AIN", "Range", "B1");
            writematrix("Level",filename, "Sheet", "AIN", "Range", "C1");
            writematrix("Application Name",filename, "Sheet", "AIN", "Range", "D1");

            % writetable(poutdata, filename, 'Sheet', "PIN");
            
            % Writing CAN sheet            
            % Can Sheet Column Names
            candata = app.UITable_can.Data{1:295, :};

            writematrix("DBC Name",filename, "Sheet", "CAN", "Range", "A1");
            %clipboard('copy',app.DBCfileNameLabel.Text)
            %fname = clipboard('paste')
            writematrix(app.DBCfileNameLabel.Text, filename, "Sheet", "CAN", "Range", "A2");

            writematrix("CAN RX Frame Ids (HEX)",filename, "Sheet", "CAN", "Range", "B1");
            writematrix(candata(:, 1),filename,'Sheet',"CAN",'Range','B2');
            writematrix("CAN TX Frame Ids (HEX)",filename, "Sheet", "CAN", "Range", "C1");
            writematrix(candata(:, 2),filename,'Sheet',"CAN",'Range','C2');
            writematrix("DIAG RX ID (HEX)",filename, "Sheet", "CAN", "Range", "D1");
            writematrix(app.RXHexEditField.Value,filename, "Sheet", "CAN", "Range", "D2");
            writematrix("DIAG TX ID (HEX)",filename, "Sheet", "CAN", "Range", "E1");
            writematrix(app.TXHexEditField.Value,filename, "Sheet", "CAN", "Range", "E2");
            writematrix("XCP CAN CHANNEL",filename, "Sheet", "CAN", "Range", "F1");
            writematrix(app.XCPCANChannelDropDown.Value, filename, "Sheet", "CAN", "Range", "F2");
            writematrix("XCP RX ID (HEX)",filename, "Sheet", "CAN", "Range", "G1");
            writematrix(app.XCPRXIDHEXEditField.Value, filename, "Sheet", "CAN", "Range", "G2");
            writematrix("XCP TX ID (HEX)",filename, "Sheet", "CAN", "Range", "H1");
            writematrix(app.XCPTXIDHEXEditField.Value, filename, "Sheet", "CAN", "Range", "H2");
            writematrix("XCP HB RX ID (HEX)",filename, "Sheet", "CAN", "Range", "I1");
            writematrix(app.XCPHBRXIDHEXEditField.Value, filename,"Sheet", "CAN", "Range", "I2");
            writematrix("XCP HB TX ID (HEX)",filename, "Sheet", "CAN", "Range", "J1");
            writematrix(app.XCPHBTXIDHEXEditField.Value, filename,"Sheet", "CAN", "Range", "J2");

            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "CAN");
            writetable(sheet(:, 11), filename, "Sheet", "CAN", "Range", "K1");
            writematrix("Row_NR",filename, "Sheet", "CAN", "Range", "K1");



            % Parameters sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "PARAMETERS");
            memdata = app.UITable_memory.Data;
            writetable(sheet(:, 1), filename, "Sheet", "PARAMETERS", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "PARAMETERS", "Range", "B1");
            writetable(memdata(:, 1), filename, 'Sheet', "PARAMETERS", "Range", "C1");
            writetable(memdata(:, 2), filename, 'Sheet', "PARAMETERS", "Range", "D1");
            writetable(memdata(:, 3), filename, 'Sheet', "PARAMETERS", "Range", "E1");
            writetable(memdata(:, 4), filename, 'Sheet', "PARAMETERS", "Range", "F1");

            writematrix("Memory Address",filename, "Sheet", "PARAMETERS", "Range", "A1");
            writematrix("Parameter ID",filename, "Sheet", "PARAMETERS", "Range", "B1");
            writematrix("Name",filename, "Sheet", "PARAMETERS", "Range", "C1");
            writematrix("Default Value",filename, "Sheet", "PARAMETERS", "Range", "D1");
            writematrix("Resolution",filename, "Sheet", "PARAMETERS", "Range", "E1");
            writematrix("Offset",filename, "Sheet", "PARAMETERS", "Range", "F1");

            % DTC sheet
            dtcdata = app.UITable_dtc.Data;
            writetable(dtcdata, filename, 'Sheet', "DTCS");

            writematrix("DTC ID",filename, "Sheet", "DTCS", "Range", "A1");
            writematrix("Name",filename, "Sheet", "DTCS", "Range", "B1");
            writematrix("Fault Severity",filename, "Sheet", "DTCS", "Range", "C1");
            writematrix("Reset Time",filename, "Sheet", "DTCS", "Range", "D1");
            writematrix("Error count limit",filename, "Sheet", "DTCS", "Range", "E1");

            % Settings Sheet
            sheet = readtable("SIGRA_VCU_Configurator.xlsx", "Sheet", "SETTINGS");
            writetable(sheet(:, 1), filename, "Sheet", "SETTINGS", "Range", "A1");
            writetable(sheet(:, 2), filename, "Sheet", "SETTINGS", "Range", "B1");

            writematrix(app.ProjectName,filename, "Sheet", "SETTINGS", "Range", "B1");
            
        end

        % Menu selected function: OpenProjectMenu
        function OpenProjectMenuSelected(app, event)
            [file, path, ~] = uigetfile('*.xlsx');
            if isequal(file,0)
                disp('User selected Cancel');
            else
                filepath = [path file];
                app.ProjectDir = filepath;
                app.ProjectPathFlag = 1;
                % writing dout table
                doutdata = readtable(filepath, "Sheet", "DOUT");
                doutdata(:, 2) = [];
                app.UITable_dout.Data = doutdata;
            
                % writing din table
                dindata = readtable(filepath, "Sheet", "DIN");
                dindata(:, 2) = [];
                dindata(:, 2) = [];
                dindata(:, 3) = [];
                tempswap = dindata(:, 2); 
                dindata(:,2) = dindata(:, 3);
                dindata(:, 3) = tempswap;
                app.UITable_din.Data = dindata;

                % witing PWM out table
                poutdata = readtable(filepath, "Sheet", "POUT");
                poutdata(:,2) = [];
                app.UITable_pout.Data = poutdata;
            
                % writing PWM in table
                pindata = readtable(filepath, "Sheet", "PIN");
                pindata(:,2) = [];
                app.UITable_pin.Data = pindata;
            
                % Writing Analog table
                aindata = readtable(filepath, "Sheet", "AIN");
                aindata(:, 2) = [];
                app.UITable_ain.Data = aindata;
            
                % writing Can table
                candata = readtable(filepath, "Sheet", "CAN", "Range", "B:C");
                app.UITable_can.Data = candata;
                dbcfile = readcell(filepath, "Sheet", "CAN", "Range","A2:A2");
                out = strjoin(dbcfile(1:1));
                app.DBCfileNameLabel.Text = out;

                rxdiag = readcell(filepath, "Sheet", "CAN", "Range","D2:D2");
                rxedit = strjoin(rxdiag(1:1));
                app.RXHexEditField.Value = rxedit;

                txdiag = readcell(filepath, "Sheet", "CAN", "Range","E2:E2");
                txedit = strjoin(txdiag(1:1));
                app.TXHexEditField.Value = txedit;

                xcprx= readcell(filepath, "Sheet", "CAN", "Range","G2:G2");
                xcprxedit = strjoin(xcprx(1:1));
                app.XCPRXIDHEXEditField.Value = xcprxedit;

                xcptx= readcell(filepath, "Sheet", "CAN", "Range","H2:H2");
                xcptxedit = strjoin(xcptx(1:1));
                app.XCPTXIDHEXEditField.Value = xcptxedit;

                xcphbtx= readcell(filepath, "Sheet", "CAN", "Range","J2:J2");
                xcphbtxedit = strjoin(xcphbtx(1:1));
                app.XCPHBTXIDHEXEditField.Value = xcphbtxedit;

                xcphbrx= readcell(filepath, "Sheet", "CAN", "Range","I2:I2");
                xcphbrxedit = strjoin(xcphbrx(1:1));
                app.XCPHBRXIDHEXEditField.Value = xcphbrxedit;

                % writing memory table
                pdata = readtable(filepath, "Sheet", "PARAMETERS", "Range","C:F");
                %pdata(:, 1) = [];
                %pdata(:, 1) = [];
                app.UITable_memory.Data = pdata;

                % writing dtc table
                dtcdata = readtable(filepath, "Sheet", "DTCS");
                app.UITable_dtc.Data = dtcdata;
            end
                     
        end

        % Button pushed function: ProjectPathButton
        function ProjectPathButtonPushed(app, event)
            if isempty(app.ProjectNameEditField.Value)
                app.Label_error.FontColor = [1.00,0.00,0.00];
                app.Label_error.Text = "Enter Project Name";
            else
                app.Label_error.Text = "";
                dname = uigetdir(' ');
                app.ProjectName = app.ProjectNameEditField.Value;
                app.Label.Text = [dname '/' app.ProjectNameEditField.Value];
                app.ProjectDir = app.Label.Text;
            end
        end

        % Button pushed function: SAVEButton_2
        function SAVEButton_2Pushed(app, event)
            if isempty(app.Label.Text)
                app.Label_error.FontColor = [1.00,0.00,0.00];
                app.Label_error.Text = "Select Path";
            else
                app.Label_error.Text = "";
                mkdir(app.ProjectDir);
                % movefile('/assets/01_Software/01_Code/Model_Simulation.slx', app.ProjectDir);
                copyfile('assets/', app.ProjectDir);
                renamefolder = strcat(app.ProjectDir,"/01_Software/01_Code/APP/app_TapasLib/01_Library/Project_name");
                newname = strcat(app.ProjectDir,"/01_Software/01_Code/APP/app_TapasLib/01_Library/",app.ProjectName);
                movefile(renamefolder, newname);

                renamefolder = strcat(app.ProjectDir,"/01_Software/01_Code/TAPAS_CFG/Project_name");
                newname = strcat(app.ProjectDir,"/01_Software/01_Code/TAPAS_CFG/",app.ProjectName);
                movefile(renamefolder, newname);

                oldname = strcat(app.ProjectDir,"/01_Software/01_Code/RTE/Project_name.fwxml");
                newname = strcat(app.ProjectDir,"/01_Software/01_Code/RTE/",app.ProjectName,".fwxml");
                movefile(oldname, newname);

                LoadDefaultfileButtonPushed(app);
                app.Label_error.FontColor = [0.47, 0.67, 0.19];
                app.ProjectPathFlag = 0;
                app.Label_error.Text = "Project Created..";
            end

        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [0.8 0.8 0.8];
            app.UIFigure.Position = [0 0 1920 1080];
            app.UIFigure.Name = 'MATLAB App';

            % Create FileMenu
            app.FileMenu = uimenu(app.UIFigure);
            app.FileMenu.ForegroundColor = [0.149 0.149 0.149];
            app.FileMenu.Text = 'File';

            % Create OpenProjectMenu
            app.OpenProjectMenu = uimenu(app.FileMenu);
            app.OpenProjectMenu.MenuSelectedFcn = createCallbackFcn(app, @OpenProjectMenuSelected, true);
            app.OpenProjectMenu.ForegroundColor = [0 0.4471 0.7412];
            app.OpenProjectMenu.Text = 'Open Project';

            % Create SaveMenu
            app.SaveMenu = uimenu(app.FileMenu);
            app.SaveMenu.MenuSelectedFcn = createCallbackFcn(app, @SAVEButtonPushed, true);
            app.SaveMenu.ForegroundColor = [0.4667 0.6745 0.1882];
            app.SaveMenu.Accelerator = 's';
            app.SaveMenu.Text = 'Save';

            % Create ECUInfoMenu
            app.ECUInfoMenu = uimenu(app.FileMenu);
            app.ECUInfoMenu.ForegroundColor = [0.3922 0.8314 0.0745];
            app.ECUInfoMenu.Text = 'ECU Info';

            % Create AboutMenu
            app.AboutMenu = uimenu(app.FileMenu);
            app.AboutMenu.ForegroundColor = [0.6353 0.0784 0.1843];
            app.AboutMenu.Text = 'About';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 0 1920 1081];

            % Create HomeTab
            app.HomeTab = uitab(app.TabGroup);
            app.HomeTab.Title = 'Home';
            app.HomeTab.BackgroundColor = [0.5686 0.6706 0.7412];
            app.HomeTab.ForegroundColor = [0.2824 0.5294 0.149];

            % Create TabGroup3
            app.TabGroup3 = uitabgroup(app.HomeTab);
            app.TabGroup3.Position = [9 76 1900 930];

            % Create NewProjectTab
            app.NewProjectTab = uitab(app.TabGroup3);
            app.NewProjectTab.Title = 'New Project';
            app.NewProjectTab.BackgroundColor = [0.7569 0.7608 0.7804];

            % Create ProjectNameEditFieldLabel
            app.ProjectNameEditFieldLabel = uilabel(app.NewProjectTab);
            app.ProjectNameEditFieldLabel.HorizontalAlignment = 'right';
            app.ProjectNameEditFieldLabel.FontSize = 20;
            app.ProjectNameEditFieldLabel.FontWeight = 'bold';
            app.ProjectNameEditFieldLabel.FontColor = [0 0.4471 0.7412];
            app.ProjectNameEditFieldLabel.Position = [161 752 133 42];
            app.ProjectNameEditFieldLabel.Text = 'Project Name';

            % Create ProjectNameEditField
            app.ProjectNameEditField = uieditfield(app.NewProjectTab, 'text');
            app.ProjectNameEditField.HorizontalAlignment = 'center';
            app.ProjectNameEditField.FontSize = 20;
            app.ProjectNameEditField.FontWeight = 'bold';
            app.ProjectNameEditField.FontColor = [0 0.4471 0.7412];
            app.ProjectNameEditField.Position = [309 752 449 42];

            % Create Label
            app.Label = uilabel(app.NewProjectTab);
            app.Label.BackgroundColor = [1 1 1];
            app.Label.FontSize = 14;
            app.Label.Position = [309 607 570 38];
            app.Label.Text = '';

            % Create PathLabel
            app.PathLabel = uilabel(app.NewProjectTab);
            app.PathLabel.FontSize = 20;
            app.PathLabel.FontWeight = 'bold';
            app.PathLabel.FontColor = [0 0.4471 0.7412];
            app.PathLabel.Position = [226 611 49 26];
            app.PathLabel.Text = 'Path';

            % Create ProjectPathButton
            app.ProjectPathButton = uibutton(app.NewProjectTab, 'push');
            app.ProjectPathButton.ButtonPushedFcn = createCallbackFcn(app, @ProjectPathButtonPushed, true);
            app.ProjectPathButton.BackgroundColor = [1 1 1];
            app.ProjectPathButton.FontSize = 16;
            app.ProjectPathButton.FontWeight = 'bold';
            app.ProjectPathButton.FontColor = [0.4667 0.6745 0.1882];
            app.ProjectPathButton.Position = [435 656 140 52];
            app.ProjectPathButton.Text = 'Project Path';

            % Create SAVEButton_2
            app.SAVEButton_2 = uibutton(app.NewProjectTab, 'push');
            app.SAVEButton_2.ButtonPushedFcn = createCallbackFcn(app, @SAVEButton_2Pushed, true);
            app.SAVEButton_2.BackgroundColor = [1 1 1];
            app.SAVEButton_2.FontSize = 16;
            app.SAVEButton_2.FontWeight = 'bold';
            app.SAVEButton_2.FontColor = [0.4667 0.6745 0.1882];
            app.SAVEButton_2.Position = [435 526 140 51];
            app.SAVEButton_2.Text = 'SAVE';

            % Create Label_error
            app.Label_error = uilabel(app.NewProjectTab);
            app.Label_error.FontWeight = 'bold';
            app.Label_error.FontColor = [1 0 0];
            app.Label_error.Position = [369 826 342 22];
            app.Label_error.Text = '';

            % Create Tab2
            app.Tab2 = uitab(app.TabGroup3);
            app.Tab2.Title = 'Tab2';

            % Create LoadDefaultfileButton
            app.LoadDefaultfileButton = uibutton(app.Tab2, 'push');
            app.LoadDefaultfileButton.ButtonPushedFcn = createCallbackFcn(app, @LoadDefaultfileButtonPushed, true);
            app.LoadDefaultfileButton.Position = [60 682 130 47];
            app.LoadDefaultfileButton.Text = 'Load Default file';

            % Create SAVEButton
            app.SAVEButton = uibutton(app.Tab2, 'push');
            app.SAVEButton.ButtonPushedFcn = createCallbackFcn(app, @SAVEButtonPushed, true);
            app.SAVEButton.Position = [260 682 117 47];
            app.SAVEButton.Text = 'SAVE';

            % Create ECUConfigurationTab
            app.ECUConfigurationTab = uitab(app.TabGroup);
            app.ECUConfigurationTab.Title = 'ECU Configuration';

            % Create TabGroup2
            app.TabGroup2 = uitabgroup(app.ECUConfigurationTab);
            app.TabGroup2.Position = [2 1 1918 996];

            % Create DigitalOutputsTab
            app.DigitalOutputsTab = uitab(app.TabGroup2);
            app.DigitalOutputsTab.Title = 'Digital Outputs';
            app.DigitalOutputsTab.Scrollable = 'on';

            % Create UITable_dout
            app.UITable_dout = uitable(app.DigitalOutputsTab);
            app.UITable_dout.ColumnName = {'Connector Pin Number'; 'Level'; 'Application Name'};
            app.UITable_dout.ColumnRearrangeable = 'on';
            app.UITable_dout.RowName = {};
            app.UITable_dout.ColumnEditable = [false false true];
            app.UITable_dout.Position = [11 19 1893 867];

            % Create DOUTConfigurationLabel
            app.DOUTConfigurationLabel = uilabel(app.DigitalOutputsTab);
            app.DOUTConfigurationLabel.Position = [17 896 114 35];
            app.DOUTConfigurationLabel.Text = 'DOUT Configuration';

            % Create DigitalInputsTab
            app.DigitalInputsTab = uitab(app.TabGroup2);
            app.DigitalInputsTab.Title = 'Digital Inputs';
            app.DigitalInputsTab.Scrollable = 'on';

            % Create UITable_din
            app.UITable_din = uitable(app.DigitalInputsTab);
            app.UITable_din.ColumnName = {'Connector Pin Number'; 'Pin Function'; 'Application Name'};
            app.UITable_din.ColumnRearrangeable = 'on';
            app.UITable_din.RowName = {};
            app.UITable_din.ColumnEditable = [false false true];
            app.UITable_din.Position = [11 19 1893 867];

            % Create DINConfigurationLabel
            app.DINConfigurationLabel = uilabel(app.DigitalInputsTab);
            app.DINConfigurationLabel.Position = [17 896 114 35];
            app.DINConfigurationLabel.Text = 'DIN Configuration';

            % Create PWMOutputsTab
            app.PWMOutputsTab = uitab(app.TabGroup2);
            app.PWMOutputsTab.Title = 'PWM Outputs';
            app.PWMOutputsTab.Scrollable = 'on';

            % Create UITable_pout
            app.UITable_pout = uitable(app.PWMOutputsTab);
            app.UITable_pout.ColumnName = {'Pout Number'; 'Level'; 'Application Name'; 'Default PWM Frequency'; 'Default PWM Duty Cycle %'};
            app.UITable_pout.ColumnRearrangeable = 'on';
            app.UITable_pout.RowName = {};
            app.UITable_pout.ColumnEditable = [false false true true true];
            app.UITable_pout.Position = [11 19 1892 858];

            % Create PWMInputsTab
            app.PWMInputsTab = uitab(app.TabGroup2);
            app.PWMInputsTab.Title = 'PWM Inputs';
            app.PWMInputsTab.Scrollable = 'on';

            % Create UITable_pin
            app.UITable_pin = uitable(app.PWMInputsTab);
            app.UITable_pin.ColumnName = {'Pin Number'; 'Level'; 'Application Name'};
            app.UITable_pin.ColumnRearrangeable = 'on';
            app.UITable_pin.RowName = {};
            app.UITable_pin.ColumnEditable = [false false true];
            app.UITable_pin.Position = [11 19 1892 858];

            % Create AinConfigurationTab
            app.AinConfigurationTab = uitab(app.TabGroup2);
            app.AinConfigurationTab.Title = 'Ain Configuration';
            app.AinConfigurationTab.Scrollable = 'on';

            % Create UITable_ain
            app.UITable_ain = uitable(app.AinConfigurationTab);
            app.UITable_ain.ColumnName = {'Pin Number'; 'Level'; 'Application Name'};
            app.UITable_ain.ColumnRearrangeable = 'on';
            app.UITable_ain.RowName = {};
            app.UITable_ain.ColumnEditable = [false false true];
            app.UITable_ain.Position = [11 19 1892 838];

            % Create CANTab
            app.CANTab = uitab(app.TabGroup2);
            app.CANTab.Title = 'CAN';
            app.CANTab.Scrollable = 'on';

            % Create CANBusSettingsLabel
            app.CANBusSettingsLabel = uilabel(app.CANTab);
            app.CANBusSettingsLabel.Position = [17 929 102 22];
            app.CANBusSettingsLabel.Text = 'CAN Bus Settings';

            % Create RXHexEditFieldLabel
            app.RXHexEditFieldLabel = uilabel(app.CANTab);
            app.RXHexEditFieldLabel.HorizontalAlignment = 'right';
            app.RXHexEditFieldLabel.Position = [11 875 55 22];
            app.RXHexEditFieldLabel.Text = 'RX (Hex)';

            % Create RXHexEditField
            app.RXHexEditField = uieditfield(app.CANTab, 'text');
            app.RXHexEditField.Placeholder = '3A0';
            app.RXHexEditField.Position = [81 875 100 22];

            % Create TXHexEditFieldLabel
            app.TXHexEditFieldLabel = uilabel(app.CANTab);
            app.TXHexEditFieldLabel.HorizontalAlignment = 'right';
            app.TXHexEditFieldLabel.Position = [211 875 53 22];
            app.TXHexEditFieldLabel.Text = 'TX (Hex)';

            % Create TXHexEditField
            app.TXHexEditField = uieditfield(app.CANTab, 'text');
            app.TXHexEditField.Placeholder = '3A1';
            app.TXHexEditField.Position = [279 875 100 22];

            % Create SelectRXandTXIDforthisdiagnostictoolUDSProtocolLabel
            app.SelectRXandTXIDforthisdiagnostictoolUDSProtocolLabel = uilabel(app.CANTab);
            app.SelectRXandTXIDforthisdiagnostictoolUDSProtocolLabel.Position = [18 896 320 22];
            app.SelectRXandTXIDforthisdiagnostictoolUDSProtocolLabel.Text = 'Select RX and TX ID for this diagnostic tool(UDS Protocol)';

            % Create XCPProtocolCANIDsLabel
            app.XCPProtocolCANIDsLabel = uilabel(app.CANTab);
            app.XCPProtocolCANIDsLabel.Position = [580 903 127 22];
            app.XCPProtocolCANIDsLabel.Text = 'XCP Protocol CAN IDs';

            % Create XCPRXIDHEXEditFieldLabel
            app.XCPRXIDHEXEditFieldLabel = uilabel(app.CANTab);
            app.XCPRXIDHEXEditFieldLabel.HorizontalAlignment = 'right';
            app.XCPRXIDHEXEditFieldLabel.Position = [535 875 101 22];
            app.XCPRXIDHEXEditFieldLabel.Text = 'XCP RX ID (HEX)';

            % Create XCPRXIDHEXEditField
            app.XCPRXIDHEXEditField = uieditfield(app.CANTab, 'text');
            app.XCPRXIDHEXEditField.Placeholder = '2A0';
            app.XCPRXIDHEXEditField.Position = [651 875 100 22];

            % Create XCPTXIDHEXEditFieldLabel
            app.XCPTXIDHEXEditFieldLabel = uilabel(app.CANTab);
            app.XCPTXIDHEXEditFieldLabel.HorizontalAlignment = 'right';
            app.XCPTXIDHEXEditFieldLabel.Position = [536 847 100 22];
            app.XCPTXIDHEXEditFieldLabel.Text = 'XCP TX ID (HEX)';

            % Create XCPTXIDHEXEditField
            app.XCPTXIDHEXEditField = uieditfield(app.CANTab, 'text');
            app.XCPTXIDHEXEditField.Placeholder = '1A0';
            app.XCPTXIDHEXEditField.Position = [651 847 100 22];

            % Create XCPHBRXIDHEXEditFieldLabel
            app.XCPHBRXIDHEXEditFieldLabel = uilabel(app.CANTab);
            app.XCPHBRXIDHEXEditFieldLabel.HorizontalAlignment = 'right';
            app.XCPHBRXIDHEXEditFieldLabel.Position = [515 816 121 22];
            app.XCPHBRXIDHEXEditFieldLabel.Text = 'XCP HB RX ID (HEX)';

            % Create XCPHBRXIDHEXEditField
            app.XCPHBRXIDHEXEditField = uieditfield(app.CANTab, 'text');
            app.XCPHBRXIDHEXEditField.Placeholder = '2A1';
            app.XCPHBRXIDHEXEditField.Position = [651 816 100 22];

            % Create XCPHBTXIDHEXEditFieldLabel
            app.XCPHBTXIDHEXEditFieldLabel = uilabel(app.CANTab);
            app.XCPHBTXIDHEXEditFieldLabel.HorizontalAlignment = 'right';
            app.XCPHBTXIDHEXEditFieldLabel.Position = [516 782 120 22];
            app.XCPHBTXIDHEXEditFieldLabel.Text = 'XCP HB TX ID (HEX)';

            % Create XCPHBTXIDHEXEditField
            app.XCPHBTXIDHEXEditField = uieditfield(app.CANTab, 'text');
            app.XCPHBTXIDHEXEditField.Placeholder = '1A1';
            app.XCPHBTXIDHEXEditField.Position = [651 782 100 22];

            % Create XCPCANChannelDropDownLabel
            app.XCPCANChannelDropDownLabel = uilabel(app.CANTab);
            app.XCPCANChannelDropDownLabel.HorizontalAlignment = 'right';
            app.XCPCANChannelDropDownLabel.Position = [529 746 107 22];
            app.XCPCANChannelDropDownLabel.Text = 'XCP CAN Channel';

            % Create XCPCANChannelDropDown
            app.XCPCANChannelDropDown = uidropdown(app.CANTab);
            app.XCPCANChannelDropDown.Items = {'Ch3', 'Ch2', 'Ch1'};
            app.XCPCANChannelDropDown.ItemsData = {'3', '2', '1'};
            app.XCPCANChannelDropDown.Position = [651 746 100 22];
            app.XCPCANChannelDropDown.Value = '3';

            % Create BrowseButton
            app.BrowseButton = uibutton(app.CANTab, 'push');
            app.BrowseButton.ButtonPushedFcn = createCallbackFcn(app, @BrowseButtonPushed, true);
            app.BrowseButton.Position = [996 876 160 41];
            app.BrowseButton.Text = 'Browse';

            % Create DBCfileNameLabel
            app.DBCfileNameLabel = uilabel(app.CANTab);
            app.DBCfileNameLabel.Position = [996 836 234 22];
            app.DBCfileNameLabel.Text = 'DBC file Name';

            % Create UITable_can
            app.UITable_can = uitable(app.CANTab);
            app.UITable_can.ColumnName = {'CAN Received Frame IDs -(USE DEC VALUES)'; 'CAN Transmitted frame IDs -(USE DEC VALUES)'};
            app.UITable_can.ColumnRearrangeable = 'on';
            app.UITable_can.RowName = {};
            app.UITable_can.ColumnEditable = [true true];
            app.UITable_can.Position = [11 19 1892 700];

            % Create MemoryTab
            app.MemoryTab = uitab(app.TabGroup2);
            app.MemoryTab.Title = 'Memory';
            app.MemoryTab.Scrollable = 'on';

            % Create ParameterConfigurationLabel
            app.ParameterConfigurationLabel = uilabel(app.MemoryTab);
            app.ParameterConfigurationLabel.Position = [17 896 136 35];
            app.ParameterConfigurationLabel.Text = 'Parameter Configuration';

            % Create UITable_memory
            app.UITable_memory = uitable(app.MemoryTab);
            app.UITable_memory.ColumnName = {'Name'; 'Default Value'; 'Resolution'; 'Offset'};
            app.UITable_memory.ColumnRearrangeable = 'on';
            app.UITable_memory.RowName = {};
            app.UITable_memory.ColumnEditable = [true true true true];
            app.UITable_memory.Position = [11 19 1893 867];

            % Create DTCTab
            app.DTCTab = uitab(app.TabGroup2);
            app.DTCTab.Title = 'DTC';
            app.DTCTab.Scrollable = 'on';

            % Create DTCConfigurationLabel
            app.DTCConfigurationLabel = uilabel(app.DTCTab);
            app.DTCConfigurationLabel.Position = [17 896 136 35];
            app.DTCConfigurationLabel.Text = 'DTC Configuration';

            % Create UITable_dtc
            app.UITable_dtc = uitable(app.DTCTab);
            app.UITable_dtc.ColumnName = {'DTC ID'; 'Name'; 'Fault Severity'; 'Reset Time'; 'Error Count Limit'};
            app.UITable_dtc.ColumnRearrangeable = 'on';
            app.UITable_dtc.RowName = {};
            app.UITable_dtc.ColumnEditable = [false true true true true];
            app.UITable_dtc.Position = [11 19 1893 867];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = App_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end