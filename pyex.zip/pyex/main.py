from openpyxl import load_workbook
from pprint import pprint

wb = load_workbook(filename = 'busmaster.xlsx')
sheet_ranges = wb['Sheet1']
# value_list = [cell.value for cell in sheet_ranges["D"]]

can_ids = [cell.value for cell in sheet_ranges["D"]]
can_channel_number = [cell.value for cell in sheet_ranges["C"]]
can_msg_direction = [cell.value for cell in sheet_ranges["B"]]
can_msg_time = [cell.value for cell in sheet_ranges["A"]]


can_ids = can_ids[3:]
can_channel_number = can_channel_number[3:]
can_msg_direction = can_msg_direction[3:]
can_msg_time = can_msg_time[3:]


# print unique can ids from list
# option 1
# original_list = [1, 2, 2, 3, 4, 4, 5, 6, 6, 7, 8, 8, 8, 9, 10]
# unique_list = []
# for item in original_list:
#     if item not in unique_list:
#         unique_list.append(item)
# print(unique_list)
# option 2
unique_set = set(can_ids)
unique_can_id_list = list(unique_set)
# pprint(unique_can_id_list)

# Create optput excel

wb = load_workbook(filename = 'testfile.xlsx')
ws = wb.active
ws['A1'] = "CAN ID"
ws['B1'] = "TX"
ws['C1'] = "RX"

# calculate number of tx rx for can message

no_of_tx = 0
no_of_rx = 0
counter = 2

for _, id in enumerate(unique_can_id_list):
    for x in range(0, len(can_ids)):
        if can_ids[x] == id:
            if can_msg_direction[x] == "Rx":
                no_of_rx += 1

            elif can_msg_direction[x] == "Tx":
                no_of_tx += 1

    print(f"for can id: {id} TX = {no_of_tx} , RX={no_of_rx}")
    ws[f'A{counter}'] = id
    ws[f'B{counter}'] = no_of_tx
    ws[f'C{counter}'] = no_of_rx
    no_of_tx = 0
    no_of_rx = 0
    counter += 1


wb.save('count_tx_rx.xlsx')
